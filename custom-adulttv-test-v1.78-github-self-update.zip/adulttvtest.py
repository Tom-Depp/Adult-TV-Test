"""
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import json
import base64
import time
import os
import io
import sys
import xbmc
import xbmcgui
import http.cookiejar
import ssl
import hashlib
import shutil
import sqlite3
import zipfile

from html import unescape as html_unescape
from urllib.parse import urljoin, quote_plus, urlencode, urlparse, parse_qs, unquote
from urllib.request import Request, build_opener, HTTPCookieProcessor, HTTPSHandler
from urllib.error import HTTPError, URLError

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

try:
    from PIL import Image
except Exception:
    Image = None

from resources.lib import utils
from resources.lib import basics
from resources.lib.customsite import CustomSite

#site = AdultSite('adulttvtest', '[COLOR hotpink]Adult TV Test v1.0[/COLOR]', 'https://adult-tv-channels.com/', 'https://adult-tv-channels.com/wp-content/uploads/2021/11/cropped-adult-tv-channels.png', 'adulttvtest')
site = CustomSite('TomDepp', 'adulttvtest')


# -------------------------------------------------------------------------
# GitHub self-update (test channel)
# -------------------------------------------------------------------------
SITE_VERSION = '1.78'
UPDATE_CHANNEL = 'test'
UPDATE_REPOSITORY = 'Tom-Depp/Adult-TV-Test'
UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/Tom-Depp/Adult-TV-Test/main/update.json'
UPDATE_CHECK_TIMEOUT = 3.0
UPDATE_DOWNLOAD_TIMEOUT = 20.0
UPDATE_MAX_BYTES = 2 * 1024 * 1024



BASE_COM = 'https://adult-tv-channels.com/'
BASE_CLICK = 'https://adult-tv-channels.click/'
BASE_OXAX = 'http://oxax.tv/'
BASE_FUCKFLIX = 'https://fuckflix.click/'

# v58: .com erkennt nun auch die neutral umgeleiteten MyCam-Ersatzstreams
# (insbesondere cdn.adultiptv.net / Redtraffic) als FALLBACK. Zusaetzlich
# kommt FuckFlix als vierte, zunaechst diagnostische Site hinzu: WordPress-
# Seitenaufbau wie .com, Player-/POST-Auswertung wie .click, HLS REAL sowie
# MyCam/Redtraffic/MP4 als sichtbarer FALLBACK.
# v59: FuckFlix erkennt nummerierte WordPress-Seiten auch ohne rel=next/
# Next-Text und prueft alle 9 Archivseiten sequenziell. Babes TV HD verwendet
# nach Deep-Preflight wirklich den geprueften SkyGo-Child samt Segment-Warmup
# und bekommt mehr Startzeit, damit Kodi nicht wieder genau beim Demuxer-Start
# gestoppt wird.
# v60: FuckFlix wird fuer die Diagnose wieder in zwei Testbereiche am Sender
# FashionTV Midnight Secrets geteilt; FashionTV selbst wird uebersprungen.
# Bei den Marken-Sendern vor FashionTV sind MyCam/Redtraffic keine gueltigen
# Erfolge mehr. POST/JSON- und iframe-Antworten werden nach ALLEN Streams
# durchsucht, damit ein zusaetzlicher Fallback nicht den echten Stream
# ueberschreibt. MP4 bleibt bis zu einem Website-Nachweis komplett deaktiviert.
# v61: FuckFlix verhindert parallele Doppeltests ueber eine Kodi-weite Sperre
# und zeigt jeden internen Lade-/Fresh-Pass sichtbar im Fortschrittsfenster.
# Die Player-Suche erkennt nun auch Lazy-iframe-Attribute, JS-Player-URLs,
# fetch/ajax/XHR-Endpunkte und bis zu zwei verschachtelte Player-Seiten. Der
# Log unterscheidet dadurch klar: echter Link gefunden, nur Fallback gefunden
# oder kein Player-Endpunkt gefunden. Kodi wird weiterhin nur bei REAL genutzt.
# v62: Das modale Fortschrittsfenster wird fuer COM, CLICK, FuckFlix und OXAX
# vor jedem Sender neu erzeugt und nach jedem Senderstart erneut eingeblendet.
# Kodi schliesst DialogProgress beim Videostart; ein blosses update() auf dem
# alten Objekt war danach unsichtbar. Die Recreate-Logik zeigt deshalb auch
# waehrend Fehlern, Fallback-Suche und Pausen wieder einen sichtbaren Status.
# v63: FuckFlix loest nun auch dynamisch zusammengesetzte JavaScript-POST-
# Endpunkte auf, z. B. var api_url='...'; fetch(api_url + '/token', ...).
# Damit wird data.fileUrl wie im Website-Player abgefragt. Liefert die API
# aktuell nur einen Fehler-/MyCam-Ersatz, bleibt er blockiert; sobald der
# echte Stream wieder verfuegbar ist, erkennt derselbe Build ihn automatisch.
# v64: FuckFlix verwendet beim AutoTest nun dieselbe Cookie-/Browser-Session
# von den Archivseiten bis zur Senderseite und zu deren dynamischem POST.
# Das entspricht dem Browser-Navigationsweg und verhindert, dass jeder Sender
# als frischer Direktaufruf eine fallback-only HTML-Variante bekommt. Zusaetzlich
# protokolliert v64 bei fehlenden Endpunkten die entscheidenden Runtime-Marker
# (fetch/fileUrl/api_url/videojs/atob/Redtraffic) und bietet einen schnellen
# Diagnosebereich nur fuer Page 1-2 (24 Sender).
# v65: Der v64-Log zeigt bei allen 22 Fallback-only-Seiten api_url=1, aber
# fetch/fileUrl/videojs=0. v65 prueft deshalb zusaetzlich externe JavaScript-
# Dateien der Senderseite. Relative/same-origin Script-Dateien werden mit
# derselben Browser-Session geladen, mit den im HTML gefundenen URL-Variablen
# ausgewertet und koennen dadurch fetch/ajax/XHR-Endpunkte liefern, deren Logik
# nicht mehr inline im HTML steht. Unaufgeloeste api_url-Kontexte und Script-
# Quellen werden gezielt protokolliert, ohne die komplette Seite zu dumpen.
# v66: Die aktuellen Browser-Quelltexte zeigen die neue FuckFlix-Struktur
# eindeutig: window.playerConfig = {streamType:'api', apiUrl:'...', endpoint:
# '...', sourceUrl:'Redtraffic...', useHlsJs:...}. Der eigentliche fetch()
# steckt nur noch in /assets/js/player.js. v66 liest deshalb playerConfig
# direkt aus der Senderseite und baut apiUrl + endpoint als POST-Endpunkt.
# sourceUrl bleibt bewusst FALLBACK. Dadurch muss die generische externe
# player.js-Logik nicht emuliert werden und die API liefert data.fileUrl direkt.
# v67: Der v66-Log bestaetigt, dass playerConfig und der POST-Endpunkt nun bei
# allen problematischen Sendern korrekt gefunden und aufgerufen werden, die
# Antwort aber noch keinen REAL-Kandidaten erzeugt. v67 liest deshalb das
# erwartete JSON-Feld data.fileUrl/verschachteltes fileUrl explizit aus der
# API-Antwort und akzeptiert es auch ohne .m3u8-Endung. Zusaetzlich werden
# HTTP-Status, Content-Type, Antwortgroesse, JSON-Keys und ein kompakter
# Antwort-Preview geloggt, falls fileUrl fehlt. So trennt der naechste Log
# eindeutig Parserfehler von einer API-Antwort, die Kodi anders als Edge sieht.
# v69: Der v67-Log zeigt die letzte Kodierungsschicht: fileUrl ist kein direkter
# URL-String, sondern Base64. Nach dem Dekodieren ist der Text rueckwaerts und
# ergibt eine kurzlebige https://stream.xlivetv.com/s/<token>-URL. v69 dekodiert
# diese Kombination automatisch, behandelt den XLivetv-Gateway als REAL und
# prueft auch extensionless HLS-Gateways, statt sie durch die .m3u8-Pflicht der
# .click-Preflight-Logik abzulehnen. Redirect/Manifest werden vor Kodi geprueft.
# v73: Der v72-Brazzers-Einzeltest grenzt .com auf das 2-KB-/tv/*.php-
# JWPlayer-Dokument ein: vier jwplayer-Marker, aber keine literal .m3u8/API-
# Marker. v73 liest deshalb JWPlayer file/src/source/url/playlist-Ausdruecke
# samt einfachen JS-Variablen auch ohne Dateiendung, protokolliert kompakte
# JWPlayer-Kontexte und ignoriert die externe jwplayer8.js als API-Endpunkt.
# Dadurch kann ein extensionless/zusammengesetzter REAL-Stream vor MyCam
# gefunden und mit dem vorhandenen .com-Preflight sicher verifiziert werden.
# v74: Log 69 zeigt die aktuelle letzte Verschleierungsschicht eindeutig:
# const signedUrl=(function(){var k=N,a=[...],r=''; ... fromCharCode(a[i]^k)
# ...})(); jwplayer(...).setup({file:signedUrl}). v74 dekodiert solche XOR-
# IIFEs lokal, speist signedUrl in die bestehende JWPlayer-Variablenauswertung
# ein und uebergibt den signierten aistr.xyz-HLS-Link an den bewaehrten COM-
# Preflight. Keine Aenderungen an .click, FuckFlix oder OXAX.
# v78: GitHub-Testkanal fuer Adult TV Test. Beim Oeffnen der Custom Site wird
# update.json im Repository Tom-Depp/Adult-TV-Test mit kurzem Timeout geprueft.
# Ein verfuegbares Update wird nach Benutzerbestaetigung als ZIP geladen, per
# SHA256/ZIP-CRC/meta.json/Python-Compile validiert und mit Backup atomar in
# die bereits installierte CUMination-Custom-Site eingespielt. Fehler beim
# Check blockieren die Site nie; Streaminglogik von v77 bleibt unveraendert.
# v75 ist temporaer auf COM Page 1-5 begrenzt. Zusaetzlich dekodiert COM
# aktive inline XOR-IIFEs direkt in Playerjs/Clappr-Eigenschaften wie file/source,
# damit z.B. Evil Angel nicht mehr nur wegen file:(function(){...}) scheitert.
# Fuer weiterhin unbekannte Player (z.B. Redlight/Clappr) werden kompakte
# Player-Kontexte geloggt. OXAX/.click/FuckFlix bleiben unveraendert.
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
FUCKFLIX_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0'

# v34: .click bekommt einen Testbereich-Dialog: komplett, bis FashionTV
# Midnight Secrets oder ab FashionTV Midnight Secrets. FashionTV Midnight
# Secrets wird im Senderstatus bewusst uebersprungen, weil der Sender aktuell
# nicht funktioniert. OXAX und .com bleiben unveraendert.
# v28: .com bleibt stabil auf v27-Basis. Zusaetzlich wird .click fuer
# Senderstatus pruefen aktiviert und nutzt dieselbe popup-arme Preflight-
# Logik wie .com: 1 Versuch, Manifest/MP4-Vorpruefung, aistr-Header und
# schnelle Fehlerklassifizierung ohne Kodi-Fehlerpopup. OXAX bleibt stabil v22.
# v44: Multi-Site-Senderstatus ruft die einzelnen Tests ohne eigenes utils.eod()
# auf und beendet das Directory nur noch einmal am Ende. Das verhindert leere
# Skin-/Container-Zustaende nach OXAX und erneutes Oeffnen des Auswahlfensters.
# .com bekommt mehr Startzeit und mehr Pause, damit langsame 1080p-Streams
# nicht mitten im Demuxer-Start gestoppt werden. .click bleibt unveraendert.
# v45: Nach jedem Senderstatus-Lauf wird der Player/alle Dialoge final
# geschlossen und Kodi per ParentDir aus dem status://select-Container zur
# normalen Add-on-Ansicht zurueckgeschickt. Dadurch bleibt kein leerer Skin
# und beim naechsten Add-on-Start oeffnet sich das Prueffenster nicht erneut.
# v46: ParentDir wurde durch Action(Back) ersetzt, damit die Custom Site nicht
# verlassen wird; .com bekam laengere Timeouts und mehrere sichtbare Kandidaten.
# v47: Der finale UI-Cleanup navigiert nicht mehr per Back/ParentDir, sondern
# beendet nur sauber Player/Dialog/Directory. Das verhindert den Rauswurf aus
# der Custom Site. Evil Angel bekommt eine langsamere Fresh-Token-Strategie,
# weil der Log zwei schnelle 404-Preflights direkt hintereinander zeigte.
# v48: .com wartet nun vor dem ersten Manifest-Test bewusst, damit frisch
# erzeugte Website-Tokens Zeit zum Aktivwerden haben. Auch zwischen Sendern
# und frischen Versuchen wird laenger pausiert. Redlight nutzt wie XY Max/Mix
# bevorzugt die bereits gepruefte Child-Playlist, weil das Master-Manifest im
# Log zweimal sofort mit EOF endete.
# v49: X Desire und FREE X duerfen ihren echten Website-MP4-Fallback nach zwei
# strengen Vorpruefungen im dritten frischen Versuch auch bei reinem Timeout
# direkt an Kodi uebergeben. Pink Erotic 2 nutzt eine gepruefte Child-Playlist
# und wird laenger sichtbar gehalten, damit ein kurzer Scheinstart nicht als
# Erfolg durchgeht und der Sender im AutoTest eindeutig kontrollierbar bleibt.
# v50: Der normale .com-Einzelstart ist wie .click selbstheilend: bis zu drei
# frische Versuche, REAL vor MP4-FALLBACK und sichtbare START/RETRY-Meldungen.
# Der .com-AutoTest meldet jeden Erfolg als REAL/FALLBACK. Nach einer Pruefung
# wird der normale Custom-Site-Hauptinhalt in den aktuellen Plugin-Container
# geschrieben, bevor eod() beendet wird; dadurch bleibt kein leerer Skin.
# v53: .click prueft wieder automatisch die komplette Site ohne Teil-Dialog
# und ohne FashionTV-Sonder-Skip. Miami TV / MiamiTV Latino bleiben Child-
# Playback-Sender, werden aber vor Kodi zusaetzlich bis zum ersten echten
# Mediensegment (inkl. AES-Key/Init-Map) geprueft. So wird ein riskanter Child
# nicht mehr an LibreELEC uebergeben und ein kompletter Player-Haenger vermieden.
# v54: Die beiden Miami-Sender leiten vom Streamlock-Master zuerst auf ein
# AWS-MediaTailor-Master weiter. v53 behandelte dieses zweite Master faelschlich
# schon als Media-Playlist und fand deshalb kein Segment. v54 folgt HLS-Mastern
# rekursiv bis zur echten Media-Playlist, liest genug Manifestdaten und prueft
# erst dort Key/Init-Map/Segment. SunBeach bleibt unveraendert.
# v55: Der Kompletttest stoppte SunBeach nach exakt 8 Sekunden, waehrend Kodis
# Demuxer den Stream erst wenige Millisekunden spaeter oeffnete. Das erzeugte
# einen Stop/Open-Race und LibreELEC blieb haengen. Die drei Streamlock-Sender
# erhalten nun Segment-Warmup, sicheren HLS-ListItem, 18 Sekunden Startzeit und
# einen einmaligen, abgewarteten Player-Stop statt doppeltem Sofort-Stopp.
# v56: .com unterscheidet jetzt jeden sichtbaren MyCam/MP4-Ersatz sauber als
# FALLBACK. Evil Angel bekommt Child- plus Segment-Preflight und gezieltes
# Schliessen von Kodi-Fehlerdialogen. Die drei Streamlock-Sender werden im
# kompletten .click-AutoTest nur noch bis zum echten Mediensegment geprueft;
# Kodi wird dort nicht gestartet, damit LibreELEC nicht erneut festhaengt.
# v57: Fallback-Provenienz wird bereits beim Auslesen gespeichert, damit ein
# MyCam-Stream auch nach Redirect/Proxy/Child-Aufloesung als FALLBACK markiert
# bleibt. Kodi-Fehlerdialoge werden nun bei COM und CLICK geschlossen. Die
# AutoTests nutzen adaptive Fast-/Safe-Zeiten: schnelle Erstversuche sind kurz,
# ein Retry erhaelt automatisch wieder die bisherigen sicheren Zeitfenster.
# Die drei Streamlock-Sonderfaelle bleiben im CLICK-AutoTest strikt SAFE-only.
OXAX_AUTOTEST_MAX_ATTEMPTS = 2
OXAX_AUTOTEST_PLAY_SECONDS = 2
OXAX_AUTOTEST_PAUSE_SECONDS = 0.8
OXAX_AUTOTEST_START_TIMEOUT = 8
OXAX_AUTOTEST_PREFETCH_ROUNDS = 3
OXAX_AUTOTEST_PREFETCH_PAUSE = 0.35
OXAX_AUTOTEST_STABLE_SECONDS = 0.8
OXAX_AUTOTEST_PREFLIGHT_TIMEOUT = 1.5

COM_AUTOTEST_MAX_ATTEMPTS = 2
COM_AUTOTEST_PLAY_SECONDS = 2
COM_AUTOTEST_PAUSE_SECONDS = 2.6
COM_AUTOTEST_INITIAL_WARMUP = 2.2
COM_AUTOTEST_RETRY_DELAY = 1.4
COM_AUTOTEST_START_TIMEOUT = 14
COM_AUTOTEST_STABLE_SECONDS = 0.8
COM_AUTOTEST_MAX_PAGES = 20
COM_AUTOTEST_MAX_CHANNELS = 250
COM_AUTOTEST_STREAM_VARIANTS = 3
COM_AUTOTEST_PREFLIGHT_TIMEOUT = 3.2
COM_AUTOTEST_OK_NOTIFICATION = True
# v57 adaptive profile: Fast path only on attempt 1. Any retry falls back to
# the proven v56 timings below, so speed does not replace reliability.
COM_AUTOTEST_FAST_WARMUP = 0.7
COM_AUTOTEST_FAST_START_TIMEOUT = 8
COM_AUTOTEST_FAST_PLAY_SECONDS = 1.2
COM_AUTOTEST_FAST_PAUSE_SECONDS = 0.8
COM_AUTOTEST_SAFE_PAUSE_SECONDS = 1.5
COM_AUTOTEST_FAILED_PAUSE_SECONDS = 0.8

# v50: Normaler .com-Einzelstart bekommt dieselbe Selbstheilung wie .click.
# Ein Benutzer-Klick darf intern frische Website-Tokens neu laden und Kodi
# erneut starten, ohne dass der Sender manuell nochmals angeklickt werden muss.
COM_PLAY_MAX_ATTEMPTS = 3
COM_PLAY_START_TIMEOUT = 14
COM_PLAY_STABLE_SECONDS = 0.8
COM_PLAY_CONFIRM_SECONDS = 0.2
COM_PLAY_RETRY_DELAY = 1.4
COM_SLOW_FRESH_RETRY_NAMES = [
    'evil angel tv online',
]
COM_SLOW_FRESH_MAX_ATTEMPTS = 4
COM_SLOW_FRESH_RETRY_DELAY = 2.8
COM_SLOW_FRESH_PREFLIGHT_WARMUP = 0.9

# v49: Diese beiden Sender zeigen auf der Website aktuell echte MP4-Videos.
# Zwei frische Versuche bleiben streng vorgeprueft; nur der dritte darf bei
# einem reinen Netzwerk-Timeout den MP4-Kandidaten browseraehnlich direkt
# an Kodi uebergeben. HTTP-Fehler bleiben weiterhin gesperrt.
COM_MP4_LAST_RESORT_NAMES = [
    'free x tv online',
    'x desire tv online',
]
COM_MP4_LAST_RESORT_MAX_ATTEMPTS = 3

# Pink Erotic 2 war laut Kodi-Log technisch gestartet, war visuell aber nicht
# eindeutig erkennbar. Direktes Child-Manifest + laengere Sichtpruefung macht
# den Test strenger und besser nachvollziehbar.
COM_CHILD_PLAYBACK_NAMES = [
    'pink erotic 2 tv online',
    # v56: Master war im Log 200/OK, der Child/Segment-Pfad erzeugte danach
    # aber zwei Kodi-Demuxer-Popups. Nur ein tief gepruefter Child darf starten.
    'evil angel tv online',
]
COM_STRICT_CHILD_SEGMENT_NAMES = [
    'evil angel tv online',
]
COM_CHILD_SEGMENT_PREFLIGHT_TIMEOUT = 3.2
COM_CHILD_SEGMENT_READ_BYTES = 65536
COM_VISIBLE_CONFIRM_NAMES = [
    'pink erotic 2 tv online',
]
COM_VISIBLE_CONFIRM_PLAY_SECONDS = 3.2

# v27: Nur eindeutig Website-seitig blockierte/Error-Sender werden fest
# uebersprungen. Gruppe 1 bleibt bewusst im Test. Zusaetzlich prueft der
# Senderstatus Medien-URLs vor Kodi. Wenn kein HLS vorhanden ist, darf eine
# echte Nicht-Werbe-.mp4 als Fallback getestet werden.
COM_KNOWN_WEBSITE_BROKEN = [
    'jasmin tv online',
    'visit-x tv online',
    'visit x tv online',
    'miami tv online',
]




def update_log(message, level=xbmc.LOGINFO):
    try:
        log('UPDATE: {}'.format(message), level)
    except Exception:
        try:
            xbmc.log('[Adult TV Test] UPDATE: {}'.format(message), level)
        except Exception:
            pass


def update_version_tuple(value):
    """Return a comparable numeric version tuple; non-numeric suffixes are ignored."""
    parts = []
    for token in re.findall(r'\d+', str(value or '')):
        try:
            parts.append(int(token))
        except Exception:
            parts.append(0)
    return tuple(parts or [0])


def update_https_get(url, timeout, max_bytes=UPDATE_MAX_BYTES):
    parsed = urlparse(str(url or ''))
    if parsed.scheme.lower() != 'https':
        raise ValueError('update URL must use HTTPS')

    request = Request(
        url,
        headers={
            'User-Agent': UA,
            'Accept': 'application/json, application/octet-stream;q=0.9, */*;q=0.8',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
        }
    )
    context = ssl.create_default_context()
    opener = build_opener(HTTPSHandler(context=context))
    with opener.open(request, timeout=max(0.5, float(timeout))) as response:
        data = response.read(int(max_bytes) + 1)
    if len(data) > int(max_bytes):
        raise ValueError('update response exceeds size limit')
    return data


def update_load_manifest():
    raw = update_https_get(UPDATE_MANIFEST_URL, UPDATE_CHECK_TIMEOUT, 256 * 1024)
    try:
        manifest = json.loads(raw.decode('utf-8-sig'))
    except Exception as exc:
        raise ValueError('invalid update.json: {}'.format(exc))

    if not isinstance(manifest, dict):
        raise ValueError('update.json root must be an object')
    if str(manifest.get('channel') or '').strip().lower() != UPDATE_CHANNEL:
        raise ValueError('unexpected update channel')

    version = str(manifest.get('version') or '').strip()
    download_url = str(manifest.get('download_url') or '').strip()
    sha256 = str(manifest.get('sha256') or '').strip().lower()
    notes = str(manifest.get('notes') or '').strip()

    if not version or not download_url:
        raise ValueError('update.json misses version/download_url')
    if not re.fullmatch(r'[0-9a-f]{64}', sha256):
        raise ValueError('update.json contains invalid sha256')

    parsed = urlparse(download_url)
    host = (parsed.hostname or '').lower()
    allowed_hosts = ('raw.githubusercontent.com', 'github.com')
    if parsed.scheme.lower() != 'https' or host not in allowed_hosts:
        raise ValueError('download_url must point to GitHub over HTTPS')
    if 'Tom-Depp/Adult-TV-Test' not in download_url:
        raise ValueError('download_url points outside expected repository')

    return {
        'version': version,
        'download_url': download_url,
        'sha256': sha256,
        'notes': notes,
    }


def update_find_installed_row():
    conn = sqlite3.connect(basics.favoritesdb)
    conn.text_factory = str
    try:
        cur = conn.cursor()
        cur.execute(
            'SELECT module_file, about, image, enabled FROM custom_sites WHERE author = ? AND name = ?',
            ('TomDepp', 'adulttvtest')
        )
        return cur.fetchone()
    finally:
        conn.close()


def update_atomic_write(path, data):
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    temp_path = path + '.update-new'
    with open(temp_path, 'wb') as handle:
        handle.write(data)
        try:
            handle.flush()
            os.fsync(handle.fileno())
        except Exception:
            pass
    os.replace(temp_path, path)


def update_install_package(package_bytes, manifest):
    expected_hash = manifest['sha256']
    actual_hash = hashlib.sha256(package_bytes).hexdigest().lower()
    if actual_hash != expected_hash:
        raise ValueError('SHA256 mismatch')

    package_buffer = io.BytesIO(package_bytes)
    with zipfile.ZipFile(package_buffer, 'r') as archive:
        bad_member = archive.testzip()
        if bad_member:
            raise ValueError('ZIP CRC failed: {}'.format(bad_member))

        try:
            meta = json.loads(archive.read('meta.json').decode('utf-8-sig'))
        except Exception as exc:
            raise ValueError('invalid meta.json: {}'.format(exc))

        if str(meta.get('name') or '') != 'adulttvtest':
            raise ValueError('package name mismatch')
        if str(meta.get('author') or '') != 'TomDepp':
            raise ValueError('package author mismatch')
        new_version = str(meta.get('version') or '').strip()
        if new_version != str(manifest['version']):
            raise ValueError('manifest/meta version mismatch')

        module_name = str(meta.get('module_name') or 'adulttvtest.py')
        if '/' in module_name or '\\' in module_name or not module_name.lower().endswith('.py'):
            raise ValueError('invalid module_name')
        module_bytes = archive.read(module_name)
        try:
            module_text = module_bytes.decode('utf-8-sig')
            compile(module_text, module_name, 'exec')
        except Exception as exc:
            raise ValueError('new Python module does not compile: {}'.format(exc))

        about_name = str(meta.get('about') or '').strip()
        about_bytes = archive.read(about_name) if about_name and about_name in archive.namelist() else None

    installed = update_find_installed_row()
    if not installed:
        raise RuntimeError('installed CUMination custom-site entry not found')

    module_file, about_stem, image_name, enabled = installed
    module_path = os.path.join(basics.customSitesDir, str(module_file) + '.py')
    about_path = os.path.join(basics.customSitesDir, str(about_stem) + '.txt') if about_stem else None
    if not os.path.isfile(module_path):
        raise RuntimeError('installed custom-site module file not found')

    module_backup = module_path + '.update-backup'
    about_backup = about_path + '.update-backup' if about_path else None
    shutil.copy2(module_path, module_backup)
    if about_path and os.path.isfile(about_path):
        shutil.copy2(about_path, about_backup)

    try:
        update_atomic_write(module_path, module_bytes)
        if about_path and about_bytes is not None:
            update_atomic_write(about_path, about_bytes)

        conn = sqlite3.connect(basics.favoritesdb)
        conn.text_factory = str
        try:
            cur = conn.cursor()
            cur.execute(
                'UPDATE custom_sites SET version = ?, title = ?, url = ? WHERE author = ? AND name = ?',
                (
                    new_version,
                    str(meta.get('title') or '[COLOR hotpink]Adult TV Test v{}[/COLOR]'.format(new_version)),
                    str(meta.get('url') or BASE_COM),
                    'TomDepp',
                    'adulttvtest',
                )
            )
            if cur.rowcount != 1:
                raise RuntimeError('custom-site database row was not updated')
            conn.commit()
        finally:
            conn.close()

        # Remove stale bytecode where possible. Failure is harmless.
        for stale in (module_path + 'o', module_path + 'c'):
            try:
                if os.path.exists(stale):
                    os.remove(stale)
            except Exception:
                pass

    except Exception:
        try:
            if os.path.isfile(module_backup):
                os.replace(module_backup, module_path)
        except Exception:
            pass
        try:
            if about_path and about_backup and os.path.isfile(about_backup):
                os.replace(about_backup, about_path)
        except Exception:
            pass
        raise
    finally:
        for backup in (module_backup, about_backup):
            if backup:
                try:
                    if os.path.isfile(backup):
                        os.remove(backup)
                except Exception:
                    pass

    return new_version


def update_offer_and_install(manifest):
    latest = manifest['version']
    notes = manifest.get('notes') or ''
    message = 'Version {} ist verfügbar.[CR]Installiert: {}.'.format(latest, SITE_VERSION)
    if notes:
        short_notes = notes[:350]
        message += '[CR][CR]{}'.format(short_notes)

    try:
        accepted = xbmcgui.Dialog().yesno(
            'Adult TV Test Update',
            message,
            nolabel='Später',
            yeslabel='Update'
        )
    except Exception as exc:
        update_log('update dialog failed: {}'.format(exc), xbmc.LOGERROR)
        return False

    if not accepted:
        update_log('user postponed version {}'.format(latest))
        return False

    progress = None
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create('Adult TV Test', 'Update v{} wird geladen …'.format(latest))
        package = update_https_get(manifest['download_url'], UPDATE_DOWNLOAD_TIMEOUT, UPDATE_MAX_BYTES)
        progress.update(55, 'Adult TV Test', 'Update v{} wird geprüft …'.format(latest))
        new_version = update_install_package(package, manifest)
        progress.update(95, 'Adult TV Test', 'Update v{} wird aktiviert …'.format(new_version))
        update_log('successfully installed version {}'.format(new_version))
        try:
            xbmcgui.Dialog().notification('Adult TV Test', 'Update auf v{} installiert'.format(new_version), xbmcgui.NOTIFICATION_INFO, 3500, False)
        except Exception:
            pass
        return True
    except Exception as exc:
        update_log('installation failed: {}'.format(exc), xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().ok('Adult TV Test Update', 'Update konnte nicht installiert werden.[CR][CR]Die bisherige Version bleibt erhalten.[CR]{}'.format(str(exc)[:500]))
        except Exception:
            pass
        return False
    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass


def update_check_on_open():
    """Check GitHub on root open. Network errors never block the custom site."""
    progress = None
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create('Adult TV Test', 'Suche nach Updates …')
        manifest = update_load_manifest()
        latest = manifest['version']
        update_log('manifest version {} | installed {}'.format(latest, SITE_VERSION))
    except Exception as exc:
        update_log('check skipped/failed: {}'.format(exc))
        return False
    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass

    if update_version_tuple(latest) <= update_version_tuple(SITE_VERSION):
        return False

    return update_offer_and_install(manifest)


def senderstatus_add_main_menu_items():
    """Render the normal custom-site root in the current plugin container."""
    site.add_dir('[COLOR hotpink]Adult-TV-Channels.com[/COLOR]', BASE_COM, 'List_COM', '')
    site.add_dir('[COLOR hotpink]Adult-TV-Channels.click[/COLOR]', BASE_CLICK, 'List_CLICK', '')
    site.add_dir('[COLOR hotpink]FuckFlix.click[/COLOR]', BASE_FUCKFLIX, 'List_FUCKFLIX', '')
    site.add_dir('[COLOR hotpink]Oxax.tv[/COLOR]', urljoin(BASE_OXAX, 'porno-kanaly.html'), 'List_OXAX', '')
    site.add_dir('[COLOR orange]Senderstatus prüfen[/COLOR]', 'status://select', 'AutoTest_SelectSites', '')


def senderstatus_between_sites_cleanup(label='Senderstatus'):
    """Small UI/player cleanup between chained site tests.

    Kodi can otherwise stay in a fullscreen/video container after the first
    test, especially with heavy skins. We do not close the final plugin
    directory here; AutoTest_SelectSites does that once at the end.
    """
    try:
        xbmc.executebuiltin('PlayerControl(Stop)')
    except Exception:
        pass

    try:
        xbmc.executebuiltin('Dialog.Close(all,true)')
    except Exception:
        pass

    # Give the skin/player a short moment to return to the normal video window.
    try:
        time.sleep(0.75)
    except Exception:
        pass

    # v47: Do not send Action(Back) even if Kodi still reports the
    # fullscreen video window. The player was already stopped above; forced
    # Back navigation can leave the custom site after the status run.
    try:
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            log('{} cleanup: fullscreen window still active after stop; leaving navigation to Kodi'.format(label))
    except Exception:
        pass

    try:
        log('{} cleanup between site tests complete'.format(label))
    except Exception:
        pass



def senderstatus_final_cleanup(label='Senderstatus', close_directory=True):
    """Finish Senderstatus and leave a populated custom-site view visible.

    Back/ParentDir can leave the custom site, while ending an empty
    status://select directory leaves Arctic Zephyr on a blank container.
    v50 therefore stops playback/dialogs, renders the normal root menu into
    the *current* directory and only then calls eod(). No forced navigation is
    needed and reopening the custom site does not reopen the test dialog.
    """
    try:
        senderstatus_between_sites_cleanup('{} final'.format(label))
    except Exception:
        pass

    if close_directory:
        try:
            senderstatus_add_main_menu_items()
            log('{} return menu rendered before eod'.format(label))
        except Exception as e:
            log('{} return menu render error: {}'.format(label, e), xbmc.LOGERROR)

        try:
            utils.eod()
        except Exception as e:
            log('{} eod error: {}'.format(label, e), xbmc.LOGERROR)

    # Do not send Back/ParentDir or close all dialogs again after eod(). The
    # populated directory should be allowed to settle naturally in the skin.
    try:
        time.sleep(0.55)
    except Exception:
        pass

    try:
        log('{} final UI cleanup complete'.format(label))
    except Exception:
        pass

COM_AD_HOST_MARKERS = [
    'mycamtv.com',
    'mycamtv',
    'mycam.tv',
]

# v58: MyCam often redirects to a neutral HLS host. The source domain then no
# longer appears in the final URL, so these known website-replacement CDNs must
# still be labelled FALLBACK. They remain playable; only the label/provenance
# changes.
COM_VISIBLE_FALLBACK_STREAM_MARKERS = [
    'mycamtv.com',
    'mycamtv',
    'mycam.tv',
    'cdn.adultiptv.net',
    'live.redtraffic.net',
    'redtraffic.net',
]

# Diese live-URLs haben im Log ein schnelles EOF erzeugt. Fuer sie testen wir
# zusaetzlich die aistr/hls-Variante, falls die Website weiterhin nur die
# stream.aistr.xyz/live-Variante ausgibt.
COM_TRY_AISTR_HLS_VARIANT_FOR = [
    # v76: current Clappr wrappers explicitly expose primary stream.aistr.xyz
    # plus backup aistr.xyz:28791.  Their browser order is preserved by the
    # dedicated decoder, so no sender should synthesize/reorder variants here.
]

CLICK_AUTOTEST_ENABLED = True
CLICK_AUTOTEST_MAX_ATTEMPTS = 3
CLICK_BABES_AUTOTEST_MAX_ATTEMPTS = 2
CLICK_AUTOTEST_PLAY_SECONDS = 1.8
CLICK_AUTOTEST_PAUSE_SECONDS = 2.6
CLICK_AUTOTEST_RETRY_DELAY = 4.5
CLICK_AUTOTEST_START_TIMEOUT = 8
CLICK_STREAMLOCK_SLOW_START_TIMEOUT = 18
CLICK_STREAMLOCK_STOP_SETTLE_SECONDS = 2.8
CLICK_AUTOTEST_STABLE_SECONDS = 1.0
CLICK_AUTOTEST_MAX_PAGES = 20
CLICK_AUTOTEST_MAX_CHANNELS = 250
CLICK_AUTOTEST_STREAM_VARIANTS = 3
CLICK_AUTOTEST_PREFLIGHT_TIMEOUT = 2.2
CLICK_AUTOTEST_PROBLEM_KODI_START_LIMIT = 1
CLICK_AUTOTEST_RATE_LIMIT_COOLDOWN = 4.5
CLICK_AUTOTEST_PREFLIGHT_REJECT_PAUSE = 0.55
CLICK_AUTOTEST_KODI_CLEANUP_PAUSE = 0.65
CLICK_AUTOTEST_VISIBLE_FALLBACK_ONLY_ON_FINAL_ATTEMPT = True
CLICK_AUTOTEST_OK_NOTIFICATION = True
# v57 adaptive profile. Known slow/popup-sensitive senders keep the full v56
# timings. Normal first attempts are shorter; retries automatically use safe.
CLICK_AUTOTEST_FAST_START_TIMEOUT = 6
CLICK_AUTOTEST_FAST_PLAY_SECONDS = 1.2
CLICK_AUTOTEST_FAST_PAUSE_SECONDS = 0.8
CLICK_AUTOTEST_SAFE_PAUSE_SECONDS = 1.5
CLICK_AUTOTEST_FAILED_PAUSE_SECONDS = 0.8
CLICK_AUTOTEST_NORMAL_RETRY_DELAY = 2.2

# v43: Normaler Einzelstart nutzt jetzt dieselbe stabile Logik wie der AutoTest:
# mehrere frische echte Versuche, Child-Playlist aus Deep-Preflight, sichtbarer
# MyCam/Redtraffic-Fallback erst am Ende. Ziel: ein einziger Benutzer-Klick soll
# intern so lange sauber vorbereiten/retryen, bis der aktuell passende Stream laeuft.
CLICK_PLAY_MAX_ATTEMPTS = 3
CLICK_PLAY_BABES_MAX_ATTEMPTS = 2
CLICK_PLAY_START_TIMEOUT = 9
CLICK_PLAY_STABLE_SECONDS = 0.8
CLICK_PLAY_CONFIRM_SECONDS = 0.2
CLICK_PLAY_RETRY_DELAY = 2.2
CLICK_PLAY_RATE_LIMIT_COOLDOWN = 4.5
CLICK_PLAY_VISIBLE_FALLBACK_ONLY_ON_FINAL_ATTEMPT = True

# v42: Sichtbarer MyCam/Redtraffic-Fallback wird im AutoTest erst im letzten Versuch erlaubt.
# Vorher werden mit frischen Tokens echte Proxy-/Aistr-Streams erneut versucht.
# Jeder OK-Sender meldet jetzt REAL/FALLBACK + Versuch/Variante per Notification und Summary.
# v33: Diagnose wieder entschärft. Nur 1 sichtbarer Versuch, weniger Kodi-Varianten
# und neueste Proxy-/Token-Varianten zuerst. Dadurch bleibt der v32-Vorteil
# erhalten, aber Kodi/LibreELEC wird nicht mehr mit zu vielen Player-Starts belastet.
# v31: .click testet echte HLS-Kandidaten mit mehreren Header-Profilen.
# Ziel: aistr.xyz-403 und externe HLS-Demuxer-Probleme abfangen, ohne
# MyCam/Redtraffic fuer nicht-strikte Karten wieder zu blockieren.
# v30: .click darf beim Senderstatus keine Werbe-Fallbacks als OK zaehlen, erlaubt aber MyCam/Redtraffic fuer nicht-strikte Karten.
# Wir holen intern bis zu zwei frische Token/Seitenlaeufe, bleiben aber bei
# einem sichtbaren Kodi-Abspielversuch pro echter HLS-Variante.
CLICK_REAL_REFRESH_PASSES = 1

# v41: .click behält v40-Timing/Babes-Fix, erlaubt aber einen sichtbaren
# Redtraffic/MyCam-Fallback NACH gescheitertem echten Proxy-/Aistr-Stream
# fuer die wechselhaften Teil-1-Sender. Fallback darf nicht zuerst starten.
# v40: .click Slow-Pause-Modus nach v39-Test. Die Website/Proxy-Ladezeiten schwanken
# sichtbar; mehr Varianten erzeugen eher 429 und Kodi-Popups. Deshalb: weniger
# Varianten, laenger auf Kodi-Start warten, laengere Pause zwischen Sendern und
# bei Proxy-429 nicht sofort weitere Profile verbraten, sondern abkuehlen lassen.
# v39: .click Stabilitaetsmodus nach v38-Test. Die Fehler sind stark wechselnd
# und haengen an Proxy-Rate-Limits (429) sowie kurzlebigen aistr-Tokens. Deshalb
# weniger Varianten, echte Pause zwischen sichtbaren Versuchen und Child-Playlist
# fuer weitere klassische TV-Sender, damit Kodi nicht nach erfolgreichem Preflight
# sofort wieder das Master-Manifest gegen den Proxy oeffnet.
# v34: Fuer kontrollierte .click-Tests kann der Senderstatus in zwei Teile
# gesplittet werden. Der Split-Punkt selbst wird uebersprungen.
CLICK_AUTOTEST_SPLIT_NAME = 'FashionTV Midnight Secrets'
CLICK_AUTOTEST_ALWAYS_SKIP_NAMES = []

# v35: Private zeigt laut aktuellem Website-Vergleich den sichtbaren MyCam/Redtraffic-HLS
# als eigentlichen Player. Deshalb darf Private diesen Fallback im Senderstatus verwenden.
CLICK_ALLOW_VISIBLE_FALLBACK_NAMES = [
    # v41: Nur als letzte Rettung nach echtem Proxy-/Aistr-Fehlschlag.
    # Diese Sender waren im v40-Log wechselhaft bzw. failed, obwohl die Website
    # laut Test entweder Stream oder sichtbares MyCam/Redtraffic-Video zeigt.
    'Private TV Online',
    'Hustler HD TV Online',
    'Playboy TV Online',
    'Redlight HD TV Online',
    'XXL TV Online',
    'Extasy4K',
    'Barely Legal TV',
]

CLICK_BABES_LEGACY_NAMES = [
    'Babes TV HD',
]

# v37: Diese Sender liefern im Log ein gueltiges Master-Manifest, Kodi scheitert
# aber beim Demuxer. Wenn der Deep-Preflight einen Child-/Media-Playlist-Pfad
# findet, wird dieser direkt an Kodi uebergeben statt des Master-Manifests.
CLICK_USE_CHILD_PLAYBACK_NAMES = [
    # v40: Child-Playlists werden nur noch sehr vorsichtig genutzt.
    # Bei adult-tv-channels-Proxy-Childs mit segment=0 wird der Child zwar
    # tief geprueft, aber nicht mehr direkt an Kodi uebergeben.
    'Babes TV HD',
    'Private TV Online',
    'Dorcel TV Online',
    'Hustler HD TV Online',
    'Playboy TV Online',
    'Redlight HD TV Online',
    'Penthouse Passion',
    'Vivid TV',
    'Extasy4K',
    # v52: Diese drei Streamlock-Master liefern im Deep-Preflight eine
    # funktionierende Child-/Media-Playlist. Kodi scheitert am Master-URL,
    # daher wird der gepruefte Child direkt gestartet.
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]

# v53: Ohne Log ist ein direkter Codec-/Demuxer-Fix nicht sicher ableitbar.
# Fuer die beiden Miami-Varianten wird deshalb konservativ vor jedem Kodi-Start
# auch der erste echte Medienbaustein geprueft. Erst wenn Child, Key/Init-Map
# und Segment erreichbar sind, darf LibreELEC den Stream oeffnen.
CLICK_STREAMLOCK_SLOW_START_NAMES = [
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]

CLICK_CHILD_SEGMENT_PREFLIGHT_NAMES = [
    # v55: SunBeach bekommt denselben echten Segment-Warmup wie die Miami-
    # Sender. Im Kompletttest war das Manifest bereits OK, der Demuxer brauchte
    # aber knapp laenger als das alte 8-Sekunden-Limit.
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]
# v56: Im kompletten AutoTest reicht fuer diese bekannten Streamlock-Sender
# der bereits strenge Master->Child->Key/Init->Segment-Test. Einzelstarts
# bleiben echte Kodi-Wiedergaben; nur der Massentest vermeidet den Hang.
CLICK_AUTOTEST_PREFLIGHT_ONLY_NAMES = [
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]
CLICK_CHILD_SEGMENT_PREFLIGHT_TIMEOUT = 2.8
CLICK_NESTED_HLS_MAX_DEPTH = 4
CLICK_NESTED_HLS_READ_BYTES = 65536
CLICK_SAFE_HLS_LISTITEM_NAMES = [
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]

# Sender aus obiger Liste bekommen weiterhin ein schmales Header-Profil.
# v39: Weitere klassische TV-Sender bekommen den schlanken Pfad: nur
# page+origin als Kodi-Start, aber bei Bedarf ein zweiter sichtbarer Versuch
# nach laengerer Pause. Das reduziert 429-Spitzen gegen den Website-Proxy.
CLICK_SINGLE_KODI_START_NAMES = [
    'Babes TV HD',
    'Private TV Online',
    'CentoXCento TV',
    'Cento X Cento TV',
    'Dorcel TV Online',
    'Hustler HD TV Online',
    'Playboy TV Online',
    'Pinko Club TV',
    'Redlight HD TV Online',
    'Penthouse Passion',
    'Vivid TV',
    'XXL TV Online',
    'SuperONE TV',
    'Passion XXX TV',
    'Extasy4K',
    'Barely Legal TV',
    # v55: Streamlock-Sender nur mit einem schmalen Kodi-Profil pro frischem
    # Versuch. Dadurch wird nach einem langsamen Start nicht sofort dieselbe URL
    # mit zwei weiteren Header-Varianten parallel nachgeschoben.
    'SunBeach TV',
    'Miami TV',
    'MiamiTV Latino',
]

CLICK_AD_STREAM_MARKERS = [
    # Echte Werbe-/Tinder-/MP4-Fallbacks bleiben global gesperrt.
    # Redtraffic/MyCam werden NICHT global gesperrt, weil viele .click-Seiten
    # laut Website-Vergleich genau darueber ihr aktuelles HLS-Video ausliefern.
    'tsyndicate.com',
    'cdn.tsyndicate.com',
    'svacdn.tsyndicate.com',
    'cdnproxy.tsyndicate.com',
    'tinder',
]

# v33: Diese HLS-Fallbacks koennen Kodi/LE beim schnellen Senderstatus hart aufhaengen.
# Deshalb nur im Senderstatus nicht an Kodi uebergeben. Andere Redtraffic-Streams
# bleiben erlaubt, weil sie auf .click oft die aktuell sichtbaren Website-Videos sind.
CLICK_SENDERSTATUS_DANGEROUS_HLS_MARKERS = [
    'live.redtraffic.net/livecams.m3u8',
]

CLICK_STRICT_AD_STREAM_MARKERS = [
    'live.redtraffic.net',
    'redtraffic.net',
    'mycamtv.com',
    'mycamtv',
    'mycam.tv',
]

# Bei diesen klassischen TV-Sendern ist ein MyCam/Redtraffic/Ad-Stream laut
# Website-Vergleich ein falscher Fallback und darf nicht als OK zaehlen. Andere
# .click-Karten, die auf der Website selbst MyCam/Redtraffic zeigen, bleiben
# damit wieder testbar.
CLICK_STRICT_TV_STREAM_NAMES = [
    'brazzers tv online',
    'hustler tv',
    'private tv online',
    'centoxcento tv',
    'cento x cento tv',
    'hustler hd tv online',
    'dorcel tv online',
    'playboy tv online',
    'pinko club tv',
    'redlight hd tv online',
    'penthouse passion',
    'penthouse passion tv online',
    'penthouse tv online',
    'vivid tv',
    'vivid tv online',
    'superone tv',
    'superone tv online',
    'passion xxx tv',
    'penthouse reality tv',
    'extasy4k',
    'evil angel',
    'babes tv hd',
    'eroxxx hd tv online',
    'sunbeach tv',
]


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[Adult TV Test] {}'.format(msg), level)
    except Exception:
        pass


def notify(msg, error=False):
    try:
        icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification('Adult TV Test', msg, icon, 5000)
    except Exception:
        pass


def senderstatus_reopen_progress(progress, heading, message, percent=0, log_prefix='Senderstatus'):
    """Recreate Kodi's modal progress dialog so it stays visible per sender.

    Kodi normally closes DialogProgress when video playback opens. Calling
    update() on that already closed Python object does not make the window
    visible again. Recreating it before and after every sender keeps the user
    informed without keeping a modal overlay on top of the playing video.
    """
    try:
        if progress:
            progress.close()
    except Exception:
        pass

    try:
        time.sleep(0.08)
        progress = xbmcgui.DialogProgress()
        progress.create(str(heading or 'Senderstatus prüfen'), str(message or 'Bitte warten...'))
        try:
            progress.update(int(max(0, min(100, percent or 0))), str(message or 'Bitte warten...'))
        except Exception:
            pass
        log('{} progress dialog recreated'.format(log_prefix))
        return progress
    except Exception as e:
        log('{} progress dialog recreate error: {}'.format(log_prefix, e), xbmc.LOGERROR)
        return None


def clean_text(text):
    text = text or ''
    text = re.sub(r'<[^>]+>', '', text)
    text = html_unescape(text)
    return utils.cleantext(text).strip()


def browser_get(opener, url, referer=None, accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'):
    headers = {
        'User-Agent': UA,
        'Accept': accept,
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
    }

    if referer:
        headers['Referer'] = referer

    req = Request(url, headers=headers)
    return opener.open(req, timeout=25).read().decode('utf-8', 'ignore')


def browser_post(opener, url, referer, origin):
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': origin.rstrip('/'),
        'Referer': referer,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
    }

    req = Request(url, data=b'', headers=headers)
    return opener.open(req, timeout=25).read().decode('utf-8', 'ignore')


def kodi_stream_headers(streamurl, referer, origin, extra_headers=None):
    headers = {
        'User-Agent': UA,
        'Referer': referer,
        'Origin': origin.rstrip('/'),
    }

    if extra_headers:
        headers.update(extra_headers)

    return streamurl + '|' + urlencode(headers)


def cookie_header(cj):
    try:
        parts = []

        for cookie in cj:
            if cookie.name and cookie.value is not None:
                parts.append('{}={}'.format(cookie.name, cookie.value))

        return '; '.join(parts)
    except Exception:
        return ''


def unwrap_click_proxy_url(streamurl):
    streamurl = html_unescape(streamurl or '').replace('\\/', '/')

    if not streamurl:
        return streamurl

    try:
        parsed = urlparse(streamurl)

        if 'adult-tv-channels.click' in parsed.netloc and 'url=' in parsed.query:
            qs = parse_qs(parsed.query)
            inner = qs.get('url', [''])[0]

            if inner:
                inner = unquote(inner)

                if '.m3u8' in inner:
                    log('CLICK proxy unwrapped to direct HLS URL')
                    return inner
    except Exception as e:
        log('CLICK proxy unwrap error: {}'.format(e), xbmc.LOGERROR)

    # Fallback fuer HTML/JSON-Strings, bei denen parse_qs wegen Sonderzeichen nicht greift.
    match = re.search(r'[?&]url=([^&]+)', streamurl)

    if match:
        inner = unquote(match.group(1))

        if '.m3u8' in inner:
            log('CLICK proxy unwrapped to direct HLS URL')
            return inner

    return streamurl


def json_find_stream_url(value):
    """Find the first usable HLS URL in nested JSON responses."""
    try:
        if isinstance(value, str):
            value = html_unescape(value).replace('\\/', '/')

            if '.m3u8' in value:
                match = re.search(r'https?://[^\s"\'<>]+?\.m3u8[^\s"\'<>]*', value, re.IGNORECASE)
                if match:
                    return match.group(0)

            return ''

        if isinstance(value, dict):
            preferred = [
                'fileUrl', 'fileURL', 'file_url', 'hls', 'hlsUrl', 'hls_url',
                'stream', 'streamUrl', 'stream_url', 'src', 'source', 'url', 'file'
            ]

            for key in preferred:
                if key in value:
                    found = json_find_stream_url(value.get(key))
                    if found:
                        return found

            for item in value.values():
                found = json_find_stream_url(item)
                if found:
                    return found

        if isinstance(value, (list, tuple)):
            for item in value:
                found = json_find_stream_url(item)
                if found:
                    return found
    except Exception:
        return ''

    return ''


def site_extract_explicit_file_urls(document, baseurl=''):
    """Extract direct or encoded fileUrl values from JSON responses."""
    found = []
    seen = set()
    try:
        parsed = json.loads(document or '')
    except Exception:
        parsed = None

    def add(value):
        if not isinstance(value, str):
            return
        value = html_unescape(value or '').replace('\\/', '/').strip()
        if not value:
            return
        try:
            value = unquote(value)
        except Exception:
            pass
        if not value.lower().startswith(('http://', 'https://')):
            try:
                decoded = fuckflix_decode_api_file_url(value)
            except Exception:
                decoded = ''
            if decoded:
                value = decoded
        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith('/'):
            value = urljoin(baseurl, value)
        if not value.lower().startswith(('http://', 'https://')):
            return
        if value in seen:
            return
        seen.add(value)
        found.append(value)

    def walk(obj):
        if isinstance(obj, dict):
            for key, child in obj.items():
                normalized = re.sub(r'[^a-z0-9]', '', str(key).lower())
                if normalized in ('fileurl', 'hlsurl', 'streamurl'):
                    add(child)
                if isinstance(child, (dict, list, tuple)):
                    walk(child)
        elif isinstance(obj, (list, tuple)):
            for child in obj:
                walk(child)

    if parsed is not None:
        walk(parsed)
    return found


def site_dynamic_api_stream_candidates(opener, document, page_url, name='', label='SITE', force_external_scripts=False):
    """Resolve current playerConfig/dynamic fetch APIs before any fallback.

    adult-tv-channels.click/.com can expose only MyCam/Redtraffic statically
    while the browser obtains the real TV stream through JavaScript. This uses
    the already-proven FuckFlix JS endpoint parser, but keeps site-specific
    origin/referer and returns only media URLs. It is intentionally marker-
    gated so old/static pages do not incur extra network calls.
    """
    decoded = html_unescape(document or '').replace('\\/', '/')
    marker_l = decoded.lower()
    has_inline_markers = any(marker in marker_l for marker in (
        'playerconfig', 'apiurl', 'api_url', 'fileurl', 'fetch(', '$.post', '$.ajax', 'xmlhttprequest'
    ))
    if not has_inline_markers and not force_external_scripts:
        return []

    try:
        page_vars = fuckflix_extract_js_string_variables(decoded, page_url)
        endpoints = []
        config_endpoints, configs = fuckflix_extract_player_config_endpoints(decoded, page_url)
        for endpoint in config_endpoints:
            if endpoint not in endpoints:
                endpoints.append(endpoint)
        for endpoint in fuckflix_extract_request_endpoints(decoded, page_url, seed_variables=page_vars):
            if endpoint not in endpoints:
                endpoints.append(endpoint)

        # If the page only exposes config variables, inspect likely external
        # player JS once (cached by URL) and resolve it with the page variables.
        if not endpoints:
            try:
                script_urls = fuckflix_extract_script_urls(decoded, page_url)
            except Exception:
                script_urls = []
            for script_url in script_urls:
                if str(label or '').upper() == 'COM' and any(marker in (script_url or '').lower() for marker in (
                    'jwplayer8.js', 'jwpcdn.com/player/'
                )):
                    log('COM dynamic API scan skipping JWPlayer library: {}'.format(script_url))
                    continue
                try:
                    script_body = fuckflix_get_script_cached(opener, script_url, page_url)
                except Exception:
                    script_body = ''
                if not script_body:
                    continue
                for endpoint in fuckflix_extract_request_endpoints(
                    script_body, page_url, seed_variables=page_vars
                ):
                    if endpoint not in endpoints:
                        endpoints.append(endpoint)

        if not endpoints:
            log('{} dynamic player markers found but no endpoint resolved for {}'.format(label, name))
            return []

        origin = click_stream_origin(page_url) or page_url.split('/', 3)[:3]
        if isinstance(origin, list):
            origin = '/'.join(origin)
        streams = []
        seen = set()
        for endpoint_url, method in endpoints[:10]:
            try:
                if str(method or 'GET').upper() == 'POST':
                    response = fuckflix_http_post(opener, endpoint_url, page_url, origin)
                else:
                    response = browser_get(opener, endpoint_url, page_url, accept='application/json,text/plain,*/*')
            except Exception as e:
                log('{} dynamic endpoint error for {} | {} {}: {}'.format(label, name, method, endpoint_url, e), xbmc.LOGERROR)
                continue

            candidates = []
            direct = json_find_stream_url(response)
            if direct:
                candidates.append(direct)
            candidates.extend(site_extract_explicit_file_urls(response, endpoint_url))
            candidates.extend(extract_m3u8_candidates(response, endpoint_url))

            for streamurl in candidates:
                streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
                if streamurl and streamurl not in seen:
                    seen.add(streamurl)
                    streams.append(streamurl)
                    log('{} dynamic REAL candidate for {}: {}'.format(label, name, streamurl))

        return streams
    except Exception as e:
        log('{} dynamic player discovery error for {}: {}'.format(label, name, e), xbmc.LOGERROR)
        return []


def configure_xlivetv_isa_item(item, referer, origin, log_prefix='SITE'):
    """Configure Kodi 22 InputStream Adaptive for an extensionless XLivetv token."""
    try:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)
        headers = {
            'User-Agent': FUCKFLIX_UA,
            'Accept': '*/*',
        }
        if referer:
            headers['Referer'] = referer
        if origin:
            headers['Origin'] = origin.rstrip('/')
        encoded = urlencode(headers)
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.common_headers', encoded)
        item.setProperty('inputstream.adaptive.manifest_headers', encoded)
        item.setProperty('inputstream.adaptive.stream_headers', encoded)
        log('{} XLivetv InputStream Adaptive enabled | referer={} | origin={}'.format(
            log_prefix, referer or '-', origin or '-'
        ))
        return True
    except Exception as e:
        log('{} XLivetv ISA setup warning: {}'.format(log_prefix, e), xbmc.LOGWARNING)
        return False


def extract_m3u8_candidates(html, baseurl):
    html = html_unescape(html or '').replace('\\/', '/')

    # Wichtig:
    # Auskommentierte alte Player-Bloecke entfernen,
    # sonst kann z. B. ein alter JWPlayer signedUrl vor dem aktiven PlayerJS gefunden werden.
    html_active = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)

    patterns = [
        # Aktiver PlayerJS:
        # new Playerjs({id:"player", file:"https://.../playlist.m3u8?e=...&st=..."});
        r'new\s+Playerjs\s*\(\s*\{.*?file\s*:\s*["\']([^"\']+?\.m3u8[^"\']*)["\']',

        # PlayerJS / allgemeines JS-Objekt:
        # file:"https://...m3u8..."
        r'file\s*:\s*["\']([^"\']+?\.m3u8[^"\']*)["\']',

        # Aktiver JWPlayer:
        # const signedUrl = "https://.../playlist.m3u8?e=...&st=..."
        r'const\s+signedUrl\s*=\s*["\']([^"\']+?\.m3u8[^"\']*)["\']',

        # source/src Fallback
        r'src\s*:\s*["\']([^"\']+?\.m3u8[^"\']*)["\']',

        # Letzter Fallback: irgendeine direkte m3u8 im aktiven HTML
        r'(https?://[^"\']+?\.m3u8[^"\']*)',
    ]

    candidates = []
    seen = set()

    def add(url):
        url = html_unescape(url or '').replace('\\/', '/').strip()
        if not url:
            return
        url = urljoin(baseurl, url)
        if url not in seen:
            seen.add(url)
            candidates.append(url)

    for pattern in patterns:
        for match in re.finditer(pattern, html_active, re.IGNORECASE | re.DOTALL):
            add(match.group(1))

    # Notfall-Fallback:
    # Falls wirklich nur ein auskommentierter Block vorhanden waere.
    if not candidates:
        for match in re.finditer(r'(https?://[^"\']+?\.m3u8[^"\']*)', html, re.IGNORECASE | re.DOTALL):
            add(match.group(1))

    return candidates


def extract_m3u8(html, baseurl):
    candidates = extract_m3u8_candidates(html, baseurl)
    return candidates[0] if candidates else None


def extract_mp4_candidates(html, baseurl):
    html = html_unescape(html or '').replace('\\/', '/')

    # Auskommentierte alte Player-Bloecke ignorieren, damit nicht irgendein
    # alter Demo- oder Werbe-Clip gewinnt.
    html_active = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)

    patterns = [
        r'new\s+Playerjs\s*\(\s*\{.*?file\s*:\s*["\']([^"\']+?\.mp4(?:\?[^"\']*)?)["\']',
        r'file\s*:\s*["\']([^"\']+?\.mp4(?:\?[^"\']*)?)["\']',
        r'<source[^>]+src=["\']([^"\']+?\.mp4(?:\?[^"\']*)?)["\']',
        r'<video[^>]+src=["\']([^"\']+?\.mp4(?:\?[^"\']*)?)["\']',
        r'src\s*[:=]\s*["\']([^"\']+?\.mp4(?:\?[^"\']*)?)["\']',
        r'(https?://[^"\'<>\s]+?\.mp4(?:\?[^"\'<>\s]*)?)',
    ]

    candidates = []
    seen = set()

    def add(url):
        url = html_unescape(url or '').replace('\\/', '/').strip()
        if not url:
            return
        url = urljoin(baseurl, url)
        if url not in seen:
            seen.add(url)
            candidates.append(url)

    for pattern in patterns:
        for match in re.finditer(pattern, html_active, re.IGNORECASE | re.DOTALL):
            add(match.group(1))

    return candidates


def com_extract_real_media_candidates(html, baseurl, name=''):
    # HLS bleibt der bevorzugte Live-TV-Kandidat. v46 gibt aber auch MP4-
    # Kandidaten als letzte Fallback-Variante zurueck, falls die Website zwar
    # zuerst einen kaputten HLS-Token liefert, sichtbar aber ein anderes
    # Player-/MyCam-aehnliches Video laeuft.
    hls = [u for u in extract_m3u8_candidates(html, baseurl) if not com_is_ad_stream_url(u)]
    mp4 = [u for u in extract_mp4_candidates(html, baseurl) if not com_is_ad_stream_url(u)]

    candidates = []
    for url in hls + mp4:
        if url and url not in candidates:
            candidates.append(url)

    if hls and mp4:
        log('COM media fallback: HLS + MP4 candidate(s) for {}: {} + {}'.format(name, len(hls), len(mp4)))
        return candidates, 'hls+mp4'

    if hls:
        return candidates, 'hls'

    if mp4:
        log('COM media fallback: MP4 candidate(s) for {}: {}'.format(name, len(mp4)))
        return candidates, 'mp4'

    return [], ''


def com_text_has_ad_host(text):
    text = (text or '').lower()
    return any(marker in text for marker in COM_AD_HOST_MARKERS)


def com_is_ad_stream_url(streamurl):
    return com_text_has_ad_host(streamurl)


def com_is_visible_fallback_stream(streamurl, iframeurl='', iframehtml=''):
    """Website-visible replacement video, even after neutral redirects."""
    combined = '{} {} {}'.format(streamurl or '', iframeurl or '', iframehtml or '').lower()
    if '.mp4' in combined:
        return True
    if any(marker in combined for marker in COM_VISIBLE_FALLBACK_STREAM_MARKERS):
        return True
    return False


def com_is_mycam_fallback_stream(streamurl, iframeurl='', iframehtml=''):
    """Only MyCam/Redtraffic-style replacement streams, excluding MP4."""
    combined = '{} {} {}'.format(streamurl or '', iframeurl or '', iframehtml or '').lower()
    return any(marker in combined for marker in COM_VISIBLE_FALLBACK_STREAM_MARKERS)


def com_is_known_real_stream(streamurl):
    decoded = unquote((streamurl or '').lower())
    return (
        fuckflix_is_api_gateway_url(streamurl)
        or any(marker in decoded for marker in (
            'aistr.xyz', 'streamlock.net', 'webtvstream.bhtelecom.ba',
            'skygo.mn', 'akamaized.net', 'mediatailor.'
        ))
    )


def com_prepared_item(finalurl, streamurl, iframeurl, source_kind='real'):
    return (finalurl, streamurl, iframeurl, source_kind or 'real')


def com_unpack_prepared(item):
    try:
        if len(item) >= 4:
            finalurl, streamurl, iframeurl, source_kind = item[:4]
        else:
            finalurl, streamurl, iframeurl = item[:3]
            source_kind = 'visible_fallback' if com_is_visible_fallback_stream(streamurl, iframeurl) else 'real'
    except Exception:
        finalurl, streamurl, iframeurl, source_kind = '', '', '', 'real'
    return finalurl, streamurl, iframeurl, source_kind


def com_extract_visible_fallback_candidates(html, baseurl):
    """Collect only MyCam-visible media, never generic ad iframes."""
    candidates = []
    seen = set()
    base_is_mycam = com_text_has_ad_host(baseurl)

    for url in extract_m3u8_candidates(html, baseurl) + extract_mp4_candidates(html, baseurl):
        url = html_unescape(url or '').replace('\\/', '/').strip()
        if not url:
            continue
        url = urljoin(baseurl, url)
        if not (base_is_mycam or com_text_has_ad_host(url)):
            continue
        if url in seen:
            continue
        seen.add(url)
        candidates.append(url)

    return candidates


def click_normalize_name(name):
    name = clean_text(name or '').lower()
    name = name.replace('&amp;', '&')
    name = re.sub(r'[^a-z0-9а-яё]+', ' ', name, flags=re.IGNORECASE)
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def click_name_in_list(name, items):
    n = click_normalize_name(name)
    if not n:
        return False

    for item in items:
        i = click_normalize_name(item)
        if i and (n == i or i in n or n in i):
            return True

    return False


def click_allows_visible_fallback(name):
    return click_name_in_list(name, CLICK_ALLOW_VISIBLE_FALLBACK_NAMES)


def click_is_babes_legacy_name(name):
    return click_name_in_list(name, CLICK_BABES_LEGACY_NAMES)


def click_uses_child_playback(name):
    return click_name_in_list(name, CLICK_USE_CHILD_PLAYBACK_NAMES)


def click_requires_child_segment_preflight(name):
    return click_name_in_list(name, CLICK_CHILD_SEGMENT_PREFLIGHT_NAMES)


def click_autotest_is_preflight_only(name):
    return click_name_in_list(name, CLICK_AUTOTEST_PREFLIGHT_ONLY_NAMES)


def click_uses_safe_hls_listitem(name):
    return click_name_in_list(name, CLICK_SAFE_HLS_LISTITEM_NAMES)


def click_single_kodi_start_name(name):
    return click_name_in_list(name, CLICK_SINGLE_KODI_START_NAMES)


def click_is_strict_tv_name(name):
    if click_allows_visible_fallback(name):
        return False
    return click_name_in_list(name, CLICK_STRICT_TV_STREAM_NAMES)


def click_is_babes_skygo_stream(streamurl):
    decoded = unquote((streamurl or '').lower())
    return 'cdn4.skygo.mn' in decoded and '/babes/hlsv3-fta/babes' in decoded


def click_is_babes_legacy_noext_stream(streamurl):
    decoded = unquote((streamurl or '').lower()).split('?', 1)[0].rstrip('/')
    return click_is_babes_skygo_stream(decoded) and not decoded.endswith('.m3u8')


def click_is_visible_fallback_stream(streamurl):
    decoded = unquote((streamurl or '').lower())
    return any(marker in decoded for marker in ('live.redtraffic.net', 'redtraffic.net', 'mycamtv.com', 'mycam.tv', 'mycamtv'))


def click_text_has_ad_host(text, name=''):
    t = (text or '').lower()

    # v71: MyCam/Redtraffic ist auf adult-tv-channels.click global ein falscher
    # Ersatzstream. Die Website kann parallel einen REAL-Stream dynamisch laden;
    # deshalb darf dieser statische Fallback nie den REAL-Pfad gewinnen.
    if '.mp4' in t:
        return True
    if any(marker in t for marker in CLICK_AD_STREAM_MARKERS):
        return True
    if any(marker in t for marker in CLICK_STRICT_AD_STREAM_MARKERS):
        return True
    return False


def click_is_ad_stream_url(streamurl, name=''):
    return click_text_has_ad_host(streamurl, name)


def click_is_senderstatus_dangerous_stream(streamurl, name=''):
    lower = (streamurl or '').lower()
    decoded = unquote(lower)
    for marker in CLICK_SENDERSTATUS_DANGEROUS_HLS_MARKERS:
        if marker and marker.lower() in decoded:
            return True
    return False


def click_name_matches(name, target):
    n = click_normalize_name(name)
    t = click_normalize_name(target)
    return bool(n and t and (n == t or t in n or n in t))


def click_is_streamlock_slow_start_name(name):
    return any(click_name_matches(name, item) for item in CLICK_STREAMLOCK_SLOW_START_NAMES)


def click_autotest_uses_safe_profile(name, attempt=1):
    return (
        attempt > 1
        or click_is_streamlock_slow_start_name(name)
        or click_single_kodi_start_name(name)
        or click_is_babes_legacy_name(name)
    )


def click_autotest_start_timeout_for_name(name, attempt=1):
    if click_is_streamlock_slow_start_name(name):
        return CLICK_STREAMLOCK_SLOW_START_TIMEOUT
    if click_autotest_uses_safe_profile(name, attempt):
        return CLICK_AUTOTEST_START_TIMEOUT
    return CLICK_AUTOTEST_FAST_START_TIMEOUT


def click_autotest_play_seconds_for_name(name, attempt=1, play_streamurl=''):
    if click_is_visible_fallback_stream(play_streamurl) or click_autotest_uses_safe_profile(name, attempt):
        return float(CLICK_AUTOTEST_PLAY_SECONDS)
    return float(CLICK_AUTOTEST_FAST_PLAY_SECONDS)


def click_autotest_retry_delay_for_name(name):
    if click_single_kodi_start_name(name) or click_is_babes_legacy_name(name) or click_is_streamlock_slow_start_name(name):
        return float(CLICK_AUTOTEST_RETRY_DELAY)
    return float(CLICK_AUTOTEST_NORMAL_RETRY_DELAY)


def click_play_start_timeout_for_name(name):
    if click_is_streamlock_slow_start_name(name):
        return CLICK_STREAMLOCK_SLOW_START_TIMEOUT
    return CLICK_PLAY_START_TIMEOUT


def click_should_skip_senderstatus(name):
    for item in CLICK_AUTOTEST_ALWAYS_SKIP_NAMES:
        if click_name_matches(name, item):
            return True
    return False


def click_split_index(channels):
    for idx, (name, _url, _img) in enumerate(channels):
        if click_name_matches(name, CLICK_AUTOTEST_SPLIT_NAME):
            return idx
    return -1


def click_select_senderstatus_range(channels):
    """v53: Always test the complete .click site without a range dialog."""
    if not channels:
        return channels, 'Alle Sender'
    return channels, 'Komplette Site'


def com_extract_iframe_urls(html, page_url):
    """Extract normal and lazy-loaded iframe/player URLs from .com pages."""
    html = html_unescape(html or '').replace('\\/', '/')
    urls = []
    seen = set()

    for tag_match in re.finditer(r'<iframe\b[^>]*>', html, re.IGNORECASE | re.DOTALL):
        tag = tag_match.group(0)
        # Prefer the real src, then common lazy/player attributes.
        for attr in ('src', 'data-src', 'data-lazy-src', 'data-url', 'data-embed', 'data-player'):
            match = re.search(r'\b' + re.escape(attr) + r'\s*=\s*["\']([^"\']+)["\']', tag, re.IGNORECASE | re.DOTALL)
            if not match:
                continue
            raw = html_unescape(match.group(1)).strip()
            if not raw or raw.lower().startswith(('javascript:', 'data:', 'about:blank')):
                continue
            iframeurl = urljoin(page_url, raw)
            if iframeurl and iframeurl not in seen:
                seen.add(iframeurl)
                urls.append(iframeurl)
            break

    return urls


def com_diagnostic_document_summary(name, document, document_url, depth=0):
    """Compact player diagnostics for one .com sender/iframe document."""
    decoded = html_unescape(document or '').replace('\\/', '/')
    lower = decoded.lower()
    iframe_urls = com_extract_iframe_urls(decoded, document_url)
    script_urls = re.findall(r'<script\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']', decoded, re.IGNORECASE | re.DOTALL)
    script_urls = [urljoin(document_url, html_unescape(item).strip()) for item in script_urls if item.strip()]
    markers = {
        'm3u8': len(re.findall(r'\.m3u8', lower)),
        'mp4': len(re.findall(r'\.mp4', lower)),
        'playerconfig': len(re.findall(r'playerconfig', lower)),
        'apiurl': len(re.findall(r'api[_-]?url|apiurl', lower)),
        'fileurl': len(re.findall(r'file[_-]?url|fileurl', lower)),
        'fetch': len(re.findall(r'\bfetch\s*\(', lower)),
        'xhr': len(re.findall(r'xmlhttprequest', lower)),
        'playerjs': len(re.findall(r'playerjs', lower)),
        'jwplayer': len(re.findall(r'jwplayer', lower)),
        'videojs': len(re.findall(r'videojs', lower)),
        'atob': len(re.findall(r'\batob\s*\(', lower)),
        'eval': len(re.findall(r'\beval\s*\(', lower)),
        'aistr': len(re.findall(r'aistr\.xyz', lower)),
        'xlivetv': len(re.findall(r'xlivetv\.com', lower)),
        'mycam': len(re.findall(r'mycam|redtraffic', lower)),
    }
    log('COM diagnostic document for {} depth={} | url={} | bytes={} | iframes={} | scripts={} | m3u8={} | mp4={} | playerConfig={} | apiUrl={} | fileUrl={} | fetch={} | xhr={} | Playerjs={} | jwplayer={} | videojs={} | atob={} | eval={} | aistr={} | xlivetv={} | mycam={}'.format(
        name, depth, document_url, len(decoded), len(iframe_urls), len(script_urls),
        markers['m3u8'], markers['mp4'], markers['playerconfig'], markers['apiurl'], markers['fileurl'],
        markers['fetch'], markers['xhr'], markers['playerjs'], markers['jwplayer'], markers['videojs'],
        markers['atob'], markers['eval'], markers['aistr'], markers['xlivetv'], markers['mycam']
    ))
    if iframe_urls:
        log('COM diagnostic iframe URLs for {} depth={}: {}'.format(name, depth, ' | '.join(iframe_urls[:8])))
    if script_urls:
        log('COM diagnostic script URLs for {} depth={}: {}'.format(name, depth, ' | '.join(script_urls[:10])))
    return iframe_urls


def com_jwplayer_context_diagnostics(name, document, document_url, depth=0):
    """Log compact source context around the current .com JWPlayer wrapper."""
    decoded = html_unescape(document or '').replace('\\/', '/')
    lower = decoded.lower()
    if 'jwplayer' not in lower:
        return

    markers = ('jwplayer', '.setup', 'file:', 'file =', 'sources', 'playlist', 'source:')
    emitted = 0
    seen = set()
    for marker in markers:
        start = 0
        while emitted < 8:
            pos = lower.find(marker.lower(), start)
            if pos < 0:
                break
            left = max(0, pos - 220)
            right = min(len(decoded), pos + 420)
            snippet = re.sub(r'\s+', ' ', decoded[left:right]).strip()
            key = snippet[:220]
            if key not in seen:
                seen.add(key)
                log('COM JWPlayer context for {} depth={} | {}: {}'.format(
                    name, depth, marker, snippet[:700]
                ))
                emitted += 1
            start = pos + len(marker)

    try:
        variables = fuckflix_extract_js_string_variables(decoded, document_url)
    except Exception:
        variables = {}
    interesting = []
    for var_name, value in variables.items():
        if not isinstance(value, str):
            continue
        lname = str(var_name).lower()
        lvalue = value.lower()
        if (
            any(token in lname for token in ('file', 'src', 'source', 'stream', 'url', 'playlist', 'hls', 'token'))
            or 'http://' in lvalue or 'https://' in lvalue or '/live/' in lvalue or '/hls/' in lvalue
        ):
            clean = re.sub(r'\s+', ' ', value).strip()
            interesting.append('{}={}'.format(var_name, clean[:300]))
    if interesting:
        log('COM JWPlayer variables for {} depth={}: {}'.format(
            name, depth, ' | '.join(interesting[:12])
        ))



def com_active_player_context_diagnostics(name, document, document_url, depth=0):
    """Log compact active Playerjs/Clappr/XOR context for COM diagnostics."""
    decoded = html_unescape(document or '').replace('\\/', '/')
    active = re.sub(r'<!--.*?-->', '', decoded, flags=re.DOTALL)
    lower = active.lower()
    markers = (
        'playerjs', 'new playerjs', 'clappr', 'new clappr.player',
        'source:', 'source =', 'file:(function', 'source:(function',
        'string.fromcharcode', 'var k=', 'playlist:'
    )
    if not any(marker in lower for marker in markers):
        return

    emitted = 0
    seen = set()
    for marker in markers:
        start = 0
        while emitted < 10:
            pos = lower.find(marker, start)
            if pos < 0:
                break
            left = max(0, pos - 260)
            right = min(len(active), pos + 620)
            snippet = re.sub(r'\s+', ' ', active[left:right]).strip()
            key = snippet[:260]
            if key not in seen:
                seen.add(key)
                log('COM active player context for {} depth={} | {}: {}'.format(
                    name, depth, marker, snippet[:900]
                ))
                emitted += 1
            start = pos + len(marker)


def com_extract_clappr_xor_url_object_candidates(document, document_url='', name=''):
    """Decode current COM Clappr urls.primary / urls.backup XOR wrappers.

    Current /tv/*.php wrappers use a small object such as:
      const urls = {"primary":(function(){...XOR...})(),
                    "backup":(function(){...XOR...})()};
      const primaryUrl = urls.primary;   // or urls.backup
      const backupUrl = urls.backup;
      new Clappr.Player({source: primaryUrl, ...});

    v77 fixes the v76 regex escaping bug and, importantly, follows the active
    primaryUrl/backupUrl assignments from the current page.  Some wrappers
    (Redlight in log 71(2)) deliberately assign primaryUrl = urls.backup, so
    blindly forcing primary before backup would no longer match the website.
    Only the narrow numeric-array XOR IIFEs are reproduced; arbitrary
    JavaScript is never evaluated.
    """
    decoded = html_unescape(document or '').replace('\\/', '/')
    active = re.sub(r'<!--.*?-->', '', decoded, flags=re.DOTALL)
    lower = active.lower()
    if 'clappr' not in lower or 'const urls' not in lower or 'primaryurl' not in lower:
        return []

    pattern = re.compile(
        r'["\']?(primary|backup)["\']?\s*:\s*'
        r'\(\s*function\s*\(\s*\)\s*\{\s*'
        r'var\s+([A-Za-z_$][\w$]*)\s*=\s*(\d+)\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*\[\s*([0-9\s,]+?)\s*\]\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*(["\'])\s*\7\s*;'
        r'(.*?)return\s+\6\s*;?\s*\}\s*\)\s*\(\s*\)',
        re.IGNORECASE | re.DOTALL
    )

    found = {}
    for m in pattern.finditer(active):
        label = (m.group(1) or '').lower()
        key_name = m.group(2)
        key = int(m.group(3))
        array_name = m.group(4)
        raw_numbers = m.group(5)
        body = m.group(8) or ''

        semantic = re.compile(
            r'String\s*\.\s*fromCharCode\s*\(\s*'
            + re.escape(array_name)
            + r'\s*\[\s*[A-Za-z_$][\w$]*\s*\]\s*\^\s*'
            + re.escape(key_name)
            + r'\s*\)',
            re.IGNORECASE | re.DOTALL
        )
        if not semantic.search(body):
            continue

        try:
            nums = [int(x.strip()) for x in raw_numbers.split(',') if x.strip()]
            if not nums or len(nums) > 4096:
                continue
            value = ''.join(chr(n ^ key) for n in nums)
        except Exception:
            continue

        value = html_unescape(value or '').replace('\\/', '/').strip()
        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith(('/', './', '../')):
            value = urljoin(document_url or BASE_COM, value)
        if not re.match(r'^https?://', value, re.IGNORECASE):
            continue
        if com_is_ad_stream_url(value) or com_is_mycam_fallback_stream(value, document_url, active):
            log('COM Clappr XOR {} blocked as ad/fallback for {}: {}'.format(label.upper(), name, value))
            continue
        found[label] = value

    if not found:
        return []

    # Follow the page's live assignment instead of assuming labels. Redlight
    # currently uses primaryUrl=urls.backup and backupUrl=urls.backup, while
    # YAK/Erox/XY normally use primary -> backup.
    primary_match = re.search(
        r'\b(?:const|let|var)\s+primaryUrl\s*=\s*urls\.(primary|backup)\s*;',
        active, re.IGNORECASE
    )
    backup_match = re.search(
        r'\b(?:const|let|var)\s+backupUrl\s*=\s*urls\.(primary|backup)\s*;',
        active, re.IGNORECASE
    )
    primary_label = (primary_match.group(1).lower() if primary_match else 'primary')
    backup_label = (backup_match.group(1).lower() if backup_match else 'backup')

    log('COM Clappr active URL order for {}: primaryUrl={} | backupUrl={}'.format(
        name, primary_label, backup_label
    ))

    candidates = []
    for role, label in (('PRIMARY', primary_label), ('BACKUP', backup_label)):
        value = found.get(label)
        if not value or value in candidates:
            continue
        candidates.append(value)
        log('COM Clappr XOR {} REAL candidate for {} via urls.{}: {}'.format(
            role, name, label, value
        ))

    # If a wrapper omits one assignment, preserve a safe fallback to whatever
    # decoded URL remains.  When both active assignments are explicit (as on
    # Redlight), do not invent an order the website itself does not use.
    if not primary_match or not backup_match:
        for label in ('primary', 'backup'):
            value = found.get(label)
            if value and value not in candidates:
                candidates.append(value)
                log('COM Clappr XOR EXTRA REAL candidate for {} via urls.{}: {}'.format(
                    name, label, value
                ))

    return candidates


def com_extract_inline_xor_media_candidates(document, document_url='', name=''):
    """Decode active inline XOR-IIFEs used directly as player media values.

    Covers current wrappers such as:
      new Playerjs({file:(function(){var k=...,a=[...],r=''; ... })()})
      new Clappr.Player({source:(function(){var k=...,a=[...],r=''; ... })()})

    Only the narrow numeric-array XOR expression is reproduced; arbitrary JS
    is never evaluated. HTML comments are removed first so old inactive player
    blocks cannot win over the site's active player.
    """
    decoded = html_unescape(document or '').replace('\\/', '/')
    active = re.sub(r'<!--.*?-->', '', decoded, flags=re.DOTALL)
    candidates = []
    seen = set()

    pattern = re.compile(
        r'(?<![\w$])(?:["\']\s*)?(file|src|source|url|playlist)(?:\s*["\'])?\s*:\s*'
        r'\(\s*function\s*\(\s*\)\s*\{\s*'
        r'var\s+([A-Za-z_$][\w$]*)\s*=\s*(\d+)\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*\[\s*([0-9\s,]+?)\s*\]\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*(["\'])\s*\7\s*;'
        r'(.*?)'
        r'return\s+\6\s*;?\s*\}\s*\)\s*\(\s*\)',
        re.IGNORECASE | re.DOTALL
    )

    for match in pattern.finditer(active):
        prop = (match.group(1) or 'media').lower()
        key_name = match.group(2)
        key = int(match.group(3))
        array_name = match.group(4)
        raw_numbers = match.group(5)
        body = match.group(8) or ''

        semantic = re.compile(
            r'String\s*\.\s*fromCharCode\s*\(\s*'
            + re.escape(array_name)
            + r'\s*\[\s*[A-Za-z_$][\w$]*\s*\]\s*\^\s*'
            + re.escape(key_name)
            + r'\s*\)',
            re.IGNORECASE | re.DOTALL
        )
        if not semantic.search(body):
            continue

        try:
            numbers = [int(piece.strip()) for piece in raw_numbers.split(',') if piece.strip()]
            if not numbers or len(numbers) > 4096:
                continue
            value = ''.join(chr(number ^ key) for number in numbers)
        except Exception:
            continue

        value = html_unescape(value or '').replace('\\/', '/').strip()
        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith(('/', './', '../')):
            value = urljoin(document_url or BASE_COM, value)
        if not re.match(r'^https?://', value, re.IGNORECASE):
            continue
        if com_is_ad_stream_url(value) or com_is_mycam_fallback_stream(value, document_url, active):
            log('COM inline XOR candidate blocked as ad/fallback for {} [{}]: {}'.format(name, prop, value))
            continue
        if value in seen:
            continue
        seen.add(value)
        candidates.append(value)
        log('COM inline XOR REAL candidate for {} [{}]: {}'.format(name, prop, value))

    return candidates


def com_extract_jwplayer_xor_variables(document, document_url='', name=''):
    """Decode the current .com JWPlayer signedUrl XOR-IIFE variables.

    Current /tv/*.php wrappers use a deliberately simple JavaScript obfuscator:
      const signedUrl = (function(){
        var k=96, a=[8,20,...], r='';
        for (var i=0; i<a.length; i++) {
          r += String.fromCharCode(a[i] ^ k);
        }
        return r;
      })();

    The browser executes this before jwplayer(...).setup({file:signedUrl}).
    We reproduce only this narrow deterministic expression; arbitrary JS is
    never executed.
    """
    decoded = html_unescape(document or '').replace('\\/', '/')
    values = {}

    pattern = re.compile(
        r'\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*'
        r'\(\s*function\s*\(\s*\)\s*\{\s*'
        r'var\s+([A-Za-z_$][\w$]*)\s*=\s*(\d+)\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*\[\s*([0-9\s,]+?)\s*\]\s*,\s*'
        r'([A-Za-z_$][\w$]*)\s*=\s*([\"\'])\s*\7\s*;'
        r'(.*?)'
        r'return\s+\6\s*;?\s*\}\s*\)\s*\(\s*\)\s*;?',
        re.IGNORECASE | re.DOTALL
    )

    for match in pattern.finditer(decoded):
        var_name = match.group(1)
        key_name = match.group(2)
        key = int(match.group(3))
        array_name = match.group(4)
        raw_numbers = match.group(5)
        body = match.group(8) or ''

        # Require the exact semantic operation used by the wrapper so a random
        # numeric array elsewhere on the page cannot be promoted to a stream.
        xor_pattern = re.compile(
            r'String\s*\.\s*fromCharCode\s*\(\s*'
            + re.escape(array_name)
            + r'\s*\[\s*[A-Za-z_$][\w$]*\s*\]\s*\^\s*'
            + re.escape(key_name)
            + r'\s*\)',
            re.IGNORECASE | re.DOTALL
        )
        if not xor_pattern.search(body):
            continue

        try:
            numbers = [int(piece.strip()) for piece in raw_numbers.split(',') if piece.strip()]
            if not numbers or len(numbers) > 4096:
                continue
            value = ''.join(chr(number ^ key) for number in numbers)
        except Exception:
            continue

        value = html_unescape(value or '').replace('\\/', '/').strip()
        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith(('/', './', '../')):
            value = urljoin(document_url or BASE_COM, value)

        if not re.match(r'^https?://', value, re.IGNORECASE):
            continue
        if com_is_ad_stream_url(value) or com_is_mycam_fallback_stream(value, document_url, decoded):
            continue

        values[var_name] = value
        log('COM JWPlayer XOR variable decoded for {}: {} -> {}'.format(name, var_name, value))

    return values



def com_extract_jwplayer_media_candidates(document, document_url, name=''):
    """Extract JWPlayer media values even when the URL has no .m3u8 suffix."""
    decoded = html_unescape(document or '').replace('\\/', '/')
    active = re.sub(r'<!--.*?-->', '', decoded, flags=re.DOTALL)
    if 'jwplayer' not in active.lower():
        return []

    try:
        variables = fuckflix_extract_js_string_variables(active, document_url)
    except Exception:
        variables = {}

    try:
        xor_variables = com_extract_jwplayer_xor_variables(active, document_url, name)
    except Exception as e:
        log('COM JWPlayer XOR decode error for {}: {}'.format(name, e), xbmc.LOGERROR)
        xor_variables = {}
    if xor_variables:
        variables.update(xor_variables)

    candidates = []
    seen = set()

    def reject_url(url):
        lower = (url or '').lower()
        return (
            not url
            or com_is_ad_stream_url(url)
            or com_is_mycam_fallback_stream(url, document_url, active)
            or any(marker in lower for marker in (
                'jwpcdn.com/player/', 'jwplayer8.js', '/jwplayer.js',
                'jquery', 'google-analytics', 'googletagmanager',
                '.css', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'
            ))
        )

    def add(raw, origin='jwplayer'):
        value = html_unescape(raw or '').replace('\\/', '/').strip().strip('"\'`')
        if not value:
            return
        try:
            value = unquote(value)
        except Exception:
            pass
        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith(('/', './', '../')):
            value = urljoin(document_url, value)
        if not re.match(r'^https?://', value, re.IGNORECASE):
            return
        if reject_url(value) or value in seen:
            return
        seen.add(value)
        candidates.append(value)
        log('COM JWPlayer REAL candidate for {} [{}]: {}'.format(name, origin, value))

    def eval_expr(expr):
        expr = (expr or '').strip()
        if not expr:
            return ''
        try:
            value = fuckflix_js_eval_string_expression(expr, variables, document_url)
        except Exception:
            value = ''
        if value:
            return value
        if len(expr) >= 2 and expr[0] in ('"', "'", '`') and expr[-1] == expr[0]:
            try:
                return fuckflix_js_decode_string_literal(expr)
            except Exception:
                return expr[1:-1]
        if re.match(r'^[A-Za-z_$][\w$]*$', expr) and expr in variables:
            return variables.get(expr) or ''
        return ''

    prop_pattern = re.compile(
        r'(?<![\w$])(file|src|source|url|playlist)\s*:\s*'
        r'((?:["\'][^"\']*["\'])|(?:`[^`]*`)|(?:[A-Za-z_$][\w$]*(?:\s*\+\s*(?:["\'][^"\']*["\']|`[^`]*`|[A-Za-z_$][\w$]*))*))',
        re.IGNORECASE | re.DOTALL
    )
    for match in prop_pattern.finditer(active):
        add(eval_expr(match.group(2)), match.group(1).lower())

    for match in re.finditer(
        r'\b(?:data-file|data-src|data-source|data-url|data-playlist)\s*=\s*["\']([^"\']+)["\']',
        active, re.IGNORECASE | re.DOTALL
    ):
        add(match.group(1), 'data-attr')

    for var_name, value in variables.items():
        lname = str(var_name).lower()
        if any(token in lname for token in ('file', 'src', 'source', 'stream', 'url', 'playlist', 'hls')):
            add(value, 'var:{}'.format(var_name))

    # Direct jwplayer(...).load(urlExpr) form without a file: property.
    for match in re.finditer(
        r'jwplayer\s*\([^)]*\)\s*\.\s*load\s*\(\s*([^,)]+)',
        active, re.IGNORECASE | re.DOTALL
    ):
        add(eval_expr(match.group(1)), 'jwplayer.load')

    return candidates


@site.register(default_mode=True)
def main(url):
    updated = update_check_on_open()
    senderstatus_add_main_menu_items()
    utils.eod()
    if updated:
        # Reload the current custom-site container so the freshly replaced
        # module is imported on the next CUMination plugin invocation.
        try:
            time.sleep(0.35)
            xbmc.executebuiltin('Container.Refresh')
        except Exception as exc:
            update_log('Container.Refresh after update failed: {}'.format(exc), xbmc.LOGERROR)


# -------------------------------------------------------------------------
# adult-tv-channels.click
# -------------------------------------------------------------------------

@site.register()
def List_CLICK(url):
    html = utils.getHtml(url, BASE_CLICK)

    cards = re.findall(
        r'<!-- begin post -->\s*<div class="card">(.*?)<!-- end post -->',
        html,
        re.DOTALL | re.IGNORECASE
    )

    seen = set()

    for card in cards:
        link = re.search(r'<a[^>]+href=["\']([^"\']+)["\']', card, re.IGNORECASE | re.DOTALL)
        if not link:
            continue

        videourl = urljoin(BASE_CLICK, html_unescape(link.group(1)))

        if videourl in seen:
            continue

        seen.add(videourl)

        img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', card, re.IGNORECASE | re.DOTALL)
        img = urljoin(BASE_CLICK, html_unescape(img_match.group(1))) if img_match else ''

        title_match = re.search(
            r'<h2[^>]*class=["\'][^"\']*card-title[^"\']*["\'][^>]*>.*?<a[^>]*>(.*?)</a>',
            card,
            re.IGNORECASE | re.DOTALL
        )

        if title_match:
            name = clean_text(title_match.group(1))
        else:
            name = videourl.rstrip('/').split('/')[-1].replace('-', ' ').title()

        description = ''
        site.add_download_link(name, videourl, 'Play_CLICK', img, description, noDownload=True)

    nextp = re.search(
        r'<link[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        html,
        re.DOTALL | re.IGNORECASE
    )

    if not nextp:
        nextp = re.search(
            r'<a[^>]+class=["\'][^"\']*older-posts[^"\']*["\'][^>]+href=["\']([^"\']+)["\']',
            html,
            re.DOTALL | re.IGNORECASE
        )

    if nextp:
        nexturl = urljoin(BASE_CLICK, html_unescape(nextp.group(1)))
        np = re.findall(r'page(\d+)', nexturl)
        np = np[-1] if np else '?'
        site.add_dir('Next Page ({})'.format(np), nexturl, 'List_CLICK', site.img_next)

    utils.eod()


@site.register()
def Play_CLICK(url, name, download=None):
    """v43 Einzelstart:
    Nicht mehr nur die erste preflight-OK-Variante blind an Kodi uebergeben.
    Der normale Klick bekommt dieselbe Selbstheilung wie der AutoTest:
    frische Seite/Token erneut holen, Child-Playlist nutzen und sichtbaren
    Fallback erst am Ende erlauben. Damit soll ein Benutzer-Klick den Sender
    moeglichst beim ersten sichtbaren Start korrekt starten.
    """
    max_attempts = CLICK_PLAY_BABES_MAX_ATTEMPTS if click_is_babes_legacy_name(name) else CLICK_PLAY_MAX_ATTEMPTS
    last_reason = ''

    for attempt in range(1, max_attempts + 1):
        allow_visible_fallback = False

        if attempt > 1:
            log('CLICK Einzelstart fresh retry {} for {} | visible_fallback={}'.format(attempt, name, allow_visible_fallback))
            try:
                notify('CLICK Retry {}: {}'.format(attempt, name), False)
            except Exception:
                pass
            time.sleep(max(0.25, CLICK_PLAY_RETRY_DELAY))

        try:
            prepared, reason = click_prepare_stream_for_autotest(name, url, False)
        except Exception as e:
            log('CLICK Einzelstart prepare error for {}: {}'.format(name, e), xbmc.LOGERROR)
            prepared, reason = [], 'prepare_error'

        last_reason = reason or last_reason

        if not prepared:
            if reason == 'mycamtv_ad_only' and not allow_visible_fallback and attempt < max_attempts:
                log('CLICK Einzelstart visible fallback deferred for {}; retrying real stream first'.format(name))
                continue
            if reason == 'mycamtv_ad_only' and allow_visible_fallback:
                log('CLICK Einzelstart only visible fallback/ad candidates for {} on final attempt'.format(name))
            else:
                log('CLICK Einzelstart no prepared stream for {} on attempt {} reason={}'.format(name, attempt, reason), xbmc.LOGERROR)
            continue

        problem_kodi_starts = 0

        for variant_index, prepared_item in enumerate(prepared, 1):
            finalurl, streamurl, referer, profile = click_unpack_prepared(prepared_item)

            gateway_isa = fuckflix_is_api_gateway_url(streamurl)
            if not gateway_isa and not click_manifest_preflight_ok(streamurl, referer, name, profile):
                code = click_last_preflight_code(profile)
                last_reason = 'rate_limited' if code == '429' else 'preflight_rejected'

                if code == '429':
                    log('CLICK Einzelstart proxy rate-limit cooldown for {} after HTTP 429 [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                    time.sleep(max(0.25, CLICK_PLAY_RATE_LIMIT_COOLDOWN))
                    break

                if code == '403' and click_single_kodi_start_name(name) and not allow_visible_fallback:
                    log('CLICK Einzelstart HTTP 403 on real candidate; retry fresh before fallback for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                    time.sleep(0.55)
                    break

                time.sleep(0.25)
                continue

            play_streamurl = streamurl
            try:
                resolved_child_url = profile.get('resolved_child_url') if profile else ''
            except Exception:
                resolved_child_url = ''

            if resolved_child_url:
                play_streamurl = resolved_child_url
                finalurl = click_build_final_stream_url(play_streamurl, referer, profile)
                log('CLICK Einzelstart using child playlist for {} [{}]: {}'.format(name, click_profile_label(profile), play_streamurl))

            ok_kind = 'visible_fallback' if click_is_visible_fallback_stream(play_streamurl) else 'real'
            log('CLICK Einzelstart playing {} attempt {} variant {}/{} [{}] {}: {}'.format(name, attempt, variant_index, len(prepared), click_profile_label(profile), ok_kind.upper(), play_streamurl))

            if click_single_kodi_start_name(name):
                problem_kodi_starts += 1

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
                time.sleep(0.25)
            except Exception:
                pass

            player = SenderStatusPlayer('CLICK Einzelstart')
            item = xbmcgui.ListItem(name)

            try:
                item.setProperty('IsPlayable', 'true')
            except Exception:
                pass

            if click_uses_safe_hls_listitem(name):
                try:
                    item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                    log('CLICK safe HLS ListItem enabled for {}'.format(name))
                except Exception:
                    pass

            if gateway_isa:
                configure_xlivetv_isa_item(item, referer, BASE_CLICK.rstrip('/'), 'CLICK Einzelstart')

            try:
                player.play(streamurl if gateway_isa else finalurl, item)
            except Exception as e:
                log('CLICK Einzelstart player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
                time.sleep(0.35)
                continue

            ok = senderstatus_wait_for_player(
                player,
                start_timeout=(5 if gateway_isa else click_play_start_timeout_for_name(name)),
                play_seconds=CLICK_PLAY_CONFIRM_SECONDS,
                stable_seconds=CLICK_PLAY_STABLE_SECONDS,
                progress=None,
                progress_message='',
                log_prefix='CLICK Einzelstart'
            )

            if ok:
                label = 'FALLBACK' if ok_kind == 'visible_fallback' else 'REAL'
                log('CLICK Einzelstart OK {} for {} on attempt {} variant {}'.format(label, name, attempt, variant_index))
                try:
                    notify('CLICK startet {}: {} | V{} | Var{}'.format(label, name, attempt, variant_index), False)
                except Exception:
                    pass
                return

            log('CLICK Einzelstart no playback for {} on attempt {} variant {}'.format(name, attempt, variant_index), xbmc.LOGERROR)
            last_reason = 'no_playback'

            click_stop_player_safely(
                player,
                name,
                progress=None,
                message='CLICK Einzelstart Player-Cleanup: {}'.format(name)
            )

            if click_single_kodi_start_name(name) and problem_kodi_starts >= 1 and attempt < max_attempts:
                log('CLICK Einzelstart stops this attempt after Kodi failure; retrying fresh later for {}'.format(name), xbmc.LOGERROR)
                break

        # naechster frischer Attempt

    if last_reason == 'mycamtv_ad_only':
        notify('CLICK: Nur sichtbarer Fallback/Werbung gefunden', False)
    elif last_reason == 'rate_limited':
        notify('CLICK: Proxy gerade limitiert - bitte kurz warten', True)
    else:
        notify('CLICK: Stream aktuell nicht stabil verfügbar', True)


# -------------------------------------------------------------------------
# adult-tv-channels.com
# -------------------------------------------------------------------------

@site.register()
def List_COM(url):
    html = utils.getHtml(url, BASE_COM)

    seen = set()

    # WordPress-Artikelblöcke
    articles = re.findall(r'<article\b.*?</article>', html, re.DOTALL | re.IGNORECASE)

    for article in articles:
        title_link = re.search(
            r'<h[1-6][^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>.*?<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            article,
            re.IGNORECASE | re.DOTALL
        )

        if title_link:
            videourl = html_unescape(title_link.group(1))
            name = clean_text(title_link.group(2))
        else:
            link = re.search(
                r'<a[^>]+href=["\'](https?://adult-tv-channels\.com/[^"\']+/)["\'][^>]*>',
                article,
                re.IGNORECASE | re.DOTALL
            )
            if not link:
                continue

            videourl = html_unescape(link.group(1))
            name = videourl.rstrip('/').split('/')[-1].replace('-', ' ').title()

        # Nicht die üblichen WP-Seiten/Kategorien einsammeln
        if any(x in videourl for x in ['/category/', '/author/', '/contact-us/', '/feed/']):
            continue

        if videourl in seen:
            continue

        seen.add(videourl)

        img_match = re.search(
            r'<img[^>]+(?:data-src|src)=["\']([^"\']+)["\']',
            article,
            re.IGNORECASE | re.DOTALL
        )
        img = urljoin(BASE_COM, html_unescape(img_match.group(1))) if img_match else ''

        desc_match = re.search(
            r'<div[^>]+class=["\'][^"\']*entry-excerpt[^"\']*["\'][^>]*>.*?<p>(.*?)</p>',
            article,
            re.IGNORECASE | re.DOTALL
        )
        description = clean_text(desc_match.group(1)) if desc_match else ''

        site.add_download_link(name, videourl, 'Play_COM', img, description, noDownload=True)

    # Fallback für das ältere Original-Layout
    if not seen:
        old_matches = re.compile(
            r'<article.*?href="([^"]+)".*?src="([^"]+)".*?entry-title(?:[^>]+>){2}([^<]+)<.*?excerpt">[^>]+>([^<]+)<',
            re.DOTALL | re.IGNORECASE
        ).findall(html)

        for videourl, img, name, description in old_matches:
            videourl = urljoin(BASE_COM, html_unescape(videourl))
            img = urljoin(BASE_COM, html_unescape(img))
            name = clean_text(name)
            description = clean_text(description)

            if videourl not in seen:
                seen.add(videourl)
                site.add_download_link(name, videourl, 'Play_COM', img, description, noDownload=True)

    # Pagination .com
    nextp = re.search(
        r'rel=["\']next["\']\s+href=["\']([^"\']+)["\']',
        html,
        re.DOTALL | re.IGNORECASE
    )

    if not nextp:
        nextp = re.search(
            r'<a[^>]+class=["\'][^"\']*(?:next|older-posts)[^"\']*["\'][^>]+href=["\']([^"\']+)["\']',
            html,
            re.DOTALL | re.IGNORECASE
        )

    if nextp:
        nexturl = urljoin(BASE_COM, html_unescape(nextp.group(1)))
        nums = re.findall(r'/page/(\d+)|page/(\d+)|paged=(\d+)', nexturl)
        if nums:
            flat = [n for group in nums for n in group if n]
            np = flat[-1] if flat else '?'
        else:
            np = '?'

        site.add_dir('Next Page ({})'.format(np), nexturl, 'List_COM', site.img_next)

    utils.eod()


@site.register()
def Play_COM(url, name, download=None):
    """v50 self-healing .com single playback.

    A single visible user click may internally reload the sender page/token up
    to three times. HLS/child playlists count as REAL; a genuine website MP4
    counts as FALLBACK. Unverified MP4 is still only permitted for the two
    explicitly whitelisted website-MP4 channels on their final attempt.
    """
    # Wie .click maximal drei sichtbare interne Startversuche: V1 + RETRY 2/3.
    # Spezielle Sender behalten ihre laengeren Pausen/Warmups, aber keinen
    # vierten Benutzerstart, damit Ablauf und Meldungen einheitlich bleiben.
    max_attempts = COM_PLAY_MAX_ATTEMPTS

    last_reason = ''
    ad_seen = False

    for attempt in range(1, max_attempts + 1):
        if attempt > 1:
            log('COM Einzelstart fresh retry {} for {}'.format(attempt, name))
            try:
                notify('COM RETRY {}: {}'.format(attempt, name), False)
            except Exception:
                pass

            retry_delay = COM_SLOW_FRESH_RETRY_DELAY if com_needs_slow_fresh_retry(name) else COM_PLAY_RETRY_DELAY
            try:
                time.sleep(max(0.25, float(retry_delay)))
            except Exception:
                time.sleep(0.25)

        try:
            prepared, prepare_reason = com_prepare_stream_for_autotest(name, url)
        except Exception as e:
            log('COM Einzelstart prepare error for {}: {}'.format(name, e), xbmc.LOGERROR)
            prepared, prepare_reason = [], 'prepare_error'

        last_reason = prepare_reason or last_reason

        if not prepared:
            if prepare_reason == 'mycamtv_ad_only':
                ad_seen = True
                log('COM Einzelstart only MyCam/ad candidates for {} on attempt {}'.format(name, attempt))
            else:
                log('COM Einzelstart no prepared stream for {} on attempt {} reason={}'.format(name, attempt, prepare_reason), xbmc.LOGERROR)
            continue

        warmup = COM_AUTOTEST_INITIAL_WARMUP
        log('COM Einzelstart warmup before preflight for {} attempt {}: {:.1f} seconds'.format(name, attempt, warmup))
        try:
            time.sleep(max(0.0, float(warmup)))
        except Exception:
            pass

        for variant_index, prepared_item in enumerate(prepared, 1):
            finalurl, streamurl, iframeurl, source_kind = com_unpack_prepared(prepared_item)
            if com_needs_slow_fresh_retry(name):
                try:
                    time.sleep(max(0.0, float(COM_SLOW_FRESH_PREFLIGHT_WARMUP)))
                except Exception:
                    pass

            allow_unverified_mp4 = False

            preflight_result = com_manifest_preflight_ok(
                streamurl,
                iframeurl,
                name,
                allow_unverified_mp4=allow_unverified_mp4
            )
            if not preflight_result:
                last_reason = 'preflight_rejected'
                time.sleep(0.25)
                continue

            play_streamurl = streamurl
            play_finalurl = finalurl
            if isinstance(preflight_result, str):
                play_streamurl = preflight_result
                play_finalurl = com_build_final_stream_url(play_streamurl, iframeurl)
                if '.mp4' in play_streamurl.lower():
                    log('COM Einzelstart using unverified website MP4 last-resort for {}: {}'.format(name, play_streamurl), xbmc.LOGWARNING)
                else:
                    log('COM Einzelstart using child playlist for {}: {}'.format(name, play_streamurl))

            play_kind = 'fallback' if source_kind == 'visible_fallback' else 'real'
            play_label = 'FALLBACK' if play_kind == 'fallback' else 'REAL'
            log('COM Einzelstart playing {} attempt {} variant {}/{} {}: {}'.format(
                name, attempt, variant_index, len(prepared), play_label, play_streamurl
            ))

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
                time.sleep(0.25)
            except Exception:
                pass

            player = SenderStatusPlayer('COM Einzelstart')
            item = xbmcgui.ListItem(name)
            try:
                item.setProperty('IsPlayable', 'true')
            except Exception:
                pass

            if com_needs_strict_child_segment(name):
                try:
                    item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                    log('COM safe HLS ListItem enabled for {}'.format(name))
                except Exception:
                    pass

            gateway_isa = fuckflix_is_api_gateway_url(play_streamurl)
            if gateway_isa:
                configure_xlivetv_isa_item(item, iframeurl, BASE_COM.rstrip('/'), 'COM Senderstatus')

            try:
                player.play(play_streamurl if gateway_isa else play_finalurl, item)
            except Exception as e:
                log('COM Einzelstart player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
                last_reason = 'player_error'
                time.sleep(0.35)
                continue

            ok = senderstatus_wait_for_player(
                player,
                start_timeout=(5 if gateway_isa else COM_PLAY_START_TIMEOUT),
                play_seconds=COM_PLAY_CONFIRM_SECONDS,
                stable_seconds=COM_PLAY_STABLE_SECONDS,
                progress=None,
                progress_message='',
                log_prefix='COM Einzelstart'
            )

            if ok:
                log('COM Einzelstart OK {} for {} on attempt {} variant {}'.format(play_label, name, attempt, variant_index))
                try:
                    notify('COM startet {}: {} | V{} | Var{} | {:.1f}s'.format(
                        play_label, name, attempt, variant_index, float(COM_PLAY_CONFIRM_SECONDS)
                    ), False)
                except Exception:
                    pass
                return

            log('COM Einzelstart no playback for {} on attempt {} variant {}'.format(name, attempt, variant_index), xbmc.LOGERROR)
            last_reason = 'no_playback'

            try:
                if player.isPlaying():
                    player.stop()
            except Exception:
                pass
            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
            except Exception:
                pass
            try:
                time.sleep(max(0.25, float(CLICK_AUTOTEST_KODI_CLEANUP_PAUSE)))
            except Exception:
                time.sleep(0.25)

    if ad_seen and last_reason == 'mycamtv_ad_only':
        notify('COM: Nur Werbevideo/MyCamTV gefunden', False)
    else:
        notify('COM: Stream nach {} Versuchen nicht verfügbar'.format(max_attempts), True)



# -------------------------------------------------------------------------
# Senderstatus: adult-tv-channels.com
# -------------------------------------------------------------------------

def com_parse_channels_from_html(html, page_url):
    channels = []
    seen = set()

    articles = re.findall(r'<article\b.*?</article>', html or '', re.DOTALL | re.IGNORECASE)

    for article in articles:
        title_link = re.search(
            r'<h[1-6][^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>.*?<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            article,
            re.IGNORECASE | re.DOTALL
        )

        if title_link:
            videourl = urljoin(page_url, html_unescape(title_link.group(1)))
            name = clean_text(title_link.group(2))
        else:
            link = re.search(
                r'<a[^>]+href=["\'](https?://adult-tv-channels\.com/[^"\']+/)["\'][^>]*>',
                article,
                re.IGNORECASE | re.DOTALL
            )
            if not link:
                continue

            videourl = urljoin(page_url, html_unescape(link.group(1)))
            name = videourl.rstrip('/').split('/')[-1].replace('-', ' ').title()

        if any(x in videourl for x in ['/category/', '/author/', '/contact-us/', '/feed/', '/privacy', '/dmca']):
            continue

        if videourl in seen:
            continue

        seen.add(videourl)

        img_match = re.search(
            r'<img[^>]+(?:data-src|src)=["\']([^"\']+)["\']',
            article,
            re.IGNORECASE | re.DOTALL
        )
        img = urljoin(page_url, html_unescape(img_match.group(1))) if img_match else ''

        channels.append((name, videourl, img))

    if not channels:
        old_matches = re.compile(
            r'<article.*?href="([^"]+)".*?src="([^"]+)".*?entry-title(?:[^>]+>){2}([^<]+)<.*?excerpt">[^>]+>([^<]+)<',
            re.DOTALL | re.IGNORECASE
        ).findall(html or '')

        for videourl, img, name, description in old_matches:
            videourl = urljoin(page_url, html_unescape(videourl))
            img = urljoin(page_url, html_unescape(img))
            name = clean_text(name)

            if any(x in videourl for x in ['/category/', '/author/', '/contact-us/', '/feed/', '/privacy', '/dmca']):
                continue

            if videourl not in seen:
                seen.add(videourl)
                channels.append((name, videourl, img))

    return channels


def com_find_next_page_url(html, page_url):
    html = html or ''

    patterns = [
        r'<link[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        r'<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\']next["\']',
        r'<a[^>]+class=["\'][^"\']*(?:next|older-posts|nextpostslink)[^"\']*["\'][^>]+href=["\']([^"\']+)["\']',
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]+class=["\'][^"\']*(?:next|older-posts|nextpostslink)[^"\']*["\']',
    ]

    for pattern in patterns:
        match = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
        if match:
            return urljoin(page_url, html_unescape(match.group(1)))

    return None

def com_status_plain_name(name):
    text = clean_text(name or '').lower()
    text = text.replace('&amp;', '&')
    text = re.sub(r'[^a-z0-9а-яёäöüß\- ]+', ' ', text, flags=re.IGNORECASE)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def com_is_known_website_broken(name):
    plain = com_status_plain_name(name)

    for item in COM_KNOWN_WEBSITE_BROKEN:
        if item in plain:
            return True

    # v26: Pink Erotic 3/4/5/6 gehoeren zur Beobachtungsgruppe und
    # werden nicht mehr pauschal uebersprungen. Wenn sie aktuell nur einen
    # kaputten Player liefern, faengt die Manifest-Vorpruefung das ab.
    return False


def com_should_try_aistr_hls_variant(name):
    plain = com_status_plain_name(name)
    return any(item in plain for item in COM_TRY_AISTR_HLS_VARIANT_FOR)


def com_needs_slow_fresh_retry(name):
    plain = com_status_plain_name(name)
    return any(item in plain for item in COM_SLOW_FRESH_RETRY_NAMES)


def com_allows_mp4_last_resort(name):
    plain = com_status_plain_name(name)
    return any(item in plain for item in COM_MP4_LAST_RESORT_NAMES)


def com_needs_named_child_playlist(name):
    plain = com_status_plain_name(name)
    return any(item in plain for item in COM_CHILD_PLAYBACK_NAMES)


def com_needs_strict_child_segment(name):
    plain = com_status_plain_name(name)
    return any(item in plain for item in COM_STRICT_CHILD_SEGMENT_NAMES)


def com_visible_confirm_seconds(name):
    plain = com_status_plain_name(name)
    if any(item in plain for item in COM_VISIBLE_CONFIRM_NAMES):
        return float(COM_VISIBLE_CONFIRM_PLAY_SECONDS)
    return float(COM_AUTOTEST_PLAY_SECONDS)


def com_slow_fresh_retry_sleep(name, attempt, max_attempts, progress=None):
    if not com_needs_slow_fresh_retry(name) or attempt >= max_attempts:
        return

    delay = float(COM_SLOW_FRESH_RETRY_DELAY)
    log('COM Senderstatus cooldown before fresh retry for {}: {:.1f} seconds'.format(name, delay))

    end = time.time() + max(0.0, delay)
    while time.time() < end:
        if oxax_autotest_cancelled(progress):
            break
        try:
            if progress:
                progress.update(0, 'COM: {}\nFresh-Token-Pause {:.1f}s...'.format(name, max(0.0, end - time.time())))
        except Exception:
            pass
        time.sleep(0.35)


def com_stream_extra_headers(streamurl):
    headers = {'Accept': '*/*'}

    if 'aistr.xyz' in (streamurl or ''):
        # LibreELEC/Kodi/Curl kann bei diesen Hosts sonst an der TLS-Pruefung scheitern.
        headers['verifypeer'] = 'false'
        headers['verifyhost'] = 'false'

    return headers


def com_stream_variants(streamurl, name=''):
    streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
    variants = []

    def add(url):
        if url and url not in variants:
            variants.append(url)

    # Manche .com-Sender liefern stream.aistr.xyz/live/<id>/playlist.m3u8.
    # Bei Redlight/XY Max/XY Mix endete Kodi damit im Log sofort mit EOF.
    # v25: Fuer diese Sender zuerst die stabile aistr.xyz:28791/hls-Variante
    # testen, damit weniger Kodi-Fehler-Popups durch die live-Variante entstehen.
    parsed = urlparse(streamurl)
    if com_should_try_aistr_hls_variant(name) and 'stream.aistr.xyz' in parsed.netloc:
        match = re.search(r'/live/([^/]+)/playlist\.m3u8', parsed.path or '', re.IGNORECASE)
        if match:
            channel_id = match.group(1)
            query = ('?' + parsed.query) if parsed.query else ''
            add('https://aistr.xyz:28791/hls/{}/playlist.m3u8{}'.format(channel_id, query))

    add(streamurl)

    return variants[:max(1, COM_AUTOTEST_STREAM_VARIANTS)]


def com_build_final_stream_url(streamurl, iframeurl):
    if fuckflix_is_api_gateway_url(streamurl):
        return streamurl
    return kodi_stream_headers(streamurl, iframeurl, BASE_COM, com_stream_extra_headers(streamurl))


def com_preflight_headers(streamurl, iframeurl):
    headers = {
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Referer': iframeurl or BASE_COM,
        'Origin': BASE_COM.rstrip('/'),
        'Connection': 'close',
    }

    if '.mp4' in (streamurl or '').lower():
        headers['Range'] = 'bytes=0-0'

    return headers


def com_build_preflight_opener():
    try:
        context = ssl._create_unverified_context()
        return build_opener(HTTPSHandler(context=context))
    except Exception:
        return build_opener()


def com_first_master_child_url(base_url, manifest_data):
    try:
        lines = [line.strip() for line in (manifest_data or '').splitlines()]
        for idx, line in enumerate(lines):
            if line.upper().startswith('#EXT-X-STREAM-INF'):
                for child in lines[idx + 1:]:
                    if child and not child.startswith('#'):
                        return urljoin(base_url, child)
        return ''
    except Exception:
        return ''


def com_should_use_child_playlist(streamurl, name=''):
    decoded = html_unescape(streamurl or '').replace('\\/', '/').lower()
    plain = com_status_plain_name(name)

    # v46: Diese Master-Hosts/Sender waren im Log preflight-OK, aber Kodi
    # bekam danach keinen stabilen Start. Direktes Child-Manifest ist hier
    # naeher am, was der Browser letztlich abspielt.
    if com_needs_named_child_playlist(name):
        return True

    if 'webtvstream.bhtelecom.ba' in decoded:
        return True

    if 'stream.aistr.xyz' in decoded and any(x in plain for x in ('redlight hd', 'xy max', 'xy mix')):
        return True

    return False


def com_first_media_segment_url(base_url, manifest_data):
    try:
        for line in (manifest_data or '').splitlines():
            item = line.strip()
            if not item or item.startswith('#'):
                continue
            lower = item.lower()
            if '.m3u8' in lower:
                continue
            return urljoin(base_url, item)
    except Exception:
        pass
    return ''


def com_deep_manifest_preflight(opener, child_url, iframeurl, name=''):
    current_url = child_url
    seen = set()

    for depth in range(3):
        if not current_url or current_url in seen:
            log('COM Senderstatus child preflight rejected loop for {} | {}'.format(name, current_url), xbmc.LOGERROR)
            return ''
        seen.add(current_url)

        try:
            req = Request(current_url, headers=com_preflight_headers(current_url, iframeurl))
            response = opener.open(req, timeout=COM_AUTOTEST_PREFLIGHT_TIMEOUT)
            final_child_url = response.geturl()
            data = response.read(COM_CHILD_SEGMENT_READ_BYTES).decode('utf-8', 'ignore')
            try:
                response.close()
            except Exception:
                pass

            head = (data or '')[:160].replace('\n', ' ').replace('\r', ' ')
            if '#EXTM3U' not in data:
                log('COM Senderstatus child preflight rejected non-HLS for {} | {} | {}'.format(name, final_child_url, head), xbmc.LOGERROR)
                return ''

            if '#EXT-X-STREAM-INF' in data.upper():
                nested = com_first_master_child_url(final_child_url, data)
                if not nested:
                    log('COM Senderstatus child preflight rejected master without child for {} | {}'.format(name, final_child_url), xbmc.LOGERROR)
                    return ''
                current_url = nested
                continue

            if com_needs_strict_child_segment(name):
                segment_url = com_first_media_segment_url(final_child_url, data)
                if not segment_url:
                    log('COM Senderstatus child preflight rejected no media segment for {} | {}'.format(name, final_child_url), xbmc.LOGERROR)
                    return ''
                try:
                    seg_headers = com_preflight_headers(segment_url, iframeurl)
                    seg_headers['Range'] = 'bytes=0-0'
                    seg_req = Request(segment_url, headers=seg_headers)
                    seg_response = opener.open(seg_req, timeout=COM_CHILD_SEGMENT_PREFLIGHT_TIMEOUT)
                    seg_response.read(1)
                    try:
                        seg_response.close()
                    except Exception:
                        pass
                    log('COM Senderstatus child segment preflight OK for {} -> {}'.format(name, segment_url))
                except HTTPError as e:
                    log('COM Senderstatus child segment rejected HTTP {} for {} | {}'.format(getattr(e, 'code', '?'), name, segment_url), xbmc.LOGERROR)
                    return ''
                except Exception as e:
                    log('COM Senderstatus child segment rejected uncertain for {} | {}: {}'.format(name, segment_url, e), xbmc.LOGERROR)
                    return ''

            log('COM Senderstatus child preflight OK for {} -> {}'.format(name, final_child_url))
            return final_child_url
        except HTTPError as e:
            log('COM Senderstatus child preflight rejected HTTP {} for {} | {}'.format(getattr(e, 'code', '?'), name, current_url), xbmc.LOGERROR)
            return ''
        except Exception as e:
            log('COM Senderstatus child preflight rejected uncertain URL for {} | {}: {}'.format(name, current_url, e), xbmc.LOGERROR)
            return ''

    log('COM Senderstatus child preflight rejected max depth for {} | {}'.format(name, current_url), xbmc.LOGERROR)
    return ''


def com_manifest_preflight_ok(streamurl, iframeurl, name='', allow_unverified_mp4=False):
    if fuckflix_is_api_gateway_url(streamurl):
        log('COM Senderstatus XLivetv gateway preflight skipped for fresh token: {} | {}'.format(name, streamurl))
        return True

    """
    Fast safety check before Kodi opens the URL.

    The website sometimes shows hls.js manifestLoadError / temporary 404. If we
    pass those URLs directly to Kodi, Kodi shows the blocking generic playback
    popup. A small manifest read is enough to reject most broken candidates and
    then refresh the sender page on the next attempt.
    """
    try:
        opener = com_build_preflight_opener()
        req = Request(streamurl, headers=com_preflight_headers(streamurl, iframeurl))
        response = opener.open(req, timeout=COM_AUTOTEST_PREFLIGHT_TIMEOUT)
        final_url = response.geturl()
        content_type = ''
        try:
            content_type = response.headers.get('Content-Type', '')
        except Exception:
            content_type = ''

        lower_stream = (streamurl or '').lower()
        lower_final = (final_url or '').lower()
        lower_type = (content_type or '').lower()

        if '.mp4' in lower_stream or '.mp4' in lower_final or lower_type.startswith('video/') or 'mp4' in lower_type:
            log('COM Senderstatus preflight MP4 OK for {} -> {} | {}'.format(name, final_url, content_type))
            return True

        data = response.read(900).decode('utf-8', 'ignore')
        head = (data or '')[:160].replace('\n', ' ').replace('\r', ' ')

        if '#EXTM3U' in data:
            child_url = com_first_master_child_url(final_url, data)
            if child_url and com_should_use_child_playlist(streamurl, name):
                child_ready = com_deep_manifest_preflight(opener, child_url, iframeurl, name)
                if child_ready:
                    log('COM Senderstatus child playback prepared for {} -> {}'.format(name, child_ready))
                    return child_ready

            log('COM Senderstatus preflight OK for {} -> {} | {}'.format(name, final_url, head))
            return True

        log('COM Senderstatus preflight rejected non-HLS/media for {} | {} | {}'.format(name, streamurl, head), xbmc.LOGERROR)
        return False

    except HTTPError as e:
        log('COM Senderstatus preflight rejected HTTP {} for {} | {}'.format(getattr(e, 'code', '?'), name, streamurl), xbmc.LOGERROR)
        return False
    except Exception as e:
        # v49: Nur fuer die zwei bekannten Website-MP4-Sender darf der letzte
        # frische Versuch bei einem unklaren Timeout browseraehnlich direkt an
        # Kodi gehen. Eindeutige HTTP-Fehler landen bereits im HTTPError-Zweig
        # und bleiben deshalb weiterhin blockiert.
        if allow_unverified_mp4 and com_allows_mp4_last_resort(name) and '.mp4' in (streamurl or '').lower():
            log('COM Senderstatus MP4 last-resort allowed after uncertain preflight for {} | {}: {}'.format(name, streamurl, e), xbmc.LOGWARNING)
            return streamurl

        # Andere Timeout/SSL/Netzwerkfehler bleiben aus Popup-Schutz unsicher.
        log('COM Senderstatus preflight rejected uncertain URL for {} | {}: {}'.format(name, streamurl, e), xbmc.LOGERROR)
        return False



def com_fetch_channels_for_autotest(progress=None):
    channels = []
    seen_pages = set()
    seen_videos = set()
    page_url = BASE_COM
    page_count = 0

    while page_url and page_url not in seen_pages and page_count < COM_AUTOTEST_MAX_PAGES and len(channels) < COM_AUTOTEST_MAX_CHANNELS:
        page_count += 1
        seen_pages.add(page_url)

        try:
            if progress:
                progress.update(0, 'COM: Page {} laden...\n{}'.format(page_count, page_url))
        except Exception:
            pass

        try:
            html = utils.getHtml(page_url, BASE_COM)
        except Exception as e:
            log('COM Senderstatus page load error page {} {}: {}'.format(page_count, page_url, e), xbmc.LOGERROR)
            break

        page_channels = com_parse_channels_from_html(html, page_url)
        added = 0

        for name, videourl, img in page_channels:
            if videourl in seen_videos:
                continue
            seen_videos.add(videourl)
            channels.append((name, videourl, img))
            added += 1

            if len(channels) >= COM_AUTOTEST_MAX_CHANNELS:
                break

        log('COM Senderstatus page {}: {} neue Sender | total {}'.format(page_count, added, len(channels)))

        next_url = com_find_next_page_url(html, page_url)

        if not next_url or next_url in seen_pages:
            break

        page_url = next_url

    log('COM Senderstatus channels: {} from {} pages'.format(len(channels), page_count))
    return channels, page_count


def com_prepare_stream_for_autotest(name, url):
    cj = http.cookiejar.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))

    try:
        root_html = browser_get(opener, url, BASE_COM)
    except Exception as e:
        log('COM Senderstatus root page load error for {} | {}: {}'.format(name, url, e), xbmc.LOGERROR)
        return [], 'page_load_error'

    ad_seen = False
    no_m3u8_seen = False
    fallback_prepared = []
    fallback_seen = set()
    visited = set()
    # root + top-level iframe + one nested iframe level, bounded so one odd
    # page cannot turn a single sender test into a crawler.
    queue = [(root_html, url, 0)]
    max_documents = 12

    def queue_mp4_fallback(streamurl, referer):
        if com_is_mycam_fallback_stream(streamurl, referer):
            log('COM Senderstatus MyCam/Redtraffic globally blocked for {}: {}'.format(name, streamurl))
            return
        for variant in com_stream_variants(streamurl, name):
            if '.mp4' not in (variant or '').lower():
                continue
            key = (variant, referer)
            if not variant or key in fallback_seen:
                continue
            fallback_seen.add(key)
            fallback_prepared.append(com_prepared_item(
                com_build_final_stream_url(variant, referer),
                variant,
                referer,
                'visible_fallback'
            ))
            log('COM Senderstatus queued MP4 fallback after REAL search for {}: {}'.format(name, variant))

    def prepare_real(streamurl, referer, context_html=''):
        prepared = []
        seen_local = set()
        for variant in com_stream_variants(streamurl, name):
            if not variant or variant in seen_local:
                continue
            seen_local.add(variant)
            if (not com_is_known_real_stream(variant)) and com_is_mycam_fallback_stream(variant, referer, context_html):
                log('COM Senderstatus MyCam/Redtraffic candidate blocked for {}: {}'.format(name, variant))
                continue
            if '.mp4' in (variant or '').lower():
                queue_mp4_fallback(variant, referer)
                continue
            prepared.append(com_prepared_item(
                com_build_final_stream_url(variant, referer), variant, referer, 'real'
            ))
            log('COM Senderstatus provenance REAL for {}: {}'.format(name, variant))
        return prepared

    doc_index = 0
    while queue and doc_index < max_documents:
        document, document_url, depth = queue.pop(0)
        if not document_url or document_url in visited:
            continue
        visited.add(document_url)
        doc_index += 1

        nested_iframes = com_diagnostic_document_summary(name, document, document_url, depth)
        com_jwplayer_context_diagnostics(name, document, document_url, depth)
        com_active_player_context_diagnostics(name, document, document_url, depth)

        # v77: Decode Clappr primary/backup XOR URLs and follow the current
        # primaryUrl/backupUrl assignments used by the website.
        clappr_xor_candidates = com_extract_clappr_xor_url_object_candidates(document, document_url, name)
        if clappr_xor_candidates:
            clappr_prepared = []
            clappr_seen = set()
            for streamurl in clappr_xor_candidates:
                for item in prepare_real(streamurl, document_url, document):
                    key = tuple(com_unpack_prepared(item))
                    if key in clappr_seen:
                        continue
                    clappr_seen.add(key)
                    clappr_prepared.append(item)
            if clappr_prepared:
                log('COM Senderstatus prepared {} Clappr primary/backup REAL variant(s) for {} from depth {} document {}'.format(
                    len(clappr_prepared), name, depth, document_url
                ))
                return clappr_prepared[:max(1, COM_AUTOTEST_STREAM_VARIANTS)], ''

        # v75/v76: Active Playerjs/Clappr/JWPlayer wrappers can hide the media
        # URL directly inside file/source:(function(){... XOR ...})(). v76 also
        # accepts quoted JSON-style keys such as "file": (function(){...}).
        inline_xor_candidates = com_extract_inline_xor_media_candidates(document, document_url, name)
        for streamurl in inline_xor_candidates:
            prepared = prepare_real(streamurl, document_url, document)
            if prepared:
                log('COM Senderstatus prepared {} inline-XOR REAL variant(s) for {} from depth {} document {}'.format(
                    len(prepared), name, depth, document_url
                ))
                return prepared, ''

        # v73/v74: Current .com /tv/*.php wrappers may use JWPlayer but may not contain
        # a literal .m3u8. Resolve file/src/source/url/playlist values first.
        jw_candidates = com_extract_jwplayer_media_candidates(document, document_url, name)
        for streamurl in jw_candidates:
            prepared = prepare_real(streamurl, document_url, document)
            if prepared:
                log('COM Senderstatus prepared {} JWPlayer REAL variant(s) for {} from depth {} document {}'.format(
                    len(prepared), name, depth, document_url
                ))
                return prepared, ''

        # Current API/player discovery. COM forces external same-origin/player
        # JS inspection even when the HTML only contains a generic script tag.
        for streamurl in site_dynamic_api_stream_candidates(
            opener, document, document_url, name, 'COM', force_external_scripts=True
        ):
            prepared = prepare_real(streamurl, document_url, document)
            if prepared:
                log('COM Senderstatus prepared {} dynamic REAL variant(s) for {} from depth {} document {}'.format(
                    len(prepared), name, depth, document_url
                ))
                return prepared, ''

        # Record MyCam only as blocked evidence. Non-MyCam MP4 can be queued,
        # but is not returned until the entire REAL search is exhausted.
        for fallback_url in com_extract_visible_fallback_candidates(document, document_url):
            if com_is_mycam_fallback_stream(fallback_url, document_url, document):
                ad_seen = True
                log('COM Senderstatus visible MyCam fallback blocked for {}: {}'.format(name, fallback_url))
            else:
                queue_mp4_fallback(fallback_url, document_url)

        document_is_mycam = com_text_has_ad_host(document_url)
        document_has_mycam = com_text_has_ad_host(document)
        if document_is_mycam or document_has_mycam:
            ad_seen = True

        media_candidates, media_kind = com_extract_real_media_candidates(document, document_url, name)
        if media_candidates:
            real_prepared = []
            for streamurl in media_candidates:
                for variant in com_stream_variants(streamurl, name):
                    if (not com_is_known_real_stream(variant)) and com_is_mycam_fallback_stream(variant, document_url, document):
                        ad_seen = True
                        log('COM Senderstatus static MyCam/Redtraffic blocked for {}: {}'.format(name, variant))
                        continue
                    if '.mp4' in (variant or '').lower():
                        queue_mp4_fallback(variant, document_url)
                        continue
                    finalurl = com_build_final_stream_url(variant, document_url)
                    real_prepared.append(com_prepared_item(finalurl, variant, document_url, 'real'))
                    log('COM Senderstatus provenance REAL for {}: {}'.format(name, variant))
            if real_prepared:
                log('COM Senderstatus prepared {} {} REAL variant(s) for {} from depth {} document {}'.format(
                    len(real_prepared), media_kind or 'media', name, depth, document_url
                ))
                return real_prepared, ''
        else:
            no_m3u8_seen = True

        # One nested level is enough for the historic /tv/*.php -> player
        # structure while keeping diagnostics bounded and fast.
        if depth < 2:
            for iframeurl in nested_iframes:
                if not iframeurl or iframeurl in visited:
                    continue
                if com_text_has_ad_host(iframeurl):
                    ad_seen = True
                    log('COM Senderstatus MyCam/ad iframe URL blocked for {}: {}'.format(name, iframeurl))
                    continue
                try:
                    iframehtml = browser_get(opener, iframeurl, document_url)
                    queue.append((iframehtml, iframeurl, depth + 1))
                except Exception as e:
                    log('COM Senderstatus iframe load error for {} | depth {} | {}: {}'.format(name, depth + 1, iframeurl, e), xbmc.LOGERROR)

    if queue:
        log('COM Senderstatus diagnostic document limit reached for {}: {} documents'.format(name, max_documents), xbmc.LOGWARNING)

    if fallback_prepared:
        log('COM Senderstatus prepared {} MP4 FALLBACK variant(s) after exhausting REAL for {}'.format(len(fallback_prepared), name))
        return fallback_prepared, 'visible_fallback'

    if ad_seen:
        log('COM Senderstatus no REAL after deep search for {} | reason=mycamtv_ad_only | documents={}'.format(name, len(visited)))
        return [], 'mycamtv_ad_only'
    if no_m3u8_seen:
        log('COM Senderstatus no REAL after deep search for {} | reason=no_m3u8 | documents={}'.format(name, len(visited)))
        return [], 'no_m3u8'
    log('COM Senderstatus no REAL after deep search for {} | reason=no_stream | documents={}'.format(name, len(visited)))
    return [], 'no_stream'


class SenderStatusPlayer(xbmc.Player):
    def __init__(self, prefix='Senderstatus'):
        try:
            super(SenderStatusPlayer, self).__init__()
        except TypeError:
            xbmc.Player.__init__(self)

        self.prefix = prefix
        self.started = False
        self.av_started = False
        self.ended = False
        self.stopped = False
        self.error = False

    def onPlayBackStarted(self):
        self.started = True
        log('{} player callback: started'.format(self.prefix))

    def onAVStarted(self):
        self.av_started = True
        log('{} player callback: AV started'.format(self.prefix))

    def onPlayBackEnded(self):
        self.ended = True
        log('{} player callback: ended'.format(self.prefix))

    def onPlayBackStopped(self):
        self.stopped = True
        log('{} player callback: stopped'.format(self.prefix))

    def onPlayBackError(self):
        self.error = True
        log('{} player callback: error'.format(self.prefix), xbmc.LOGERROR)


def senderstatus_close_playback_error_dialogs(log_prefix='Senderstatus'):
    prefix = str(log_prefix or '').upper()
    if not (prefix.startswith('COM') or prefix.startswith('CLICK') or prefix.startswith('FUCKFLIX') or prefix.startswith('OXAX')):
        return
    for dialog_name in ('okdialog', 'yesnodialog'):
        try:
            xbmc.executebuiltin('Dialog.Close({},true)'.format(dialog_name))
        except Exception:
            pass


def senderstatus_wait_for_player(player, start_timeout=8, play_seconds=2, stable_seconds=0.8, progress=None, progress_message='', log_prefix='Senderstatus'):
    start = time.time()
    stable_since = None

    while time.time() - start < start_timeout:
        senderstatus_close_playback_error_dialogs(log_prefix)

        if oxax_autotest_cancelled(progress):
            return False

        if getattr(player, 'error', False):
            senderstatus_close_playback_error_dialogs(log_prefix)
            return False

        if (getattr(player, 'ended', False) or getattr(player, 'stopped', False)) and not getattr(player, 'av_started', False):
            senderstatus_close_playback_error_dialogs(log_prefix)
            return False

        playing_video = False
        try:
            playing_video = bool(player.isPlayingVideo())
        except Exception:
            playing_video = False

        real_started = bool(getattr(player, 'av_started', False) or playing_video)

        if real_started:
            if stable_since is None:
                stable_since = time.time()
                log('{} real playback detected - confirming stability'.format(log_prefix))

            if time.time() - stable_since >= stable_seconds:
                hold_start = time.time()
                log('{} playback confirmed - holding for {} seconds'.format(log_prefix, play_seconds))

                while time.time() - hold_start < play_seconds:
                    senderstatus_close_playback_error_dialogs(log_prefix)
                    if oxax_autotest_cancelled(progress):
                        return False

                    if getattr(player, 'error', False) or getattr(player, 'ended', False) or getattr(player, 'stopped', False):
                        return False

                    try:
                        if progress and progress_message:
                            remaining = int(play_seconds - (time.time() - hold_start))
                            progress.update(0, progress_message + '\nLäuft noch ca. {} Sekunden...'.format(max(0, remaining)))
                    except Exception:
                        pass

                    time.sleep(0.35)

                return True
        else:
            stable_since = None

        time.sleep(0.25)

    return False


def com_autotest_wait(seconds, progress=None, message=''):
    end = time.time() + max(0.0, float(seconds))
    while time.time() < end:
        if oxax_autotest_cancelled(progress):
            return False
        try:
            if progress and message:
                progress.update(0, '{}\nNoch ca. {:.1f}s...'.format(message, max(0.0, end - time.time())))
        except Exception:
            pass
        time.sleep(0.3)
    return True


def com_autotest_uses_safe_profile(name, attempt=1):
    return (
        attempt > 1
        or com_needs_slow_fresh_retry(name)
        or com_allows_mp4_last_resort(name)
        or com_needs_named_child_playlist(name)
        or com_needs_strict_child_segment(name)
    )


def com_autotest_warmup_for(name, attempt=1):
    return COM_AUTOTEST_INITIAL_WARMUP if com_autotest_uses_safe_profile(name, attempt) else COM_AUTOTEST_FAST_WARMUP


def com_autotest_start_timeout_for(name, attempt=1):
    return COM_AUTOTEST_START_TIMEOUT if com_autotest_uses_safe_profile(name, attempt) else COM_AUTOTEST_FAST_START_TIMEOUT


def com_autotest_confirm_seconds_for(name, attempt=1, source_kind='real'):
    named = com_visible_confirm_seconds(name)
    if named != float(COM_AUTOTEST_PLAY_SECONDS):
        return named
    if source_kind == 'visible_fallback' or com_autotest_uses_safe_profile(name, attempt):
        return float(COM_AUTOTEST_PLAY_SECONDS)
    return float(COM_AUTOTEST_FAST_PLAY_SECONDS)


def com_autotest_try_channel(name, url, progress=None, channel_index=0, channel_total=0):
    if com_needs_slow_fresh_retry(name):
        max_attempts = COM_SLOW_FRESH_MAX_ATTEMPTS
    elif com_allows_mp4_last_resort(name):
        max_attempts = COM_MP4_LAST_RESORT_MAX_ATTEMPTS
    else:
        max_attempts = COM_AUTOTEST_MAX_ATTEMPTS

    last_reason = ''

    if com_needs_slow_fresh_retry(name):
        log('COM Senderstatus slow fresh retry enabled for {}: {} attempts'.format(name, max_attempts))
    elif com_allows_mp4_last_resort(name):
        log('COM Senderstatus verified-MP4 fresh retry enabled for {}: {} attempts; unverified MP4 playback disabled'.format(name, max_attempts))

    for attempt in range(1, max_attempts + 1):
        if oxax_autotest_cancelled(progress):
            return False, attempt - 1, 'cancelled'

        try:
            if progress:
                percent = int((max(channel_index - 1, 0) * 100) / max(channel_total, 1))
                progress.update(percent, 'COM: {} ({}/{})\nVersuch {}/{}'.format(name, channel_index, channel_total, attempt, max_attempts))
        except Exception:
            pass

        try:
            prepared, prepare_reason = com_prepare_stream_for_autotest(name, url)
        except Exception as e:
            log('COM Senderstatus prepare error for {}: {}'.format(name, e), xbmc.LOGERROR)
            prepared, prepare_reason = [], 'prepare_error'

        last_reason = prepare_reason or last_reason

        if not prepared:
            if prepare_reason == 'mycamtv_ad_only':
                notify('COM nur Werbevideo/MyCamTV: {}'.format(name), False)
                log('COM Senderstatus ad-only/mycamtv for {}'.format(name))
                return False, attempt, 'mycamtv_ad_only'

            notify('COM Stream nicht vorbereitet: {}'.format(name), False)
            time.sleep(0.25)
            continue

        ok = False

        # v48: Freshly generated Aistr tokens can exist in the iframe HTML
        # before the backend route is actually ready. Give the website the
        # same short settling time a browser/player naturally gets.
        warmup = com_autotest_warmup_for(name, attempt)
        log('COM Senderstatus {} warmup before preflight for {} attempt {}: {:.1f} seconds'.format(
            'SAFE' if com_autotest_uses_safe_profile(name, attempt) else 'FAST', name, attempt, warmup
        ))
        if not com_autotest_wait(
            warmup,
            progress=progress,
            message='COM: {} ({}/{})\nWebsite-/Token-Pause vor Versuch {}/{}'.format(name, channel_index, channel_total, attempt, max_attempts)
        ):
            return False, attempt - 1, 'cancelled'

        for variant_index, prepared_item in enumerate(prepared, 1):
            finalurl, streamurl, iframeurl, source_kind = com_unpack_prepared(prepared_item)
            if oxax_autotest_cancelled(progress):
                return False, attempt - 1, 'cancelled'

            if com_needs_slow_fresh_retry(name):
                try:
                    time.sleep(max(0.0, float(COM_SLOW_FRESH_PREFLIGHT_WARMUP)))
                except Exception:
                    pass

            allow_unverified_mp4 = False

            preflight_result = com_manifest_preflight_ok(
                streamurl,
                iframeurl,
                name,
                allow_unverified_mp4=allow_unverified_mp4
            )
            if not preflight_result:
                # Nicht an Kodi uebergeben, sonst kommt bei 404/manifestLoadError
                # wieder das blockierende 'Wiedergabe nicht moeglich'-Popup.
                last_reason = 'preflight_rejected'
                time.sleep(0.25)
                continue

            play_streamurl = streamurl
            play_finalurl = finalurl
            if isinstance(preflight_result, str):
                play_streamurl = preflight_result
                play_finalurl = com_build_final_stream_url(play_streamurl, iframeurl)
                if '.mp4' in play_streamurl.lower():
                    log('COM Senderstatus using unverified website MP4 last-resort for {}: {}'.format(name, play_streamurl), xbmc.LOGWARNING)
                else:
                    log('COM Senderstatus using child playlist for {}: {}'.format(name, play_streamurl))

            log('COM Senderstatus playing {} attempt {} variant {}/{}: {}'.format(name, attempt, variant_index, len(prepared), play_streamurl))

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
                time.sleep(0.25)
            except Exception:
                pass

            player = SenderStatusPlayer('COM Senderstatus')
            item = xbmcgui.ListItem(name)

            try:
                item.setProperty('IsPlayable', 'true')
            except Exception:
                pass

            if com_needs_strict_child_segment(name):
                try:
                    item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                    log('COM safe HLS ListItem enabled for {}'.format(name))
                except Exception:
                    pass

            gateway_isa = fuckflix_is_api_gateway_url(play_streamurl)
            if gateway_isa:
                configure_xlivetv_isa_item(item, iframeurl, BASE_COM.rstrip('/'), 'COM Einzelstart')

            try:
                player.play(play_streamurl if gateway_isa else play_finalurl, item)
            except Exception as e:
                log('COM Senderstatus player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
                time.sleep(0.25)
                continue

            confirm_seconds = com_autotest_confirm_seconds_for(name, attempt, source_kind)
            selected_start_timeout = 5 if gateway_isa else com_autotest_start_timeout_for(name, attempt)
            if confirm_seconds != float(COM_AUTOTEST_PLAY_SECONDS):
                log('COM Senderstatus adaptive visible confirmation for {}: {:.1f} seconds'.format(name, confirm_seconds))
            log('COM Senderstatus {} start timeout for {} attempt {}: {} seconds'.format(
                'SAFE' if com_autotest_uses_safe_profile(name, attempt) else 'FAST', name, attempt, selected_start_timeout
            ))

            ok = senderstatus_wait_for_player(
                player,
                start_timeout=selected_start_timeout,
                play_seconds=confirm_seconds,
                stable_seconds=COM_AUTOTEST_STABLE_SECONDS,
                progress=progress,
                progress_message='COM: {} ({}/{})\nVariante {}/{}'.format(name, channel_index, channel_total, variant_index, len(prepared)),
                log_prefix='COM Senderstatus'
            )

            try:
                if player.isPlaying():
                    player.stop()
            except Exception:
                pass

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
            except Exception:
                pass

            click_autotest_sleep(CLICK_AUTOTEST_KODI_CLEANUP_PAUSE, progress, 'COM Player-Cleanup: {}'.format(name))

            if ok:
                ok_kind = 'visible_fallback' if source_kind == 'visible_fallback' else 'real'
                ok_label = 'FALLBACK' if ok_kind == 'visible_fallback' else 'REAL'
                log('COM Senderstatus OK {} for {} on attempt {} variant {}'.format(
                    ok_label,
                    name,
                    attempt,
                    variant_index
                ))
                if COM_AUTOTEST_OK_NOTIFICATION:
                    notify('COM OK {}: {} | V{} | Var{} | {:.1f}s'.format(
                        ok_label,
                        name,
                        attempt,
                        variant_index,
                        float(confirm_seconds)
                    ), False)
                return True, attempt, ok_kind

            log('COM Senderstatus no playback for {} on attempt {} variant {}'.format(name, attempt, variant_index), xbmc.LOGERROR)
            last_reason = 'no_playback'

        if com_needs_slow_fresh_retry(name) and last_reason == 'preflight_rejected' and attempt < max_attempts:
            com_slow_fresh_retry_sleep(name, attempt, max_attempts, progress=progress)
            continue

        notify('COM Stream nicht verfuegbar: {}'.format(name), False)
        if attempt < max_attempts and not com_needs_slow_fresh_retry(name):
            log('COM Senderstatus cooldown before normal fresh retry for {}: {:.1f} seconds'.format(name, COM_AUTOTEST_RETRY_DELAY))
            if not com_autotest_wait(
                COM_AUTOTEST_RETRY_DELAY,
                progress=progress,
                message='COM: {} ({}/{})\nPause vor frischem Versuch {}/{}'.format(name, channel_index, channel_total, attempt + 1, max_attempts)
            ):
                return False, attempt, 'cancelled'
        else:
            time.sleep(0.25)

    return False, max_attempts, last_reason or 'no_playback'


@site.register()
def AutoTest_COM(url, close_directory=True):
    monitor = xbmc.Monitor()
    progress = None
    ok_count = 0
    failed = []
    skipped = []
    ad_only = []
    fallback_ok = []
    page_count = 0

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('COM Senderstatus prüfen', 'Lade Pages...')
    except Exception:
        progress = None

    try:
        channels, page_count = com_fetch_channels_for_autotest(progress=progress)

        if not channels:
            notify('COM Senderstatus: keine Sender gefunden', True)
            return

        notify('COM Page 1-5 Test startet: {} Sender / {} Pages'.format(len(channels), page_count), False)

        for idx, (name, videourl, img) in enumerate(channels, 1):
            if monitor.abortRequested() or oxax_autotest_cancelled(progress):
                log('COM Senderstatus cancelled by user/abort')
                break

            start_percent = int(max(0, min(99, ((idx - 1) * 100.0) / max(1, len(channels)))))
            progress = senderstatus_reopen_progress(
                progress,
                'COM Senderstatus prüfen',
                'COM: {} ({}/{})\nStarte Senderanalyse...'.format(name, idx, len(channels)),
                start_percent,
                'COM Senderstatus'
            )
            log('COM Senderstatus channel {}/{}: {} | {}'.format(idx, len(channels), name, videourl))

            if com_is_known_website_broken(name):
                skipped.append(name)
                log('COM Senderstatus skip known website issue: {}'.format(name))
                try:
                    if progress:
                        percent = int((idx * 100) / max(len(channels), 1))
                        progress.update(percent, 'COM übersprungen: {}\nBekanntes Website-Problem'.format(name))
                except Exception:
                    pass
                ok = False
                used_attempts = 0
                reason = 'skipped'
            else:
                ok, used_attempts, reason = com_autotest_try_channel(
                    name,
                    videourl,
                    progress=progress,
                    channel_index=idx,
                    channel_total=len(channels)
                )

                if ok:
                    ok_count += 1
                    if reason == 'visible_fallback':
                        fallback_ok.append(name)
                elif reason == 'mycamtv_ad_only':
                    ad_only.append(name)
                    log('COM Senderstatus classified as mycamtv/ad-only: {}'.format(name))
                else:
                    failed.append(name)

            percent = int((idx * 100) / max(len(channels), 1))
            progress = senderstatus_reopen_progress(
                progress,
                'COM Senderstatus prüfen',
                'COM fertig: {} ({}/{})\nOK: {} | Fallback-OK: {} | Fehler: {} | Skip: {} | Ad: {}'.format(
                    name, idx, len(channels), ok_count, len(fallback_ok), len(failed), len(skipped), len(ad_only)
                ),
                percent,
                'COM Senderstatus'
            )

            if ok and reason == 'real' and used_attempts == 1:
                channel_pause = COM_AUTOTEST_FAST_PAUSE_SECONDS
            elif ok:
                channel_pause = COM_AUTOTEST_SAFE_PAUSE_SECONDS
            else:
                channel_pause = COM_AUTOTEST_FAILED_PAUSE_SECONDS
            log('COM adaptive pause after {}: {:.1f}s'.format(name, channel_pause))
            pause_ticks = int(max(channel_pause, 0) * 2)
            for _ in range(max(1, pause_ticks)):
                if monitor.abortRequested() or oxax_autotest_cancelled(progress):
                    break
                time.sleep(0.5)

    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass

    testable_total = ok_count + len(failed)
    total_channels = len(channels) if 'channels' in locals() else testable_total + len(skipped) + len(ad_only)
    status_msg = 'COM Senderstatus v77 summary: {}/{} testbare Sender OK | total: {} | pages: {} | failed: {} | skipped: {} | ad_only: {} | fallback_ok: {}'.format(
        ok_count,
        testable_total,
        total_channels,
        page_count,
        ', '.join(failed) if failed else '-',
        ', '.join(skipped) if skipped else '-',
        ', '.join(ad_only) if ad_only else '-',
        ', '.join(fallback_ok) if fallback_ok else '-'
    )
    log(status_msg)

    if failed:
        notify('COM Senderstatus: {}/{} OK, {} Fallback-OK, {} Fehler, {} übersprungen'.format(ok_count, testable_total, len(fallback_ok), len(failed), len(skipped)), True)
    else:
        notify('COM Senderstatus: {}/{} OK, {} Fallback-OK, {} übersprungen'.format(ok_count, testable_total, len(fallback_ok), len(skipped)), False)

    if close_directory:
        senderstatus_final_cleanup('COM Senderstatus', close_directory=True)


# -------------------------------------------------------------------------
# Senderstatus: adult-tv-channels.click
# -------------------------------------------------------------------------

def click_parse_channels_from_html(html, page_url):
    html = html or ''
    channels = []
    seen = set()

    cards = re.findall(
        r'<!-- begin post -->\s*<div class="card">(.*?)<!-- end post -->',
        html,
        re.DOTALL | re.IGNORECASE
    )

    if not cards:
        cards = re.findall(
            r'<div[^>]+class=["\'][^"\']*card[^"\']*["\'][^>]*>(.*?)</div>\s*</div>\s*</div>',
            html,
            re.DOTALL | re.IGNORECASE
        )

    for card in cards:
        link = re.search(r'<a[^>]+href=["\']([^"\']+)["\']', card, re.IGNORECASE | re.DOTALL)
        if not link:
            continue

        videourl = urljoin(page_url, html_unescape(link.group(1)))
        if not videourl or videourl in seen:
            continue

        seen.add(videourl)

        img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', card, re.IGNORECASE | re.DOTALL)
        img = urljoin(page_url, html_unescape(img_match.group(1))) if img_match else ''

        title_match = re.search(
            r'<h[1-6][^>]*class=["\'][^"\']*(?:card-title|entry-title)[^"\']*["\'][^>]*>.*?<a[^>]*>(.*?)</a>',
            card,
            re.IGNORECASE | re.DOTALL
        )

        if title_match:
            name = clean_text(title_match.group(1))
        else:
            name = videourl.rstrip('/').split('/')[-1].replace('-', ' ').title()

        channels.append((name, videourl, img))

    # Fallback fuer andere WordPress-/Bootstrap-Layouts.
    if not channels:
        for match in re.finditer(
            r'<a[^>]+href=["\'](https?://adult-tv-channels\.click/[^"\']+/)["\'][^>]*>(.*?)</a>',
            html,
            re.IGNORECASE | re.DOTALL
        ):
            videourl = html_unescape(match.group(1))
            if videourl in seen:
                continue
            name = clean_text(match.group(2)) or videourl.rstrip('/').split('/')[-1].replace('-', ' ').title()
            if not name or name.lower() in ('next page', 'older posts', 'read more'):
                continue
            seen.add(videourl)
            channels.append((name, videourl, ''))

    return channels


def click_find_next_page_url(html, page_url):
    html = html or ''
    patterns = [
        r'<link[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        r'<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\']next["\']',
        r'<a[^>]+class=["\'][^"\']*(?:next|older-posts|nextpostslink)[^"\']*["\'][^>]+href=["\']([^"\']+)["\']',
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]+class=["\'][^"\']*(?:next|older-posts|nextpostslink)[^"\']*["\']',
    ]

    for pattern in patterns:
        match = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
        if match:
            return urljoin(page_url, html_unescape(match.group(1)))

    return None


def click_fetch_channels_for_autotest(progress=None):
    channels = []
    seen_pages = set()
    seen_channels = set()
    page_url = BASE_CLICK
    page_count = 0

    while page_url and page_url not in seen_pages and page_count < CLICK_AUTOTEST_MAX_PAGES and len(channels) < CLICK_AUTOTEST_MAX_CHANNELS:
        seen_pages.add(page_url)
        page_count += 1

        try:
            if progress:
                progress.update(0, 'CLICK: Lade Page {}...'.format(page_count))
        except Exception:
            pass

        try:
            html = utils.getHtml(page_url, BASE_CLICK)
        except Exception as e:
            log('CLICK Senderstatus page load error page {} {}: {}'.format(page_count, page_url, e), xbmc.LOGERROR)
            break

        parsed = click_parse_channels_from_html(html, page_url)
        added = 0

        for name, videourl, img in parsed:
            if not videourl or videourl in seen_channels:
                continue
            seen_channels.add(videourl)
            channels.append((name, videourl, img))
            added += 1
            if len(channels) >= CLICK_AUTOTEST_MAX_CHANNELS:
                break

        log('CLICK Senderstatus page {}: {} neue Sender | total {}'.format(page_count, added, len(channels)))
        page_url = click_find_next_page_url(html, page_url)

    log('CLICK Senderstatus channels: {} from {} pages'.format(len(channels), page_count))
    return channels, page_count


def click_stream_extra_headers(streamurl):
    headers = {'Accept': '*/*'}

    if 'aistr.xyz' in (streamurl or ''):
        headers['verifypeer'] = 'false'
        headers['verifyhost'] = 'false'

    return headers


def click_header_profile(label, referer=None, origin=None, skip_preflight=False):
    profile = {'label': label, 'referer': referer, 'origin': origin}
    if skip_preflight:
        profile['skip_preflight'] = True
    return profile


def click_stream_origin(streamurl):
    try:
        parsed = urlparse(streamurl or '')
        if parsed.scheme and parsed.netloc:
            return parsed.scheme + '://' + parsed.netloc
    except Exception:
        pass
    return ''


def click_stream_header_profiles(streamurl, referer, name=''):
    streamurl = streamurl or ''
    ref = referer or BASE_CLICK
    base_origin = BASE_CLICK.rstrip('/')
    stream_origin = click_stream_origin(streamurl)
    strict = click_is_strict_tv_name(name)
    lower = streamurl.lower()

    profiles = []

    def add(label, ref_value, origin_value):
        key = (ref_value or '', origin_value or '')
        for profile in profiles:
            if (profile.get('referer') or '', profile.get('origin') or '') == key:
                return
        profiles.append(click_header_profile(label, ref_value, origin_value))

    # v37: Kein preflight-skip fuer Babes mehr. Der no-extension Child-Pfad
    # erzeugte in v35 403/Popup. Babes wird nur noch ueber sicheren Manifest-
    # Preflight bewertet.

    # Standard wie bisher. Fuer MyCam/Redtraffic-Karten reicht das und bleibt schnell.
    add('page+origin', ref, base_origin)

    # v37: Problem-Sender mit Master/Child-Demuxer-Problemen werden bewusst
    # schlank getestet. Mehr Header-Profile haben im Log nur weitere Kodi-
    # Fehlstarts/Popups erzeugt, nicht bessere Ergebnisse.
    if click_single_kodi_start_name(name):
        return profiles

    # Nur fuer echte TV-/Sonderstreams breiter testen. Genau diese Kandidaten
    # scheiterten im Log entweder mit aistr-403 oder mit Kodi-Demuxer-Abbruch.
    if strict or 'aistr.xyz' in lower or 'skygo.mn' in lower or 'streamlock.net' in lower:
        add('page-no-origin', ref, None)
        add('base-no-origin', BASE_CLICK, None)
        add('bare', None, None)

        # Letzter Versuch: manche HLS-Server akzeptieren nur ihre eigene Origin.
        if stream_origin and 'adult-tv-channels.click' not in stream_origin:
            add('stream-origin', ref, stream_origin)

    return profiles


def click_profile_label(profile):
    try:
        return profile.get('label') or 'default'
    except Exception:
        return 'default'


def click_profile_http_headers(streamurl, referer=None, profile=None):
    if not profile:
        profile = click_header_profile('page+origin', referer or BASE_CLICK, BASE_CLICK.rstrip('/'))

    headers = {
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Connection': 'close',
    }

    ref = profile.get('referer')
    origin = profile.get('origin')

    if ref:
        headers['Referer'] = ref

    if origin:
        headers['Origin'] = origin.rstrip('/')

    if '.mp4' in (streamurl or '').lower():
        headers['Range'] = 'bytes=0-0'

    return headers


def click_profile_kodi_url(streamurl, profile=None):
    if not profile:
        profile = click_header_profile('page+origin', BASE_CLICK, BASE_CLICK.rstrip('/'))

    headers = {
        'User-Agent': UA,
        'Accept': '*/*',
    }

    ref = profile.get('referer')
    origin = profile.get('origin')

    if ref:
        headers['Referer'] = ref

    if origin:
        headers['Origin'] = origin.rstrip('/')

    if 'aistr.xyz' in (streamurl or ''):
        headers['verifypeer'] = 'false'
        headers['verifyhost'] = 'false'

    return streamurl + '|' + urlencode(headers)


def click_build_final_stream_url(streamurl, referer, profile=None):
    if fuckflix_is_api_gateway_url(streamurl):
        return streamurl
    if profile is None:
        profile = click_header_profile('page+origin', referer or BASE_CLICK, BASE_CLICK.rstrip('/'))
    return click_profile_kodi_url(streamurl, profile)


def click_preflight_headers(streamurl, referer, profile=None):
    return click_profile_http_headers(streamurl, referer, profile)


def click_prepared_item(finalurl, streamurl, referer, profile):
    return (finalurl, streamurl, referer, profile)


def click_unpack_prepared(item):
    if len(item) >= 4:
        return item[0], item[1], item[2], item[3]
    # Rueckwaertskompatibilitaet fuer alte Tupel
    finalurl, streamurl, referer = item
    return finalurl, streamurl, referer, click_header_profile('page+origin', referer or BASE_CLICK, BASE_CLICK.rstrip('/'))


def click_first_master_child_url(base_url, manifest_data):
    try:
        lines = [line.strip() for line in (manifest_data or '').splitlines()]
        for idx, line in enumerate(lines):
            if line.upper().startswith('#EXT-X-STREAM-INF'):
                for child in lines[idx + 1:]:
                    if child and not child.startswith('#'):
                        return urljoin(base_url, child)
        return ''
    except Exception:
        return ''



def click_manifest_uri_from_tag(manifest_data, tag_name):
    try:
        pattern = r'^' + re.escape(tag_name) + r'.*?URI=["\']([^"\']+)["\']'
        match = re.search(pattern, manifest_data or '', re.IGNORECASE | re.MULTILINE)
        return html_unescape(match.group(1)).strip() if match else ''
    except Exception:
        return ''


def click_first_media_segment_url(base_url, manifest_data):
    try:
        for line in (manifest_data or '').splitlines():
            item = line.strip()
            if not item or item.startswith('#'):
                continue
            lower = item.lower().split('?', 1)[0]
            # Another manifest is not a media segment.
            if lower.endswith('.m3u8') or '.m3u8?' in item.lower():
                continue
            return urljoin(base_url, item)
        return ''
    except Exception:
        return ''



def click_resolve_nested_media_playlist(opener, playlist_url, playlist_data, referer, name='', profile=None):
    """Follow nested HLS masters until a real media playlist is reached.

    Miami TV redirects from the Streamlock master to an AWS MediaTailor master.
    The first non-comment line of that response is another .m3u8, not a media
    segment. v53 therefore rejected a healthy stream as child_no_segment.

    All requests are bounded and the maximum depth is small, so a redirect loop
    or slow backend is rejected before Kodi/LibreELEC is opened.
    """
    current_url = playlist_url
    current_data = playlist_data or ''
    seen = set()

    for depth in range(CLICK_NESTED_HLS_MAX_DEPTH + 1):
        if not current_url or current_url in seen:
            log('CLICK nested HLS rejected loop/empty for {} | {}'.format(name, current_url), xbmc.LOGERROR)
            click_mark_preflight_error(profile, 'uncertain', 'nested_loop')
            return '', ''
        seen.add(current_url)

        # A media playlist has no EXT-X-STREAM-INF. It may contain long
        # MediaTailor metadata/ad tags before its first segment, so keep the
        # larger bounded read instead of the old 900-byte sample.
        if '#EXT-X-STREAM-INF' not in current_data.upper():
            log('CLICK nested HLS media playlist resolved depth {} for {} -> {}'.format(depth, name, current_url))
            return current_url, current_data

        next_url = click_first_master_child_url(current_url, current_data)
        if not next_url:
            log('CLICK nested HLS rejected master without child depth {} for {} | {}'.format(depth, name, current_url), xbmc.LOGERROR)
            click_mark_preflight_error(profile, 'uncertain', 'nested_no_child')
            return '', ''

        if click_is_ad_stream_url(next_url, name) or click_is_senderstatus_dangerous_stream(next_url, name):
            log('CLICK nested HLS rejected ad/dangerous depth {} for {} | {}'.format(depth, name, next_url), xbmc.LOGERROR)
            click_mark_preflight_error(profile, 'blocked', 'nested_blocked')
            return '', ''

        try:
            req = Request(next_url, headers=click_preflight_headers(next_url, referer, profile))
            response = opener.open(req, timeout=CLICK_CHILD_SEGMENT_PREFLIGHT_TIMEOUT)
            final_url = response.geturl()

            if click_is_ad_stream_url(final_url, name) or click_is_senderstatus_dangerous_stream(final_url, name):
                try:
                    response.close()
                except Exception:
                    pass
                log('CLICK nested HLS rejected redirected ad/dangerous depth {} for {} | {}'.format(depth, name, final_url), xbmc.LOGERROR)
                click_mark_preflight_error(profile, 'blocked', 'nested_redirect_blocked')
                return '', ''

            data = response.read(CLICK_NESTED_HLS_READ_BYTES).decode('utf-8', 'ignore')
            try:
                response.close()
            except Exception:
                pass

            if '#EXTM3U' not in data:
                head = (data or '')[:160].replace('\n', ' ').replace('\r', ' ')
                log('CLICK nested HLS rejected non-HLS depth {} for {} | {} | {}'.format(depth, name, final_url, head), xbmc.LOGERROR)
                click_mark_preflight_error(profile, 'uncertain', 'nested_non_hls')
                return '', ''

            log('CLICK nested HLS followed depth {} for {} -> {}'.format(depth + 1, name, final_url))
            current_url = final_url
            current_data = data
        except HTTPError as e:
            click_mark_preflight_error(profile, getattr(e, 'code', '?'), 'nested_http')
            log('CLICK nested HLS rejected HTTP {} depth {} for {} | {}'.format(getattr(e, 'code', '?'), depth, name, next_url), xbmc.LOGERROR)
            return '', ''
        except Exception as e:
            click_mark_preflight_error(profile, 'uncertain', 'nested_uncertain')
            log('CLICK nested HLS rejected uncertain depth {} for {} | {}: {}'.format(depth, name, next_url, e), xbmc.LOGERROR)
            return '', ''

    log('CLICK nested HLS rejected max depth for {} | {}'.format(name, current_url), xbmc.LOGERROR)
    click_mark_preflight_error(profile, 'uncertain', 'nested_max_depth')
    return '', ''


def click_child_media_preflight_ok(opener, child_url, child_data, referer, name='', profile=None):
    """Validate key/init-map and the first real segment before Kodi playback.

    A manifest-only 200 response is not enough for the two Miami streams: the
    backend can expose a valid child while its key or first segment is missing
    or stalls. Kodi/LibreELEC may then block deep inside the demuxer. This test
    performs small bounded reads and rejects the attempt before player.play().
    """
    checks = []

    key_uri = click_manifest_uri_from_tag(child_data, '#EXT-X-KEY:')
    if key_uri:
        checks.append(('key', urljoin(child_url, key_uri), False))

    map_uri = click_manifest_uri_from_tag(child_data, '#EXT-X-MAP:')
    if map_uri:
        checks.append(('init', urljoin(child_url, map_uri), True))

    segment_url = click_first_media_segment_url(child_url, child_data)
    if not segment_url:
        log('CLICK safe child rejected: no media segment for {} | {}'.format(name, child_url), xbmc.LOGERROR)
        click_mark_preflight_error(profile, 'uncertain', 'child_no_segment')
        return False
    checks.append(('segment', segment_url, True))

    for kind, media_url, use_range in checks:
        if click_is_ad_stream_url(media_url, name) or click_is_senderstatus_dangerous_stream(media_url, name):
            log('CLICK safe child rejected {} ad/dangerous for {} | {}'.format(kind, name, media_url), xbmc.LOGERROR)
            click_mark_preflight_error(profile, 'blocked', 'child_{}_blocked'.format(kind))
            return False

        try:
            headers = click_preflight_headers(media_url, referer, profile)
            if use_range:
                headers['Range'] = 'bytes=0-2047'
            req = Request(media_url, headers=headers)
            response = opener.open(req, timeout=CLICK_CHILD_SEGMENT_PREFLIGHT_TIMEOUT)
            final_url = response.geturl()
            sample = response.read(2048)
            try:
                response.close()
            except Exception:
                pass

            if not sample:
                log('CLICK safe child rejected empty {} for {} | {}'.format(kind, name, final_url), xbmc.LOGERROR)
                click_mark_preflight_error(profile, 'empty', 'child_{}_empty'.format(kind))
                return False

            log('CLICK safe child {} preflight OK for {} -> {} | {} bytes'.format(kind, name, final_url, len(sample)))
        except HTTPError as e:
            click_mark_preflight_error(profile, getattr(e, 'code', '?'), 'child_{}_http'.format(kind))
            log('CLICK safe child rejected {} HTTP {} for {} | {}'.format(kind, getattr(e, 'code', '?'), name, media_url), xbmc.LOGERROR)
            return False
        except Exception as e:
            click_mark_preflight_error(profile, 'uncertain', 'child_{}_uncertain'.format(kind))
            log('CLICK safe child rejected uncertain {} for {} | {}: {}'.format(kind, name, media_url, e), xbmc.LOGERROR)
            return False

    return True


def click_clear_preflight_error(profile):
    try:
        if profile is not None:
            profile.pop('last_preflight_error_code', None)
            profile.pop('last_preflight_error_kind', None)
    except Exception:
        pass


def click_mark_preflight_error(profile, code='', kind=''):
    try:
        if profile is not None:
            profile['last_preflight_error_code'] = str(code or '')
            profile['last_preflight_error_kind'] = kind or ''
    except Exception:
        pass


def click_last_preflight_code(profile):
    try:
        return str(profile.get('last_preflight_error_code') or '')
    except Exception:
        return ''


def click_can_use_child_for_kodi(child_url, manifest_url, name=''):
    """v40: Childs weiter zur Sicherheit pruefen, aber riskante Proxy-Childs
    nicht direkt an Kodi uebergeben.

    Bei .click zeigte der Log: Child-URLs ueber den Website-Proxy mit segment=0
    koennen im Preflight OK sein und danach beim Kodi-Start einen allgemeinen
    Fehler ausloesen. Daher bleibt der Master-Stream fuer Kodi bevorzugt.
    """
    child_l = (child_url or '').lower()
    manifest_l = (manifest_url or '').lower()

    if 'adult-tv-channels.click' in child_l and 'segment=0' in child_l:
        return False

    if 'adult-tv-channels.click' in child_l and 'aistr.xyz' in unquote(child_l):
        return False

    # Babes ist ein Sonderfall: Master scheitert ebenfalls am Demuxer, deshalb
    # darf der gefundene SkyGo-Child weiterhin getestet werden.
    if click_is_babes_legacy_name(name) and 'cdn4.skygo.mn' in child_l:
        return True

    # Fuer externe, stabile HLS-Hosts kann Child-Playback sinnvoll bleiben.
    if 'adult-tv-channels.click' not in child_l and child_l != manifest_l:
        return True

    return False

def click_deep_manifest_preflight(opener, manifest_url, referer, name='', profile=None, manifest_data=''):
    """Prueft bei Master-Playlists auch den ersten Child-Eintrag.

    Viele .click-Proxy-URLs liefern ein gueltiges Master-Manifest, aber der eigentliche
    Child-Stream endet dann mit 403/429 oder Redirect. Kodi zeigt dann gerne ein Popup.
    Deshalb wird der erste Child vorher kurz getestet.
    """
    child_url = click_first_master_child_url(manifest_url, manifest_data)
    if not child_url:
        return True

    allow_visible_fallback = bool(profile and profile.get('allow_visible_fallback'))
    if click_is_ad_stream_url(child_url, name) and not allow_visible_fallback:
        log('CLICK Senderstatus deep preflight rejected child ad/wrong fallback [{}] for {} | {}'.format(click_profile_label(profile), name, child_url), xbmc.LOGERROR)
        return False

    if click_is_senderstatus_dangerous_stream(child_url, name):
        log('CLICK Senderstatus deep preflight rejected dangerous child [{}] for {} | {}'.format(click_profile_label(profile), name, child_url), xbmc.LOGERROR)
        return False

    try:
        req = Request(child_url, headers=click_preflight_headers(child_url, referer, profile))
        response = opener.open(req, timeout=CLICK_AUTOTEST_PREFLIGHT_TIMEOUT)
        final_child_url = response.geturl()

        if click_is_ad_stream_url(final_child_url, name) and not allow_visible_fallback:
            log('CLICK Senderstatus deep preflight rejected redirected child ad/wrong fallback [{}] for {} | {}'.format(click_profile_label(profile), name, final_child_url), xbmc.LOGERROR)
            return False

        child_data = response.read(CLICK_NESTED_HLS_READ_BYTES).decode('utf-8', 'ignore')
        try:
            response.close()
        except Exception:
            pass
        child_head = (child_data or '')[:160].replace('\n', ' ').replace('\r', ' ')
        if '#EXTM3U' in child_data:
            if profile is not None and click_uses_child_playback(name) and click_can_use_child_for_kodi(final_child_url, manifest_url, name):
                playback_child_url = final_child_url
                playback_child_data = child_data

                if click_requires_child_segment_preflight(name):
                    playback_child_url, playback_child_data = click_resolve_nested_media_playlist(
                        opener,
                        final_child_url,
                        child_data,
                        referer,
                        name,
                        profile
                    )
                    if not playback_child_url or not playback_child_data:
                        try:
                            profile.pop('resolved_child_url', None)
                        except Exception:
                            pass
                        log('CLICK Senderstatus safe nested child rejected before Kodi for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                        return False

                    if not click_child_media_preflight_ok(opener, playback_child_url, playback_child_data, referer, name, profile):
                        try:
                            profile.pop('resolved_child_url', None)
                        except Exception:
                            pass
                        log('CLICK Senderstatus safe media child rejected before Kodi for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                        return False
                try:
                    profile['resolved_child_url'] = playback_child_url
                    log('CLICK Senderstatus child playback prepared [{}] for {} -> {}'.format(click_profile_label(profile), name, playback_child_url))
                except Exception:
                    pass
            elif profile is not None and click_uses_child_playback(name):
                try:
                    profile.pop('resolved_child_url', None)
                except Exception:
                    pass
                log('CLICK Senderstatus child playback kept as preflight-only [{}] for {} -> {}'.format(click_profile_label(profile), name, final_child_url))
            log('CLICK Senderstatus deep preflight OK [{}] for {} -> {}'.format(click_profile_label(profile), name, final_child_url))
            return True

        log('CLICK Senderstatus deep preflight rejected child non-HLS [{}] for {} | {} | {}'.format(click_profile_label(profile), name, final_child_url, child_head), xbmc.LOGERROR)
        return False
    except HTTPError as e:
        click_mark_preflight_error(profile, getattr(e, 'code', '?'), 'child_http')
        log('CLICK Senderstatus deep preflight rejected child HTTP {} [{}] for {} | {}'.format(getattr(e, 'code', '?'), click_profile_label(profile), name, child_url), xbmc.LOGERROR)
        return False
    except Exception as e:
        click_mark_preflight_error(profile, 'uncertain', 'child_uncertain')
        log('CLICK Senderstatus deep preflight rejected child uncertain URL [{}] for {} | {}: {}'.format(click_profile_label(profile), name, child_url, e), xbmc.LOGERROR)
        return False


def click_manifest_preflight_ok(streamurl, referer, name='', profile=None):
    click_clear_preflight_error(profile)
    try:
        if profile and profile.get('skip_preflight'):
            log('CLICK Senderstatus preflight skipped [{}] for {} | {}'.format(click_profile_label(profile), name, streamurl))
            return True
    except Exception:
        pass

    allow_visible_fallback = bool(profile and profile.get('allow_visible_fallback'))
    if click_is_ad_stream_url(streamurl, name) and not allow_visible_fallback:
        log('CLICK Senderstatus preflight rejected ad/wrong fallback for {} | {}'.format(name, streamurl), xbmc.LOGERROR)
        return False

    if click_is_senderstatus_dangerous_stream(streamurl, name):
        log('CLICK Senderstatus preflight rejected dangerous/hanging HLS for {} | {}'.format(name, streamurl), xbmc.LOGERROR)
        return False

    # .click v30: Nur HLS/m3u8 als echter Senderstatus. MP4 war im Log ein
    # Werbe-Fallback und wird deshalb nicht mehr an Kodi uebergeben.
    lower_stream = (streamurl or '').lower()
    decoded_lower_stream = unquote(lower_stream)
    if '.m3u8' not in decoded_lower_stream and not ('cdn4.skygo.mn' in decoded_lower_stream and '/babes/hlsv3-fta/babes' in decoded_lower_stream):
        log('CLICK Senderstatus preflight rejected non-HLS for {} | {}'.format(name, streamurl), xbmc.LOGERROR)
        return False

    try:
        opener = com_build_preflight_opener()
        req = Request(streamurl, headers=click_preflight_headers(streamurl, referer, profile))
        response = opener.open(req, timeout=CLICK_AUTOTEST_PREFLIGHT_TIMEOUT)
        final_url = response.geturl()

        if click_is_ad_stream_url(final_url, name) and not allow_visible_fallback:
            log('CLICK Senderstatus preflight rejected redirected ad/wrong fallback [{}] for {} | {}'.format(click_profile_label(profile), name, final_url), xbmc.LOGERROR)
            return False

        data = response.read(900).decode('utf-8', 'ignore')
        head = (data or '')[:160].replace('\n', ' ').replace('\r', ' ')

        if '#EXTM3U' in data:
            if '#EXT-X-STREAM-INF' in data and not click_deep_manifest_preflight(opener, final_url, referer, name, profile, data):
                return False
            log('CLICK Senderstatus preflight OK [{}] for {} -> {} | {}'.format(click_profile_label(profile), name, final_url, head))
            return True

        log('CLICK Senderstatus preflight rejected non-HLS/media [{}] for {} | {} | {}'.format(click_profile_label(profile), name, streamurl, head), xbmc.LOGERROR)
        return False

    except HTTPError as e:
        click_mark_preflight_error(profile, getattr(e, 'code', '?'), 'manifest_http')
        log('CLICK Senderstatus preflight rejected HTTP {} [{}] for {} | {}'.format(getattr(e, 'code', '?'), click_profile_label(profile), name, streamurl), xbmc.LOGERROR)
        return False
    except Exception as e:
        click_mark_preflight_error(profile, 'uncertain', 'manifest_uncertain')
        log('CLICK Senderstatus preflight rejected uncertain URL [{}] for {} | {}: {}'.format(click_profile_label(profile), name, streamurl, e), xbmc.LOGERROR)
        return False

def click_extract_real_media_candidates(html, baseurl, name=''):
    # .click v30: Kein MP4-Fallback mehr. Die im Log sichtbaren MP4s kamen von
    # Werbe-CDNs und zaehlten Sender falsch als OK.
    hls = [u for u in extract_m3u8_candidates(html, baseurl) if not click_is_ad_stream_url(u, name)]
    if hls:
        return hls, 'hls'

    if click_text_has_ad_host(html, name):
        return [], 'ad'

    return [], ''

def click_stream_variants(streamurl, name=''):
    # v32 Diagnose:
    # In v31 wurde die Proxy-URL zwar gesammelt, hier aber sofort wieder
    # entpackt. Dadurch wurde der Website-Proxy nie wirklich getestet.
    # Jetzt behalten wir die rohe Proxy-URL als eigene Variante und testen
    # danach erst die direkte/entpackte HLS-URL plus moegliche aistr-hls-Form.
    raw_streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
    direct_streamurl = unwrap_click_proxy_url(raw_streamurl)
    direct_streamurl = html_unescape(direct_streamurl or '').replace('\\/', '/').strip()
    variants = []

    def add(url):
        url = html_unescape(url or '').replace('\\/', '/').strip()
        if url and url not in variants:
            variants.append(url)

    raw_host = urlparse(raw_streamurl).netloc.lower()
    raw_decoded = unquote(raw_streamurl or '').lower()

    # Website-Proxy zuerst testen, falls vorhanden. Gerade bei .click kann
    # der direkte aistr-Link 403 liefern, waehrend der Proxy eventuell noch
    # passende Cookies/Weiterleitung nutzt.
    if raw_streamurl and raw_streamurl != direct_streamurl and 'adult-tv-channels.click' in raw_host and '.m3u8' in raw_decoded:
        add(raw_streamurl)
        log('CLICK Senderstatus keeping proxy variant for {}: {}'.format(name, raw_streamurl))

    parsed = urlparse(direct_streamurl)

    # v37: Babes no-extension Child nicht mehr direkt testen. In v35 erzeugte
    # dieser Pfad 403 und ein Kodi-Popup. Wenn ein Master-Manifest vorhanden ist,
    # prueft der tiefe Preflight den Child-Eintrag sicher, bevor Kodi ihn bekommt.
    if 'cdn4.skygo.mn' in parsed.netloc.lower() and '/babes/hlsv3-fta/babes' in (parsed.path or '').lower():
        if not (parsed.path or '').lower().endswith('.m3u8'):
            add(direct_streamurl.rstrip('/') + '.m3u8')

    # Wie bei .com: stream.aistr.xyz/live/<id>/playlist.m3u8 kann auf Kodi
    # direkt abbrechen. Fuer .click testen wir die hls-Variante zuerst.
    if 'stream.aistr.xyz' in parsed.netloc:
        match = re.search(r'/live/([^/]+)/playlist\.m3u8', parsed.path or '', re.IGNORECASE)
        if match:
            channel_id = match.group(1)
            query = ('?' + parsed.query) if parsed.query else ''
            add('https://aistr.xyz:28791/hls/{}/playlist.m3u8{}'.format(channel_id, query))

    add(direct_streamurl)
    return variants[:max(1, CLICK_AUTOTEST_STREAM_VARIANTS)]


def click_add_candidate(candidates, seen, streamurl, referer, name='', fallback_candidates=None, allow_visible_fallback=False):
    raw_streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
    unwrapped = unwrap_click_proxy_url(raw_streamurl)
    unwrapped = html_unescape(unwrapped or '').replace('\\/', '/').strip()
    referer = referer or BASE_CLICK

    stream_urls = []

    def add_url(url):
        url = html_unescape(url or '').replace('\\/', '/').strip()
        if url and url not in stream_urls:
            stream_urls.append(url)

    # v31: Proxy-URL nicht sofort verlieren. Bei .click liefern einige echte
    # TV-Kandidaten direkt 403, eventuell funktioniert aber der Website-Proxy
    # oder ein Redirect besser. Der direkte Kandidat bleibt danach weiterhin
    # als zweite Variante erhalten.
    if raw_streamurl and raw_streamurl != unwrapped and 'adult-tv-channels.click' in urlparse(raw_streamurl).netloc:
        add_url(raw_streamurl)

    add_url(unwrapped)

    for candidate_url in stream_urls:
        if not candidate_url:
            continue

        if click_is_ad_stream_url(candidate_url, name):
            log('CLICK Senderstatus skip ad/wrong candidate for {}: {}'.format(name, candidate_url))
            continue

        # .click: Senderstatus ist HLS-only. Proxy-URLs sind erlaubt, wenn sie
        # eine HLS-URL transportieren. MP4 wird bewusst ignoriert.
        lower_candidate = candidate_url.lower()
        if ('.m3u8' not in lower_candidate and '%2fm3u8' not in lower_candidate and 'url=' not in lower_candidate
                and not fuckflix_is_api_gateway_url(candidate_url)):
            log('CLICK Senderstatus skip non-HLS candidate for {}: {}'.format(name, candidate_url))
            continue

        key = (candidate_url, referer)
        if key in seen:
            continue

        seen.add(key)
        if click_is_visible_fallback_stream(candidate_url):
            log('CLICK Senderstatus MyCam/Redtraffic globally blocked for {}: {}'.format(name, candidate_url))
            continue

        candidates.append((candidate_url, referer))

def click_collect_stream_candidates(opener, page_url, name='', allow_visible_fallback=False):
    videosrc = browser_get(opener, page_url, BASE_CLICK)
    candidates = []
    fallback_candidates = []
    seen = set()
    ad_seen = False

    # v71: REAL zuerst. Aktuelle Seiten koennen statisch nur Redtraffic/MyCam
    # enthalten und den echten Sender erst per playerConfig/fetch nachladen.
    for streamurl in site_dynamic_api_stream_candidates(opener, videosrc, page_url, name, 'CLICK'):
        if click_is_visible_fallback_stream(streamurl) or click_is_ad_stream_url(streamurl, name):
            ad_seen = True
            log('CLICK dynamic candidate is blocked MyCam/ad for {}: {}'.format(name, streamurl))
            continue
        click_add_candidate(candidates, seen, streamurl, page_url, name, fallback_candidates, False)

    # Neuer .click-Aufbau: fetch(..., { method:'POST' }) liefert haeufig JSON
    # mit einer HLS-URL oder Proxy-URL. Wichtig: Ad/MP4-Fallbacks werden hier
    # noch vor dem Kodi-Start verworfen.
    for match in re.finditer(
        r"fetch\(\s*['\"]([^'\"]+)['\"]\s*,\s*\{.*?method\s*:\s*['\"]POST['\"]",
        videosrc,
        re.IGNORECASE | re.DOTALL
    ):
        posturl = urljoin(BASE_CLICK, html_unescape(match.group(1)))
        try:
            response = browser_post(opener, posturl, page_url, BASE_CLICK)
            try:
                data = json.loads(response)
                streamurl = json_find_stream_url(data)
            except Exception:
                streamurl = json_find_stream_url(response)

            if streamurl:
                if click_is_ad_stream_url(streamurl, name) or click_is_visible_fallback_stream(streamurl):
                    ad_seen = True
                    log('CLICK Senderstatus POST/JSON returned blocked MyCam/ad stream for {}: {}'.format(name, streamurl))
                else:
                    click_add_candidate(candidates, seen, streamurl, page_url, name, fallback_candidates, False)
        except Exception as e:
            log('CLICK Senderstatus POST/JSON error for {} | {}: {}'.format(name, posturl, e), xbmc.LOGERROR)

    for streamurl in extract_m3u8_candidates(videosrc, page_url):
        if click_is_ad_stream_url(streamurl, name):
            ad_seen = True
            log('CLICK Senderstatus page m3u8 ad/wrong stream ignored for {}: {}'.format(name, streamurl))
            continue
        click_add_candidate(candidates, seen, streamurl, page_url, name, fallback_candidates, allow_visible_fallback)

    # Kein MP4-Fallback fuer .click mehr. MP4 im Log war Werbung.
    if extract_mp4_candidates(videosrc, page_url):
        ad_seen = True
        log('CLICK Senderstatus page MP4 fallback ignored for {}'.format(name))

    iframe_urls = com_extract_iframe_urls(videosrc, page_url)
    for iframeurl in iframe_urls:
        if click_text_has_ad_host(iframeurl, name):
            ad_seen = True
            log('CLICK Senderstatus ignore ad iframe for {}: {}'.format(name, iframeurl))
            continue

        try:
            iframehtml = browser_get(opener, iframeurl, page_url)
        except Exception as e:
            log('CLICK Senderstatus iframe load error for {} | {}: {}'.format(name, iframeurl, e), xbmc.LOGERROR)
            continue

        dynamic_iframe_candidates = site_dynamic_api_stream_candidates(opener, iframehtml, iframeurl, name, 'CLICK')
        for streamurl in dynamic_iframe_candidates:
            if click_is_visible_fallback_stream(streamurl) or click_is_ad_stream_url(streamurl, name):
                ad_seen = True
                log('CLICK iframe dynamic candidate blocked as MyCam/ad for {}: {}'.format(name, streamurl))
                continue
            click_add_candidate(candidates, seen, streamurl, iframeurl, name, fallback_candidates, False)

        media_candidates, media_kind = click_extract_real_media_candidates(iframehtml, iframeurl, name)

        if not media_candidates:
            if click_text_has_ad_host(iframehtml, name):
                ad_seen = True
                log('CLICK Senderstatus iframe has ad/wrong fallback but no usable HLS for {} | {}'.format(name, iframeurl))
            continue

        for streamurl in media_candidates:
            click_add_candidate(candidates, seen, streamurl, iframeurl, name, fallback_candidates, allow_visible_fallback)

    if candidates or fallback_candidates:
        if fallback_candidates:
            log('CLICK Senderstatus queued {} visible fallback candidate(s) after real candidates for {}'.format(len(fallback_candidates), name))
        return candidates + fallback_candidates, ''

    if ad_seen or click_text_has_ad_host(videosrc, name):
        return [], 'mycamtv_ad_only'

    return [], 'no_stream'

def click_prepare_stream_for_autotest(name, url, allow_visible_fallback=False):
    prepared = []
    seen = set()
    last_reason = ''

    # Bis zu zwei frische Seiten-/Token-Laeufe sammeln. Das ist kein sichtbarer
    # Kodi-Retry, sondern verhindert, dass nach einem 403 sofort ein Werbe-HLS
    # als OK gezaehlt wird.
    for pass_no in range(1, max(1, CLICK_REAL_REFRESH_PASSES) + 1):
        pass_prepared = []
        cj = http.cookiejar.CookieJar()
        opener = build_opener(HTTPCookieProcessor(cj))

        try:
            candidates, reason = click_collect_stream_candidates(opener, url, name, allow_visible_fallback)
        except Exception as e:
            log('CLICK Senderstatus collect error for {} pass {}: {}'.format(name, pass_no, e), xbmc.LOGERROR)
            candidates, reason = [], 'no_stream'

        last_reason = reason or last_reason

        if pass_no > 1:
            log('CLICK Senderstatus fresh-token pass {} for {} -> {} candidate(s), reason={}'.format(pass_no, name, len(candidates), reason))

        for streamurl, referer in candidates:
            for variant in click_stream_variants(streamurl, name):
                if click_is_ad_stream_url(variant, name):
                    log('CLICK Senderstatus skip ad variant for {}: {}'.format(name, variant))
                    continue

                if click_is_senderstatus_dangerous_stream(variant, name):
                    log('CLICK Senderstatus skip dangerous/hanging variant for {}: {}'.format(name, variant))
                    continue

                variant_l = (variant or '').lower()
                if ('.m3u8' not in variant_l and not ('cdn4.skygo.mn' in variant_l and '/babes/hlsv3-fta/babes' in variant_l)
                        and not fuckflix_is_api_gateway_url(variant)):
                    log('CLICK Senderstatus skip non-HLS variant for {}: {}'.format(name, variant))
                    continue

                # XLivetv tokens use exactly the sender-page origin/referer.
                profiles = click_stream_header_profiles(variant, referer, name)
                if fuckflix_is_api_gateway_url(variant):
                    profiles = [click_header_profile('xlivetv-isa', referer or url, BASE_CLICK.rstrip('/'))]

                # Mehrere Header-Profile fuer dieselbe URL sind bewusst erlaubt.
                for profile in profiles:
                    profile_key = (variant, referer, click_profile_label(profile), profile.get('referer') or '', profile.get('origin') or '')
                    if profile_key in seen:
                        continue
                    seen.add(profile_key)

                    finalurl = click_build_final_stream_url(variant, referer, profile)
                    pass_prepared.append(click_prepared_item(finalurl, variant, referer, profile))
                    log('CLICK Senderstatus prepared variant {} [{}] for {}: {}'.format(len(prepared) + len(pass_prepared), click_profile_label(profile), name, variant))

                    if len(pass_prepared) >= CLICK_AUTOTEST_STREAM_VARIANTS:
                        break

                if len(pass_prepared) >= CLICK_AUTOTEST_STREAM_VARIANTS:
                    break

            if len(pass_prepared) >= CLICK_AUTOTEST_STREAM_VARIANTS:
                break

        if pass_prepared:
            # Neueste Token/Proxy-Varianten zuerst testen, damit stale Proxy-Varianten
            # keine Kodi-Popups verursachen, bevor ein frischer Kandidat laeuft.
            prepared = pass_prepared + prepared
            if len(prepared) > CLICK_AUTOTEST_STREAM_VARIANTS:
                prepared = prepared[:CLICK_AUTOTEST_STREAM_VARIANTS]

        # Alle Fresh-Token-Passes durchlaufen, damit am Ende die neuesten
        # Kandidaten vorne stehen. Nicht nach dem ersten vollen Pass abbrechen.

    if prepared:
        log('CLICK Senderstatus prepared {} real HLS variant(s) for {}'.format(len(prepared), name))
        return prepared, ''

    return [], last_reason or 'no_stream'

def click_autotest_sleep(seconds, progress=None, message=''):
    seconds = max(float(seconds or 0), 0)
    if seconds <= 0:
        return

    monitor = xbmc.Monitor()
    end_time = time.time() + seconds
    while time.time() < end_time:
        if monitor.abortRequested() or oxax_autotest_cancelled(progress):
            break
        try:
            if progress and message:
                left = max(0, int(round(end_time - time.time())))
                progress.update(0, '{}\nPause: {}s'.format(message, left))
        except Exception:
            pass
        time.sleep(min(0.5, max(0.1, end_time - time.time())))


def click_stop_player_safely(player, name, progress=None, message=''):
    """Stop Kodi once and allow the demuxer/player threads to settle.

    v54 called both player.stop() and PlayerControl(Stop) immediately. For a
    Streamlock URL that was still opening, Kodi could receive Stop at the exact
    moment the demuxer finally opened its first stream. v55 uses only one stop
    path first and waits longer for the three known slow Streamlock channels.
    """
    playing = False
    try:
        playing = bool(player.isPlaying())
    except Exception:
        playing = False

    try:
        if playing:
            player.stop()
        else:
            xbmc.executebuiltin('PlayerControl(Stop)')
    except Exception:
        pass

    settle = CLICK_STREAMLOCK_STOP_SETTLE_SECONDS if click_is_streamlock_slow_start_name(name) else CLICK_AUTOTEST_KODI_CLEANUP_PAUSE
    log('CLICK safe player stop for {} | playing={} | settle={:.1f}s'.format(name, playing, settle))
    click_autotest_sleep(settle, progress, message or 'CLICK Player-Cleanup: {}'.format(name))

    try:
        if player.isPlaying():
            xbmc.executebuiltin('PlayerControl(Stop)')
            click_autotest_sleep(0.45, progress, message or 'CLICK finaler Player-Stop: {}'.format(name))
    except Exception:
        pass


def click_autotest_try_channel(name, url, progress=None, channel_index=0, channel_total=0):
    # v40: Nicht mehr Varianten spammen. Ein Sender darf laenger laden,
    # bei 429 wird bewusst abgewartet und erst danach frisch neu gesammelt.
    # Babes bleibt Sonderfall ohne Fallback, bekommt aber 2 frische Versuche,
    # weil der Child-Stream im Log manchmal erst stabil wird. Alle anderen duerfen
    # bis zu 3 frische echte Stream-Versuche bekommen, bevor sichtbare Fallbacks auftauchen.
    max_attempts = CLICK_BABES_AUTOTEST_MAX_ATTEMPTS if click_is_babes_legacy_name(name) else CLICK_AUTOTEST_MAX_ATTEMPTS
    last_reason = ''

    for attempt in range(1, max_attempts + 1):
        problem_kodi_starts = 0
        visible_fallback_enabled_for_attempt = False
        if oxax_autotest_cancelled(progress):
            return False, attempt - 1, 'cancelled'

        try:
            if progress:
                percent = int((max(channel_index - 1, 0) * 100) / max(channel_total, 1))
                progress.update(percent, 'CLICK: {} ({}/{})\nVersuch {}/{} | Fallback: {}'.format(name, channel_index, channel_total, attempt, max_attempts, 'AN' if visible_fallback_enabled_for_attempt else 'AUS'))
        except Exception:
            pass

        try:
            prepared, prepare_reason = click_prepare_stream_for_autotest(name, url, False)
        except Exception as e:
            log('CLICK Senderstatus prepare error for {}: {}'.format(name, e), xbmc.LOGERROR)
            prepared, prepare_reason = [], 'prepare_error'

        last_reason = prepare_reason or last_reason

        if not prepared:
            if prepare_reason == 'mycamtv_ad_only':
                # notify('CLICK nur Werbung/falscher Fallback: {}'.format(name), False)
                log('CLICK Senderstatus ad-only/wrong-fallback for {}'.format(name))
                return False, attempt, 'mycamtv_ad_only'

            # notify('CLICK Stream nicht vorbereitet: {}'.format(name), False)
            time.sleep(0.25)
            continue

        for variant_index, prepared_item in enumerate(prepared, 1):
            finalurl, streamurl, referer, profile = click_unpack_prepared(prepared_item)
            if oxax_autotest_cancelled(progress):
                return False, attempt - 1, 'cancelled'

            gateway_isa = fuckflix_is_api_gateway_url(streamurl)
            if not gateway_isa and not click_manifest_preflight_ok(streamurl, referer, name, profile):
                code = click_last_preflight_code(profile)
                last_reason = 'rate_limited' if code == '429' else 'preflight_rejected'

                if code == '429':
                    log('CLICK Senderstatus proxy rate-limit cooldown for {} after HTTP 429 [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                    click_autotest_sleep(CLICK_AUTOTEST_RATE_LIMIT_COOLDOWN, progress, 'CLICK wartet wegen 429: {}'.format(name))
                    break

                if code == '403' and click_single_kodi_start_name(name):
                    if visible_fallback_enabled_for_attempt:
                        log('CLICK Senderstatus 403 on real candidate; final attempt may continue to visible fallback for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                        click_autotest_sleep(CLICK_AUTOTEST_PREFLIGHT_REJECT_PAUSE, progress, 'CLICK prueft letzten Fallback nach 403: {}'.format(name))
                        continue
                    log('CLICK Senderstatus HTTP 403 on real candidate; delaying fallback and retrying fresh later for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                    click_autotest_sleep(CLICK_AUTOTEST_PREFLIGHT_REJECT_PAUSE, progress, 'CLICK wartet auf frischen Versuch: {}'.format(name))
                    break

                click_autotest_sleep(CLICK_AUTOTEST_PREFLIGHT_REJECT_PAUSE, progress, 'CLICK prueft naechste Variante: {}'.format(name))
                continue

            play_streamurl = streamurl
            try:
                resolved_child_url = profile.get('resolved_child_url') if profile else ''
            except Exception:
                resolved_child_url = ''
            if resolved_child_url:
                play_streamurl = resolved_child_url
                finalurl = click_build_final_stream_url(play_streamurl, referer, profile)
                log('CLICK Senderstatus using child playlist for {} [{}]: {}'.format(name, click_profile_label(profile), play_streamurl))

            if click_autotest_is_preflight_only(name):
                if not resolved_child_url:
                    log('CLICK Senderstatus SAFE check rejected without resolved media child for {} [{}]'.format(name, click_profile_label(profile)), xbmc.LOGERROR)
                    last_reason = 'safe_child_missing'
                    continue
                log('CLICK Senderstatus OK SAFE for {} on attempt {} variant {} | {}'.format(name, attempt, variant_index, play_streamurl))
                if CLICK_AUTOTEST_OK_NOTIFICATION:
                    notify('CLICK OK SAFE: {} | V{} | Var{} | Segment'.format(name, attempt, variant_index), False)
                return True, attempt, 'safe_preflight'

            log('CLICK Senderstatus playing {} attempt {} variant {}/{} [{}]: {}'.format(name, attempt, variant_index, len(prepared), click_profile_label(profile), play_streamurl))
            if click_single_kodi_start_name(name):
                problem_kodi_starts += 1

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
                time.sleep(0.25)
            except Exception:
                pass

            player = SenderStatusPlayer('CLICK Senderstatus')
            item = xbmcgui.ListItem(name)

            try:
                item.setProperty('IsPlayable', 'true')
            except Exception:
                pass

            if click_uses_safe_hls_listitem(name):
                try:
                    item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                    log('CLICK safe HLS ListItem enabled for {}'.format(name))
                except Exception:
                    pass

            if gateway_isa:
                configure_xlivetv_isa_item(item, referer, BASE_CLICK.rstrip('/'), 'CLICK Senderstatus')

            try:
                player.play(streamurl if gateway_isa else finalurl, item)
            except Exception as e:
                log('CLICK Senderstatus player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
                time.sleep(0.25)
                continue

            selected_start_timeout = 5 if gateway_isa else click_autotest_start_timeout_for_name(name, attempt)
            selected_play_seconds = click_autotest_play_seconds_for_name(name, attempt, play_streamurl)
            profile_label = 'SAFE' if click_autotest_uses_safe_profile(name, attempt) else 'FAST'
            log('CLICK Senderstatus {} timing for {} attempt {}: start={}s hold={:.1f}s'.format(
                profile_label, name, attempt, selected_start_timeout, selected_play_seconds
            ))

            ok = senderstatus_wait_for_player(
                player,
                start_timeout=selected_start_timeout,
                play_seconds=selected_play_seconds,
                stable_seconds=CLICK_AUTOTEST_STABLE_SECONDS,
                progress=progress,
                progress_message='CLICK: {} ({}/{})\nVersuch {} | Variante {}/{} | {}'.format(name, channel_index, channel_total, attempt, variant_index, len(prepared), 'FALLBACK' if click_is_visible_fallback_stream(play_streamurl) else 'REAL'),
                log_prefix='CLICK Senderstatus'
            )

            click_stop_player_safely(
                player,
                name,
                progress=progress,
                message='CLICK Player-Cleanup: {}'.format(name)
            )

            if ok:
                ok_kind = 'visible_fallback' if click_is_visible_fallback_stream(play_streamurl) else 'real'
                ok_label = 'FALLBACK' if ok_kind == 'visible_fallback' else 'REAL'
                log('CLICK Senderstatus OK {} for {} on attempt {} variant {}'.format(ok_label, name, attempt, variant_index))
                if CLICK_AUTOTEST_OK_NOTIFICATION:
                    notify('CLICK OK {}: {} | V{} | Var{} | {:.1f}s'.format(ok_label, name, attempt, variant_index, selected_play_seconds), False)
                return True, attempt, ok_kind

            log('CLICK Senderstatus no playback for {} on attempt {} variant {}'.format(name, attempt, variant_index), xbmc.LOGERROR)
            last_reason = 'no_playback'
            if click_single_kodi_start_name(name):
                if click_is_babes_legacy_name(name):
                    if attempt < max_attempts:
                        log('CLICK Senderstatus Babes child failed once; retrying fresh later for {}'.format(name), xbmc.LOGERROR)
                        break
                    log('CLICK Senderstatus stop after Babes child retry failed for {}'.format(name), xbmc.LOGERROR)
                    return False, attempt, last_reason

                start_limit = 2 if visible_fallback_enabled_for_attempt else CLICK_AUTOTEST_PROBLEM_KODI_START_LIMIT
                if problem_kodi_starts >= start_limit:
                    if attempt < max_attempts:
                        log('CLICK Senderstatus stop this attempt after {} Kodi failure(s); delaying fallback and retrying fresh later for {}'.format(problem_kodi_starts, name), xbmc.LOGERROR)
                        break
                    log('CLICK Senderstatus stop after {} Kodi failures for popup-safe channel {}'.format(problem_kodi_starts, name), xbmc.LOGERROR)
                    return False, attempt, last_reason

                if visible_fallback_enabled_for_attempt:
                    log('CLICK Senderstatus final-attempt fallback-safe extra candidate allowed for {} after Kodi failure {}/{}'.format(name, problem_kodi_starts, start_limit), xbmc.LOGERROR)
                else:
                    log('CLICK Senderstatus real-stream retry preferred for {} after Kodi failure {}/{}'.format(name, problem_kodi_starts, start_limit), xbmc.LOGERROR)

        # v42: OK-Notifications sind wieder aktiv, damit im AutoTest sichtbar ist,
        # ob ein Sender REAL oder nur per FALLBACK lief. Fehler bleiben in Summary/Log.
        if attempt < max_attempts:
            selected_retry_delay = click_autotest_retry_delay_for_name(name)
            log('CLICK Senderstatus cooldown before fresh retry for {}: {:.1f} seconds'.format(name, selected_retry_delay))
            click_autotest_sleep(max(selected_retry_delay, 0.25), progress, 'CLICK wartet vor frischem Versuch: {}'.format(name))
        else:
            click_autotest_sleep(0.5, progress, 'CLICK kurze Pause: {}'.format(name))

    return False, max_attempts, last_reason or 'no_playback'


@site.register()
def AutoTest_CLICK(url, close_directory=True):
    monitor = xbmc.Monitor()
    progress = None
    ok_count = 0
    failed = []
    skipped = []
    ad_only = []
    fallback_ok = []
    safe_ok = []
    page_count = 0

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('CLICK Senderstatus prüfen', 'Lade Pages...')
    except Exception:
        progress = None

    try:
        channels, page_count = click_fetch_channels_for_autotest(progress=progress)

        if not channels:
            notify('CLICK Senderstatus: keine Sender gefunden', True)
            if close_directory:
                senderstatus_final_cleanup('CLICK Senderstatus', close_directory=True)
            return

        channels, range_label = click_select_senderstatus_range(channels)
        if not channels:
            log('CLICK Senderstatus range selection cancelled or empty')
            if close_directory:
                senderstatus_final_cleanup('CLICK Senderstatus', close_directory=True)
            return

        notify('CLICK Senderstatus startet: {} Sender / {} Pages / {}'.format(len(channels), page_count, range_label), False)
        log('CLICK Senderstatus range: {} | {} Sender'.format(range_label, len(channels)))

        for idx, (name, videourl, img) in enumerate(channels, 1):
            if monitor.abortRequested() or oxax_autotest_cancelled(progress):
                log('CLICK Senderstatus cancelled by user/abort')
                break

            start_percent = int(max(0, min(99, ((idx - 1) * 100.0) / max(1, len(channels)))))
            progress = senderstatus_reopen_progress(
                progress,
                'CLICK Senderstatus prüfen',
                'CLICK: {} ({}/{})\nStarte Senderanalyse...'.format(name, idx, len(channels)),
                start_percent,
                'CLICK Senderstatus'
            )
            log('CLICK Senderstatus channel {}/{}: {} | {}'.format(idx, len(channels), name, videourl))

            if click_should_skip_senderstatus(name):
                skipped.append(name)
                log('CLICK Senderstatus skipped by v34 rule: {}'.format(name))
                percent = int((idx * 100) / max(len(channels), 1))
                progress = senderstatus_reopen_progress(
                    progress,
                    'CLICK Senderstatus prüfen',
                    'CLICK übersprungen: {} ({}/{})\nOK: {} | Fehler: {} | Skip: {}'.format(
                        name, idx, len(channels), ok_count, len(failed), len(skipped)
                    ),
                    percent,
                    'CLICK Senderstatus'
                )
                click_autotest_sleep(0.4, progress, 'CLICK Pause vor naechstem Sender')
                continue

            ok, used_attempts, reason = click_autotest_try_channel(
                name,
                videourl,
                progress=progress,
                channel_index=idx,
                channel_total=len(channels)
            )

            if ok:
                ok_count += 1
                if reason == 'visible_fallback':
                    fallback_ok.append(name)
                elif reason == 'safe_preflight':
                    safe_ok.append(name)
            elif reason == 'mycamtv_ad_only':
                ad_only.append(name)
                log('CLICK Senderstatus classified as ad-only/wrong-fallback: {}'.format(name))
            else:
                failed.append(name)

            percent = int((idx * 100) / max(len(channels), 1))
            progress = senderstatus_reopen_progress(
                progress,
                'CLICK Senderstatus prüfen',
                'CLICK fertig: {} ({}/{})\nOK: {} | SAFE: {} | Fallback-OK: {} | Fehler: {}'.format(
                    name, idx, len(channels), ok_count, len(safe_ok), len(fallback_ok), len(failed)
                ),
                percent,
                'CLICK Senderstatus'
            )

            if ok and reason == 'safe_preflight':
                channel_pause = 0.4
            elif ok and reason == 'real' and used_attempts == 1:
                channel_pause = CLICK_AUTOTEST_FAST_PAUSE_SECONDS
            elif ok:
                channel_pause = CLICK_AUTOTEST_SAFE_PAUSE_SECONDS
            else:
                channel_pause = CLICK_AUTOTEST_FAILED_PAUSE_SECONDS
            log('CLICK adaptive pause after {}: {:.1f}s'.format(name, channel_pause))
            click_autotest_sleep(channel_pause, progress, 'CLICK Pause vor naechstem Sender')

    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass

    testable_total = ok_count + len(failed)
    total_channels = len(channels) if 'channels' in locals() else testable_total + len(skipped) + len(ad_only)
    range_info = range_label if 'range_label' in locals() else 'Alle Sender'
    status_msg = 'CLICK Senderstatus v71 summary: {}/{} testbare Sender OK | total: {} | pages: {} | range: {} | failed: {} | skipped: {} | ad_only: {} | safe_ok: {} | fallback_ok: {}'.format(
        ok_count,
        testable_total,
        total_channels,
        page_count,
        range_info,
        ', '.join(failed) if failed else '-',
        ', '.join(skipped) if skipped else '-',
        ', '.join(ad_only) if ad_only else '-',
        ', '.join(safe_ok) if safe_ok else '-',
        ', '.join(fallback_ok) if fallback_ok else '-'
    )
    log(status_msg)

    if failed:
        notify('CLICK Senderstatus: {}/{} OK, {} SAFE, {} Fallback-OK, {} Fehler'.format(ok_count, testable_total, len(safe_ok), len(fallback_ok), len(failed)), True)
    else:
        notify('CLICK Senderstatus: {}/{} OK, {} SAFE, {} Fallback-OK, {} Skip'.format(ok_count, testable_total, len(safe_ok), len(fallback_ok), len(skipped)), False)

    if close_directory:
        senderstatus_final_cleanup('CLICK Senderstatus', close_directory=True)

# -------------------------------------------------------------------------
# fuckflix.click (v70 global fallback block + speed pass + Live Cams safe ISA)
# Page/archive structure follows the .com WordPress parser; playback follows
# the safer .click POST/iframe/HLS logic. MP4 is kept as FALLBACK for this site
# until the first real AutoTest log tells us which pages genuinely use it.
# -------------------------------------------------------------------------

FUCKFLIX_MAX_PAGES = 20
FUCKFLIX_EXPECTED_PAGES = 9
FUCKFLIX_MAX_CHANNELS = 250
FUCKFLIX_MAX_ATTEMPTS = 2
FUCKFLIX_REAL_ONLY_MAX_ATTEMPTS = 2
FUCKFLIX_PLAY_MAX_ATTEMPTS = 3
FUCKFLIX_START_TIMEOUT = 10
FUCKFLIX_SLOW_START_TIMEOUT = 20
FUCKFLIX_PLAY_SECONDS = 1.4
FUCKFLIX_RETRY_DELAY = 1.2
FUCKFLIX_PAUSE_SECONDS = 0.6
FUCKFLIX_CHILD_SEGMENT_TIMEOUT = 3.5
FUCKFLIX_HTTP_TIMEOUT = 8
FUCKFLIX_API_START_TIMEOUT = 5
FUCKFLIX_LIVECAMS_START_TIMEOUT = 7
FUCKFLIX_LIVECAMS_SAFE_TIMEOUT = 4.0
FUCKFLIX_PLAYBOY_HOLD_SECONDS = 4.0
FUCKFLIX_MAX_PLAYER_DEPTH = 2
FUCKFLIX_MAX_PLAYER_URLS = 10
FUCKFLIX_AUTOTEST_LOCK_PROPERTY = 'AdultTVTest.FUCKFLIX.AutoTestLock'
FUCKFLIX_AUTOTEST_LOCK_MAX_AGE = 90 * 60
FUCKFLIX_SPLIT_NAME = 'FashionTV Midnight Secrets'
FUCKFLIX_ALLOW_MP4_FALLBACK = False
FUCKFLIX_DIAGNOSTIC_PAGES = 2
FUCKFLIX_CHANNELS_PER_PAGE = 12
FUCKFLIX_MAX_SCRIPT_URLS = 10
FUCKFLIX_SCRIPT_CACHE = {}

# Historische Liste der Sender vor FashionTV. Seit v70 gilt die strengere
# Regel fuer die komplette FuckFlix-Site: MyCam/Redtraffic darf weder im
# AutoTest noch im Einzelstart als Erfolg abgespielt werden. Die Liste bleibt
# nur fuer bestehende Profil-/Timinglogik erhalten.
FUCKFLIX_REAL_ONLY_NAMES = [
    'Brazzers TV Online', 'Babes TV HD', 'Eroxxx HD TV Online',
    'Redlight HD TV Online', 'VIXEN', 'Private TV Online', 'Extasy4K',
    'XXL TV Online', 'Hustler HD TV Online', 'Hustler TV',
    'Dorcel TV Online', 'Playboy TV', 'Penthouse Passion',
    'Passion XXX TV', 'Evil Angel', 'TransAngels TV',
    'Penthouse Reality TV', 'Barely Legal TV', 'Pinko Club TV',
    'Venus TV', 'CentoXCento TV', 'PenthouseGold TV Online',
    'FAKE TAXI', 'SuperONE TV', 'Leo TV', 'Sextreme TV',
    'Hot Pleasure', 'True Amateurs', 'Leo Gold TV', 'HOT Man',
    'Sexy Hot', 'Trans Erotica', 'EXXXotica', 'SeXation',
    'Television X', 'Penthouse After Midnight', 'Penthouse TV',
    'Penthouse Black', 'Penthouse', 'Bang U', 'Blue Hustler',
    'Dusk TV', 'Reality Kings TV', 'Penthouse Naughty Nights',
    'SexPrive', 'Nuart TV', 'Mofos', 'CUM 4K',
    'EroLuxe Shemales', 'Secret Circle TV', 'Beate-Uhse TV',
    'Dorcel TV Africa', 'HOT XXL', 'BODY SEX', 'HOT HD',
    'Erox TV Online', 'Desire TV', 'Miami TV', 'MiamiTV Latino',
]

FUCKFLIX_FALLBACK_MARKERS = [
    'mycamtv.com', 'mycamtv', 'mycam.tv',
    'live.redtraffic.net', 'redtraffic.net',
]
FUCKFLIX_HARD_AD_MARKERS = [
    'tsyndicate.com', 'cdn.tsyndicate.com', 'svacdn.tsyndicate.com',
    'cdnproxy.tsyndicate.com', 'tinder',
]


def fuckflix_is_hard_ad(text):
    lower = (text or '').lower()
    return any(marker in lower for marker in FUCKFLIX_HARD_AD_MARKERS)


def fuckflix_is_visible_fallback(streamurl, referer='', source_kind=''):
    combined = '{} {} {}'.format(streamurl or '', referer or '', source_kind or '').lower()
    return (
        source_kind == 'visible_fallback'
        or '.mp4' in combined
        or any(marker in combined for marker in FUCKFLIX_FALLBACK_MARKERS)
    )


def fuckflix_is_livecams_real(name, streamurl):
    """FuckFlix uses this exact Redtraffic URL as the primary Live Cams feed.

    All other Redtraffic/MyCam URLs remain blocked globally.  This narrow
    exception is intentionally name+URL bound so category fallback videos
    cannot leak through.
    """
    plain = com_status_plain_name(name).strip().lower()
    decoded = unquote((streamurl or '').lower())
    return plain == 'live cams' and 'live.redtraffic.net/livecams.m3u8' in decoded


def fuckflix_is_real_only_name(name):
    plain = com_status_plain_name(name)
    return any(plain == com_status_plain_name(item) for item in FUCKFLIX_REAL_ONLY_NAMES)


def fuckflix_find_all_stream_urls(value, baseurl=''):
    """Collect every HLS/MP4 URL from nested JSON/text, REAL candidates first.

    v59 used json_find_stream_url(), which returns only the first URL. If a
    response contains both the real TV stream and a fallback field, the first
    fallback could hide the real stream completely.
    """
    found = []
    seen = set()

    def add(candidate):
        candidate = html_unescape(candidate or '').replace('\\/', '/').strip()
        if not candidate:
            return

        decoded_versions = [candidate]
        try:
            decoded = unquote(candidate)
            if decoded and decoded != candidate:
                decoded_versions.append(decoded)
        except Exception:
            pass

        for raw in decoded_versions:
            urls = []
            if (
                ('.m3u8' in raw.lower() or '.mp4' in raw.lower())
                and not re.search(r'\s', raw)
                and raw.lower().startswith(('http://', 'https://', '/'))
            ):
                urls.append(raw)
            urls.extend(re.findall(
                r'https?://[^\s"\'<>]+?(?:\.m3u8|\.mp4)[^\s"\'<>]*',
                raw,
                re.IGNORECASE
            ))
            for url in urls:
                url = html_unescape(url).replace('\\/', '/').strip(' ,;)]}')
                if baseurl:
                    url = urljoin(baseurl, url)
                if url and url not in seen:
                    seen.add(url)
                    found.append(url)

    def walk(obj):
        if isinstance(obj, dict):
            # Likely real/source fields first; fallback/ad fields last.
            items = list(obj.items())
            items.sort(key=lambda item: (
                1 if any(x in str(item[0]).lower() for x in ('fallback', 'backup', 'ad', 'promo', 'cam')) else 0,
                str(item[0]).lower()
            ))
            for _key, child in items:
                walk(child)
        elif isinstance(obj, (list, tuple)):
            for child in obj:
                walk(child)
        elif isinstance(obj, str):
            add(obj)

    walk(value)
    found.sort(key=lambda url: (
        1 if fuckflix_is_visible_fallback(url) else 0,
        1 if '.mp4' in url.lower() else 0,
    ))
    return found



def fuckflix_progress_update(progress, channel_index=0, channel_total=0, name='', stage='', percent=None):
    if not progress:
        return
    try:
        if percent is None:
            if channel_total:
                percent = int(max(0, min(99, ((max(1, channel_index) - 1) * 100.0) / max(1, channel_total))))
            else:
                percent = 0
        title = 'FUCKFLIX: {} ({}/{})'.format(name or 'Senderstatus', channel_index or '-', channel_total or '-')
        progress.update(int(percent), '{}\n{}'.format(title, stage or 'Bitte warten...'))
    except Exception:
        pass


def fuckflix_acquire_autotest_lock():
    try:
        window = xbmcgui.Window(10000)
        current = window.getProperty(FUCKFLIX_AUTOTEST_LOCK_PROPERTY) or ''
        now = time.time()
        if current:
            try:
                current_ts = float(current.split('|', 1)[0])
            except Exception:
                current_ts = now
            age = max(0.0, now - current_ts)
            if age < FUCKFLIX_AUTOTEST_LOCK_MAX_AGE:
                log('FUCKFLIX AutoTest duplicate blocked; active lock age {:.1f}s'.format(age), xbmc.LOGWARNING)
                return '', window
            log('FUCKFLIX stale AutoTest lock cleared; age {:.1f}s'.format(age), xbmc.LOGWARNING)
            window.clearProperty(FUCKFLIX_AUTOTEST_LOCK_PROPERTY)

        token = '{}|{}'.format(now, os.getpid())
        window.setProperty(FUCKFLIX_AUTOTEST_LOCK_PROPERTY, token)
        log('FUCKFLIX AutoTest lock acquired: {}'.format(token))
        return token, window
    except Exception as e:
        log('FUCKFLIX AutoTest lock unavailable: {}'.format(e), xbmc.LOGERROR)
        return 'no-window-lock', None


def fuckflix_release_autotest_lock(token, window=None):
    if not token:
        return
    try:
        window = window or xbmcgui.Window(10000)
        current = window.getProperty(FUCKFLIX_AUTOTEST_LOCK_PROPERTY) or ''
        if current == token or token == 'no-window-lock':
            window.clearProperty(FUCKFLIX_AUTOTEST_LOCK_PROPERTY)
            log('FUCKFLIX AutoTest lock released')
    except Exception as e:
        log('FUCKFLIX AutoTest lock release error: {}'.format(e), xbmc.LOGERROR)


def fuckflix_new_browser_opener():
    cj = http.cookiejar.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))
    try:
        opener._fuckflix_cookiejar = cj
    except Exception:
        pass
    return opener


def fuckflix_http_get(opener, url, referer=None, accept='text/html,application/xhtml+xml,application/json,text/plain,*/*;q=0.8'):
    headers = {
        'User-Agent': FUCKFLIX_UA,
        'Accept': accept,
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin' if referer else 'none',
        'Connection': 'keep-alive',
    }
    if referer:
        headers['Referer'] = referer
    req = Request(url, headers=headers)
    return opener.open(req, timeout=FUCKFLIX_HTTP_TIMEOUT).read().decode('utf-8', 'ignore')


def fuckflix_http_post(opener, url, referer, origin, return_meta=False):
    # Mirror the site's native fetch(..., {method:'POST'}) request while
    # preserving the same cookies/session that produced the sender page.
    headers = {
        'User-Agent': FUCKFLIX_UA,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': (origin or fuckflix_site_origin(referer)).rstrip('/'),
        'Referer': referer,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Connection': 'keep-alive',
    }
    req = Request(url, data=b'', headers=headers)
    response = opener.open(req, timeout=FUCKFLIX_HTTP_TIMEOUT)
    raw = response.read()
    text = raw.decode('utf-8', 'ignore')
    if not return_meta:
        return text
    status = getattr(response, 'status', None) or getattr(response, 'code', None) or 0
    try:
        content_type = response.headers.get('Content-Type', '') or ''
    except Exception:
        content_type = ''
    try:
        final_url = response.geturl() or url
    except Exception:
        final_url = url
    return text, int(status or 0), content_type, len(raw), final_url


def fuckflix_decode_api_file_url(raw_value):
    """Decode the current FuckFlix API fileUrl format.

    Current API responses return a Base64 string. Decoding it yields the real
    URL backwards, e.g. ``TOKEN/s/moc.vtevilx.maerts//:sptth``. Reversing that
    text produces ``https://stream.xlivetv.com/s/TOKEN``.

    Keep direct HTTP(S) fileUrl values supported as well, because FuckFlix has
    used that older format before and may switch between both variants.
    """
    if not isinstance(raw_value, str):
        return ''

    value = html_unescape(raw_value or '').replace('\\/', '/').strip()
    if not value:
        return ''
    try:
        value = unquote(value)
    except Exception:
        pass

    if value.lower().startswith(('http://', 'https://')):
        return value

    candidates = []
    # Base64 from the API is currently standard Base64 without padding, but
    # urlsafe_b64decode also tolerates future '-'/'_' alphabet changes.
    padded = value + ('=' * ((4 - (len(value) % 4)) % 4))
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            decoded = decoder(padded).decode('utf-8', 'strict').strip()
        except Exception:
            continue
        if decoded and decoded not in candidates:
            candidates.append(decoded)

    for decoded in candidates:
        direct = decoded.strip()
        reversed_value = direct[::-1].strip()
        for candidate in (direct, reversed_value):
            if candidate.lower().startswith(('http://', 'https://')):
                return candidate
    return ''


def fuckflix_is_api_gateway_url(url):
    try:
        parsed = urlparse(url or '')
        host = (parsed.netloc or '').lower().split(':', 1)[0]
        path = parsed.path or ''
        return host in ('stream.xlivetv.com', 'www.stream.xlivetv.com') and path.startswith('/s/')
    except Exception:
        return False


def fuckflix_extract_api_file_urls(document, baseurl=''):
    """Extract the site's authoritative API fileUrl even without an extension.

    FuckFlix's player.js consumes data.fileUrl and tells Video.js that the
    result is HLS. Therefore a valid tokenized HLS URL is allowed to omit the
    literal '.m3u8' suffix; the normal generic stream regex would miss it.
    Only explicit fileUrl/file_url keys are promoted here, not generic URL
    fields, so ad/fallback metadata cannot accidentally become REAL.
    """
    try:
        parsed = json.loads(document or '')
    except Exception:
        return []

    found = []
    seen = set()

    def add(raw):
        if not isinstance(raw, str):
            return
        original = html_unescape(raw or '').replace('\\/', '/').strip()
        if not original:
            return

        value = fuckflix_decode_api_file_url(original)
        if value:
            log('FUCKFLIX API fileUrl decoded: {}'.format(value))
        else:
            value = original
            try:
                value = unquote(value)
            except Exception:
                pass

        if value.startswith('//'):
            value = 'https:' + value
        elif value.startswith('/'):
            value = urljoin(baseurl or BASE_FUCKFLIX, value)
        if not value.lower().startswith(('http://', 'https://')):
            return
        value = fuckflix_normalize_player_url(value, baseurl)
        if not value or value in seen or fuckflix_is_hard_ad(value):
            return
        seen.add(value)
        found.append(value)

    def walk(obj):
        if isinstance(obj, dict):
            for key, child in obj.items():
                normalized = re.sub(r'[^a-z0-9]', '', str(key).lower())
                if normalized == 'fileurl':
                    add(child)
                if isinstance(child, (dict, list, tuple)):
                    walk(child)
        elif isinstance(obj, (list, tuple)):
            for child in obj:
                walk(child)

    walk(parsed)
    return found


def fuckflix_api_response_diagnostic(document):
    """Return compact non-cookie diagnostics for one API response."""
    text = document or ''
    json_kind = 'no'
    top_keys = '-'
    fileurl_state = 'absent'
    try:
        parsed = json.loads(text)
        json_kind = type(parsed).__name__
        if isinstance(parsed, dict):
            keys = [str(k) for k in parsed.keys()]
            top_keys = ','.join(keys[:12]) if keys else '-'

            def find_fileurl(obj):
                if isinstance(obj, dict):
                    for key, child in obj.items():
                        if re.sub(r'[^a-z0-9]', '', str(key).lower()) == 'fileurl':
                            return child
                        result = find_fileurl(child)
                        if result is not None:
                            return result
                elif isinstance(obj, (list, tuple)):
                    for child in obj:
                        result = find_fileurl(child)
                        if result is not None:
                            return result
                return None

            file_value = find_fileurl(parsed)
            if file_value is None:
                fileurl_state = 'absent'
            elif isinstance(file_value, str):
                fileurl_state = 'string:{}chars'.format(len(file_value))
            else:
                fileurl_state = type(file_value).__name__
    except Exception:
        pass

    preview = re.sub(r'\s+', ' ', text).strip()
    if len(preview) > 320:
        preview = preview[:320] + '...'
    return json_kind, top_keys, fileurl_state, preview or '-'


def fuckflix_http_get_script(opener, url, referer):
    """Load a JS resource like a browser script request, preserving cookies."""
    headers = {
        'User-Agent': FUCKFLIX_UA,
        'Accept': '*/*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Referer': referer or BASE_FUCKFLIX,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Fetch-Dest': 'script',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'same-origin',
        'Connection': 'keep-alive',
    }
    req = Request(url, headers=headers)
    return opener.open(req, timeout=FUCKFLIX_HTTP_TIMEOUT).read().decode('utf-8', 'ignore')


def fuckflix_extract_script_urls(html, baseurl=''):
    """Return JS resources worth inspecting for dynamically moved player code."""
    decoded = html_unescape(html or '').replace('\\/', '/')
    urls = []
    seen = set()
    base_host = urlparse(baseurl or BASE_FUCKFLIX).netloc.lower()

    for tag in re.findall(r'<script\b[^>]*>', decoded, re.IGNORECASE | re.DOTALL):
        match = re.search(r'\bsrc\s*=\s*["\']([^"\']+)["\']', tag, re.IGNORECASE | re.DOTALL)
        if not match:
            continue
        raw = match.group(1).strip()
        if not raw or raw.startswith(('data:', 'javascript:')):
            continue
        url = urljoin(baseurl or BASE_FUCKFLIX, raw)
        if url in seen or fuckflix_is_hard_ad(url):
            continue

        parsed = urlparse(url)
        host = parsed.netloc.lower()
        lower = url.lower()
        same_host = host == base_host

        # Same-origin assets are the most likely place for the site's moved
        # fetch/player code. Third-party scripts are only inspected when their
        # URL itself looks player/stream related; known ad/analytics libraries
        # are deliberately skipped.
        blocked = (
            'googletagmanager.com', 'google-analytics.com', 'tsyndicate.com',
            'effectiveratecpm.com', 'cloudflareinsights.com',
            'vjs.zencdn.net', 'disable-devtool', 'trafficstars'
        )
        if any(marker in lower for marker in blocked):
            continue
        third_party_playerish = any(marker in lower for marker in (
            'player', 'video', 'stream', 'live', 'hls', 'jw'
        ))
        if not same_host and not third_party_playerish:
            continue

        seen.add(url)
        urls.append(url)
        if len(urls) >= FUCKFLIX_MAX_SCRIPT_URLS:
            break

    return urls


def fuckflix_get_script_cached(opener, script_url, referer):
    """Cache static JS only for the current Python process/test run."""
    if script_url in FUCKFLIX_SCRIPT_CACHE:
        return FUCKFLIX_SCRIPT_CACHE.get(script_url) or ''
    try:
        body = fuckflix_http_get_script(opener, script_url, referer)
        FUCKFLIX_SCRIPT_CACHE[script_url] = body
        return body
    except Exception as e:
        FUCKFLIX_SCRIPT_CACHE[script_url] = ''
        log('FUCKFLIX external script load error {}: {}'.format(script_url, e), xbmc.LOGWARNING)
        return ''


def fuckflix_marker_context(document, marker, radius=220):
    """Return one compact, log-safe source fragment around a diagnostic marker."""
    decoded = html_unescape(document or '').replace('\\/', '/')
    match = re.search(re.escape(marker), decoded, re.IGNORECASE)
    if not match:
        return ''
    start = max(0, match.start() - radius)
    end = min(len(decoded), match.end() + radius)
    snippet = decoded[start:end]
    snippet = re.sub(r'\s+', ' ', snippet).strip()
    return snippet[:520]


def fuckflix_bootstrap_session(opener):
    """Prime cookies like a normal visit before opening a sender directly."""
    try:
        html = fuckflix_http_get(opener, BASE_FUCKFLIX, None)
        log('FUCKFLIX browser session bootstrapped: homepage={} bytes'.format(len(html)))
        return True
    except Exception as e:
        log('FUCKFLIX browser session bootstrap failed: {}'.format(e), xbmc.LOGWARNING)
        return False


def fuckflix_normalize_player_url(candidate, baseurl=''):
    candidate = html_unescape(candidate or '').replace('\\/', '/').strip()
    if not candidate or candidate.startswith(('#', 'javascript:', 'data:', 'mailto:')):
        return ''
    candidate = urljoin(baseurl or BASE_FUCKFLIX, candidate)
    lower = candidate.lower()
    if any(lower.split('?', 1)[0].endswith(ext) for ext in (
        '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.css', '.js', '.woff', '.woff2', '.ttf'
    )):
        return ''
    if '.m3u8' in lower or '.mp4' in lower or fuckflix_is_hard_ad(candidate):
        return ''
    return candidate


def fuckflix_extract_player_urls(html, baseurl=''):
    """Find normal and lazy/JS player pages without following archive links."""
    decoded = html_unescape(html or '').replace('\\/', '/')
    found = []
    seen = set()

    def add(raw, strong=False):
        url = fuckflix_normalize_player_url(raw, baseurl)
        if not url or url in seen:
            return
        lower = url.lower()
        try:
            same_host = urlparse(url).netloc.lower() == urlparse(baseurl or BASE_FUCKFLIX).netloc.lower()
        except Exception:
            same_host = False
        playerish = strong or any(marker in lower for marker in (
            '/player', '/embed', '/tv/', '/live/', 'iframe', 'stream', '.php', 'jwplayer'
        ))
        if not playerish and same_host:
            return
        seen.add(url)
        found.append(url)

    # Iframes may keep the real player in data-src while src contains a fallback.
    for tag in re.findall(r'<iframe\b[^>]*>', decoded, re.IGNORECASE | re.DOTALL):
        for attr in ('data-src', 'data-lazy-src', 'data-url', 'data-embed', 'data-player', 'src'):
            match = re.search(r'\b{}\s*=\s*["\']([^"\']+)["\']'.format(re.escape(attr)), tag, re.IGNORECASE | re.DOTALL)
            if match:
                add(match.group(1), strong=True)

    # Common lazy-player and inline-JS assignments.
    for match in re.finditer(
        r'\b(?:data-src|data-lazy-src|data-url|data-embed|data-player|playerUrl|player_url|iframeUrl|iframe_url|embedUrl|embed_url)\s*[:=]\s*["\']([^"\']+)["\']',
        decoded, re.IGNORECASE | re.DOTALL
    ):
        add(match.group(1), strong=True)

    for match in re.finditer(
        r'(?:window\.open|loadPlayer|openPlayer|setPlayer|loadIframe)\s*\(\s*["\']([^"\']+)["\']',
        decoded, re.IGNORECASE | re.DOTALL
    ):
        add(match.group(1), strong=True)

    return found[:FUCKFLIX_MAX_PLAYER_URLS]


def fuckflix_js_decode_string_literal(token):
    """Decode a simple quoted JavaScript string without executing JS."""
    token = (token or '').strip()
    if len(token) < 2 or token[0] not in ('"', "'", '`') or token[-1] != token[0]:
        return ''

    quote = token[0]
    if quote == '"':
        try:
            value = json.loads(token)
            return value if isinstance(value, str) else ''
        except Exception:
            pass

    value = token[1:-1]
    value = value.replace('\\/', '/')
    value = re.sub(
        r'\\x([0-9a-fA-F]{2})',
        lambda match: chr(int(match.group(1), 16)),
        value
    )
    value = re.sub(
        r'\\u([0-9a-fA-F]{4})',
        lambda match: chr(int(match.group(1), 16)),
        value
    )
    replacements = {
        r"\'": "'", r'\"': '"', r'\\': '\\',
        r'\n': '\n', r'\r': '\r', r'\t': '\t',
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    return value


def fuckflix_js_split_arguments(text, open_paren_index):
    """Return top-level arguments for one JS function call."""
    args = []
    current = []
    depth = 0
    quote = ''
    escaped = False

    for char in text[open_paren_index + 1:]:
        if quote:
            current.append(char)
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = ''
            continue

        if char in ('"', "'", '`'):
            quote = char
            current.append(char)
            continue
        if char in '([{':
            depth += 1
            current.append(char)
            continue
        if char in ']}':
            if depth > 0:
                depth -= 1
            current.append(char)
            continue
        if char == ')':
            if depth == 0:
                args.append(''.join(current).strip())
                return args
            depth -= 1
            current.append(char)
            continue
        if char == ',' and depth == 0:
            args.append(''.join(current).strip())
            current = []
            continue
        current.append(char)

    return []


def fuckflix_js_split_concat(expression):
    """Split a simple JS string concatenation on top-level plus signs."""
    parts = []
    current = []
    depth = 0
    quote = ''
    escaped = False

    for char in expression or '':
        if quote:
            current.append(char)
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = ''
            continue

        if char in ('"', "'", '`'):
            quote = char
            current.append(char)
            continue
        if char in '([{':
            depth += 1
            current.append(char)
            continue
        if char in ')]}':
            if depth > 0:
                depth -= 1
            current.append(char)
            continue
        if char == '+' and depth == 0:
            parts.append(''.join(current).strip())
            current = []
            continue
        current.append(char)

    parts.append(''.join(current).strip())
    return [part for part in parts if part]


def fuckflix_js_eval_string_expression(expression, variables=None, baseurl=''):
    """Resolve literals, known variables and + concatenation only."""
    variables = variables or {}
    expression = (expression or '').strip()
    while len(expression) >= 2 and expression[0] == '(' and expression[-1] == ')':
        expression = expression[1:-1].strip()

    if expression.startswith('`') and expression.endswith('`'):
        template = fuckflix_js_decode_string_literal(expression)
        unresolved = [False]

        def replace_var(match):
            name = match.group(1)
            if name not in variables:
                unresolved[0] = True
                return ''
            return variables[name]

        template = re.sub(r'\$\{\s*([A-Za-z_$][\w$]*)\s*\}', replace_var, template)
        return '' if unresolved[0] else template

    parts = fuckflix_js_split_concat(expression)
    if not parts:
        return ''

    result = []
    origin = fuckflix_site_origin(baseurl)
    for part in parts:
        part = part.strip()
        while len(part) >= 2 and part[0] == '(' and part[-1] == ')':
            part = part[1:-1].strip()
        if len(part) >= 2 and part[0] in ('"', "'", '`') and part[-1] == part[0]:
            value = fuckflix_js_decode_string_literal(part)
        elif part in variables:
            value = variables[part]
        elif re.match(r'^(?:window|globalThis|self)\.[A-Za-z_$][\w$]*$', part):
            member_name = part.split('.', 1)[1]
            if member_name not in variables:
                return ''
            value = variables[member_name]
        elif part in ('window.location.origin', 'location.origin', 'document.location.origin'):
            value = origin
        else:
            return ''
        result.append(value)
    return ''.join(result)


def fuckflix_extract_js_string_variables(decoded, baseurl='', seed_variables=None):
    """Resolve simple JS string assignments, optionally seeded by page globals."""
    variables = dict(seed_variables or {})
    assignments = []
    pattern = re.compile(
        r'\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;\r\n]+)',
        re.IGNORECASE
    )
    for match in pattern.finditer(decoded or ''):
        assignments.append((match.group(1), match.group(2).strip()))

    # Some FuckFlix variants assign endpoint variables without var/let/const.
    # Restrict this to URL/API-like names so normal JS assignments do not
    # become endpoint candidates accidentally.
    bare_pattern = re.compile(
        r'(?<![\w$])((?:api|endpoint|player|stream|file)[A-Za-z0-9_$]*_?(?:url)?|url)\s*=\s*([^;\r\n]+)',
        re.IGNORECASE
    )
    existing = set(name for name, _expr in assignments)
    for match in bare_pattern.finditer(decoded or ''):
        name = match.group(1)
        if name not in existing:
            assignments.append((name, match.group(2).strip()))
            existing.add(name)

    # Current FuckFlix variants may expose page globals as window.api_url =
    # "..." while moving the fetch() code into an external JS file.
    member_pattern = re.compile(
        r'(?<![\w$])(?:window|globalThis|self)\.([A-Za-z_$][\w$]*)\s*=\s*([^;\r\n]+)',
        re.IGNORECASE
    )
    for match in member_pattern.finditer(decoded or ''):
        name = match.group(1)
        if name not in existing:
            assignments.append((name, match.group(2).strip()))
            existing.add(name)

    # Also accept URL-like object properties such as {api_url: "..."} as
    # seeds. They are only useful if they resolve to a simple string.
    property_pattern = re.compile(
        r'\b((?:api|endpoint|player|stream|file)[A-Za-z0-9_$]*_?(?:url)?|url)\s*:\s*([^,}\r\n]+)',
        re.IGNORECASE
    )
    for match in property_pattern.finditer(decoded or ''):
        name = match.group(1)
        if name not in existing:
            assignments.append((name, match.group(2).strip()))
            existing.add(name)

    for _pass in range(4):
        changed = False
        for name, expression in assignments:
            value = fuckflix_js_eval_string_expression(expression, variables, baseurl)
            if value and variables.get(name) != value:
                variables[name] = value
                changed = True
        if not changed:
            break
    return variables



def fuckflix_extract_player_config_endpoints(document, baseurl=''):
    """Resolve FuckFlix's current window.playerConfig API descriptor.

    Current pages no longer keep fetch() inline. Instead they expose:
      window.playerConfig = {
        streamType: "api",
        apiUrl: "https://fuckflix.click/<token>",
        endpoint: "<channel-token>",
        sourceUrl: "https://live.redtraffic.net/....m3u8",
        useHlsJs: true/false
      };

    /assets/js/player.js consumes that object. For streamType=api the old
    inline player implementation and the current config both map to a POST
    against apiUrl + "/" + endpoint. sourceUrl is the website's error
    fallback and is never promoted to REAL here.
    """
    decoded = html_unescape(document or '').replace('\\/', '/')
    endpoints = []
    configs = []

    # Object is intentionally simple JSON-like JavaScript. Limit matching to
    # window/globalThis/self.playerConfig so unrelated ad configs are ignored.
    pattern = re.compile(
        r'(?:(?:window|globalThis|self)\s*\.\s*)?playerConfig\s*=\s*\{(.*?)\}\s*;?',
        re.IGNORECASE | re.DOTALL
    )

    def read_string(block, key):
        match = re.search(
            r'(?<![\w$])' + re.escape(key) + r'\s*:\s*(["\'])(.*?)\1',
            block,
            re.IGNORECASE | re.DOTALL
        )
        if not match:
            return ''
        return fuckflix_js_decode_string_literal(match.group(1) + match.group(2) + match.group(1)).strip()

    def read_bool(block, key):
        match = re.search(
            r'(?<![\w$])' + re.escape(key) + r'\s*:\s*(true|false)',
            block,
            re.IGNORECASE
        )
        if not match:
            return None
        return match.group(1).lower() == 'true'

    seen = set()
    for match in pattern.finditer(decoded):
        block = match.group(1)
        stream_type = read_string(block, 'streamType').lower()
        api_url = read_string(block, 'apiUrl')
        endpoint = read_string(block, 'endpoint')
        source_url = read_string(block, 'sourceUrl')
        use_hls_js = read_bool(block, 'useHlsJs')

        config = {
            'streamType': stream_type,
            'apiUrl': api_url,
            'endpoint': endpoint,
            'sourceUrl': source_url,
            'useHlsJs': use_hls_js,
        }
        configs.append(config)

        if stream_type != 'api' or not api_url or not endpoint:
            continue

        api_url = fuckflix_normalize_player_url(api_url, baseurl)
        if not api_url:
            continue
        if re.match(r'^https?://', endpoint, re.IGNORECASE):
            endpoint_url = endpoint
        else:
            endpoint_url = api_url.rstrip('/') + '/' + endpoint.lstrip('/')
        endpoint_url = fuckflix_normalize_player_url(endpoint_url, baseurl)
        if (
            not endpoint_url
            or endpoint_url in seen
            or fuckflix_is_hard_ad(endpoint_url)
        ):
            continue
        seen.add(endpoint_url)
        endpoints.append((endpoint_url, 'POST'))

    return endpoints[:FUCKFLIX_MAX_PLAYER_URLS], configs



def fuckflix_extract_request_endpoints(html, baseurl='', seed_variables=None):
    """Find literal and safely resolvable fetch/ajax/XHR endpoints.

    Besides fetch('literal', ...), v63 resolves the source pattern observed on
    FuckFlix: var api_url='https://...'; fetch(api_url + '/token', {POST}).
    """
    decoded = html_unescape(html or '').replace('\\/', '/')
    endpoints = []
    seen = set()
    variables = fuckflix_extract_js_string_variables(decoded, baseurl, seed_variables=seed_variables)

    def add_expression(expression, method, discovery='literal'):
        raw = fuckflix_js_eval_string_expression(expression, variables, baseurl)
        if not raw:
            return
        url = fuckflix_normalize_player_url(raw, baseurl)
        if not url or url in seen or fuckflix_is_hard_ad(url):
            return
        seen.add(url)
        endpoints.append((url, (method or 'GET').upper()))
        if discovery == 'dynamic':
            log('FUCKFLIX dynamic JS endpoint resolved: {} -> {}'.format(
                re.sub(r'\s+', ' ', expression.strip())[:180], url
            ))

    for match in re.finditer(r'\bfetch\s*\(', decoded, re.IGNORECASE):
        args = fuckflix_js_split_arguments(decoded, match.end() - 1)
        if not args:
            continue
        options = args[1] if len(args) > 1 else ''
        method_match = re.search(r"\bmethod\s*:\s*['\"](GET|POST)['\"]", options, re.IGNORECASE)
        method = method_match.group(1) if method_match else 'GET'
        discovery = 'dynamic' if not re.match(r"^\s*['\"`]", args[0]) else 'literal'
        add_expression(args[0], method, discovery)

    for match in re.finditer(r'\$\.post\s*\(', decoded, re.IGNORECASE):
        args = fuckflix_js_split_arguments(decoded, match.end() - 1)
        if args:
            discovery = 'dynamic' if not re.match(r"^\s*['\"`]", args[0]) else 'literal'
            add_expression(args[0], 'POST', discovery)

    for match in re.finditer(r'\.open\s*\(', decoded, re.IGNORECASE):
        args = fuckflix_js_split_arguments(decoded, match.end() - 1)
        if len(args) < 2:
            continue
        method = fuckflix_js_eval_string_expression(args[0], variables, baseurl).upper()
        if method not in ('GET', 'POST'):
            continue
        discovery = 'dynamic' if not re.match(r"^\s*['\"`]", args[1]) else 'literal'
        add_expression(args[1], method, discovery)

    for match in re.finditer(r'\$\.ajax\s*\(', decoded, re.IGNORECASE):
        args = fuckflix_js_split_arguments(decoded, match.end() - 1)
        if not args:
            continue
        block = args[0]
        url_match = re.search(r'\burl\s*:\s*([^,\r\n}]+)', block, re.IGNORECASE)
        method_match = re.search(r"\b(?:type|method)\s*:\s*['\"](GET|POST)['\"]", block, re.IGNORECASE)
        if url_match:
            expression = url_match.group(1).strip()
            discovery = 'dynamic' if not re.match(r"^\s*['\"`]", expression) else 'literal'
            add_expression(expression, method_match.group(1) if method_match else 'GET', discovery)

    for match in re.finditer(r'\baxios\.(get|post)\s*\(', decoded, re.IGNORECASE):
        args = fuckflix_js_split_arguments(decoded, match.end() - 1)
        if args:
            discovery = 'dynamic' if not re.match(r"^\s*['\"`]", args[0]) else 'literal'
            add_expression(args[0], match.group(1).upper(), discovery)

    return endpoints[:FUCKFLIX_MAX_PLAYER_URLS]

def fuckflix_runtime_marker_counts(document):
    decoded = html_unescape(document or '').replace('\\/', '/')
    markers = {
        'fetch': len(re.findall(r'\bfetch\s*\(', decoded, re.IGNORECASE)),
        'fileUrl': len(re.findall(r'\bfileUrl\b', decoded, re.IGNORECASE)),
        'api_url': len(re.findall(r'\bapi[_$-]?url\b', decoded, re.IGNORECASE)),
        'videojs': len(re.findall(r'\bvideojs\s*\(', decoded, re.IGNORECASE)),
        'atob': len(re.findall(r'\batob\s*\(', decoded, re.IGNORECASE)),
        'eval': len(re.findall(r'\beval\s*\(', decoded, re.IGNORECASE)),
        'xhr': len(re.findall(r'XMLHttpRequest', decoded, re.IGNORECASE)),
        'ajax': len(re.findall(r'\$\.ajax|\$\.post', decoded, re.IGNORECASE)),
        'scripts': len(re.findall(r'<script\b', decoded, re.IGNORECASE)),
        'redtraffic': len(re.findall(r'redtraffic', decoded, re.IGNORECASE)),
        'm3u8': len(re.findall(r'\.m3u8', decoded, re.IGNORECASE)),
    }
    return markers

def fuckflix_log_runtime_markers(name, document, endpoints, player_urls):
    if endpoints or player_urls:
        return
    markers = fuckflix_runtime_marker_counts(document)
    log('FUCKFLIX runtime markers for {}: fetch={} | fileUrl={} | api_url={} | videojs={} | atob={} | eval={} | xhr={} | ajax={} | scripts={} | redtraffic={} | m3u8={}'.format(
        name, markers['fetch'], markers['fileUrl'], markers['api_url'], markers['videojs'],
        markers['atob'], markers['eval'], markers['xhr'], markers['ajax'], markers['scripts'],
        markers['redtraffic'], markers['m3u8']
    ))

def fuckflix_split_index(channels):
    target = com_status_plain_name(FUCKFLIX_SPLIT_NAME)
    for idx, (name, _url, _img) in enumerate(channels):
        if com_status_plain_name(name) == target:
            return idx
    return -1


def fuckflix_select_senderstatus_range(channels):
    """v71: FuckFlix always tests the complete discovered site."""
    if not channels:
        return [], 'Keine Sender', []
    return channels, 'Komplette Site', []


def fuckflix_site_origin(url=None):
    try:
        parsed = urlparse(url or BASE_FUCKFLIX)
        if parsed.scheme and parsed.netloc:
            return '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        pass
    return BASE_FUCKFLIX.rstrip('/')


def fuckflix_header_profiles(streamurl, referer, name=''):
    ref = referer or BASE_FUCKFLIX
    base_origin = fuckflix_site_origin(ref)
    stream_origin = click_stream_origin(streamurl)
    profiles = []
    seen = set()

    def add(label, ref_value, origin_value):
        key = (ref_value or '', origin_value or '')
        if key in seen:
            return
        seen.add(key)
        profile = click_header_profile(label, ref_value, origin_value)
        profiles.append(profile)

    add('page+origin', ref, base_origin)

    # The API-generated XLivetv gateway is short-lived and the website itself
    # performs exactly one browser-style HLS request from the sender page.
    # Extra page-no-origin/bare variants only replay the same token and made a
    # failed single test unnecessarily long.
    if fuckflix_is_api_gateway_url(streamurl):
        return profiles[:1]

    add('page-no-origin', ref, None)

    lower = (streamurl or '').lower()
    if 'aistr.xyz' in lower or 'streamlock.net' in lower or 'skygo.mn' in lower:
        add('bare', None, None)
        if stream_origin and 'fuckflix.click' not in stream_origin:
            add('stream-origin', ref, stream_origin)

    return profiles[:3]


def fuckflix_page_number(url):
    try:
        match = re.search(r'/page/(\d+)/?', url or '', re.IGNORECASE)
        if match:
            return max(1, int(match.group(1)))
        match = re.search(r'[?&]paged=(\d+)', url or '', re.IGNORECASE)
        if match:
            return max(1, int(match.group(1)))
    except Exception:
        pass
    return 1


def fuckflix_page_url(page_number):
    page_number = max(1, int(page_number or 1))
    if page_number <= 1:
        return BASE_FUCKFLIX
    return urljoin(BASE_FUCKFLIX, 'page/{}/'.format(page_number))


def fuckflix_discover_page_numbers(html, page_url=''):
    """Find numbered WordPress pagination links even without rel=next."""
    numbers = {1, fuckflix_page_number(page_url)}
    html = html or ''

    for match in re.finditer(r'href=["\']([^"\']+)["\']', html, re.IGNORECASE):
        candidate = urljoin(page_url or BASE_FUCKFLIX, html_unescape(match.group(1)))
        try:
            host = urlparse(candidate).netloc.lower()
        except Exception:
            host = ''
        if 'fuckflix.click' not in host:
            continue

        page_match = re.search(r'/page/(\d+)/?', candidate, re.IGNORECASE)
        if not page_match:
            page_match = re.search(r'[?&]paged=(\d+)', candidate, re.IGNORECASE)
        if page_match:
            try:
                number = int(page_match.group(1))
                if 1 <= number <= FUCKFLIX_MAX_PAGES:
                    numbers.add(number)
            except Exception:
                pass

    return sorted(numbers)


def fuckflix_max_page_from_html(html, page_url=''):
    discovered = fuckflix_discover_page_numbers(html, page_url)
    detected_max = max(discovered) if discovered else 1
    return min(FUCKFLIX_MAX_PAGES, max(FUCKFLIX_EXPECTED_PAGES, detected_max))


def fuckflix_is_slow_skygo_name(name, streamurl=''):
    plain = com_status_plain_name(name)
    lower = (streamurl or '').lower()
    return 'babes tv hd' in plain or ('cdn4.skygo.mn' in lower and '/babes/' in lower)


def fuckflix_child_segment_preflight_ok(child_url, referer, name, profile):
    """Warm the real SkyGo child segment before Kodi opens it."""
    try:
        opener = com_build_preflight_opener()
        req = Request(child_url, headers=click_preflight_headers(child_url, referer, profile))
        response = opener.open(req, timeout=FUCKFLIX_CHILD_SEGMENT_TIMEOUT)
        final_child_url = response.geturl()
        child_data = response.read(CLICK_NESTED_HLS_READ_BYTES).decode('utf-8', 'ignore')
        try:
            response.close()
        except Exception:
            pass

        if '#EXTM3U' not in child_data:
            log('FUCKFLIX child warmup rejected non-HLS for {} | {}'.format(name, final_child_url), xbmc.LOGERROR)
            return ''

        media_url, media_data = click_resolve_nested_media_playlist(
            opener, final_child_url, child_data, referer, name, profile
        )
        if not media_url or not media_data:
            log('FUCKFLIX child warmup rejected nested playlist for {}'.format(name), xbmc.LOGERROR)
            return ''

        if not click_child_media_preflight_ok(opener, media_url, media_data, referer, name, profile):
            log('FUCKFLIX child warmup rejected media segment for {}'.format(name), xbmc.LOGERROR)
            return ''

        log('FUCKFLIX child/segment warmup OK for {} -> {}'.format(name, media_url))
        return media_url
    except HTTPError as e:
        log('FUCKFLIX child warmup HTTP {} for {} | {}'.format(getattr(e, 'code', '?'), name, child_url), xbmc.LOGERROR)
        return ''
    except Exception as e:
        log('FUCKFLIX child warmup error for {} | {}: {}'.format(name, child_url, e), xbmc.LOGERROR)
        return ''


def fuckflix_parse_channels_from_html(html, page_url):
    channels = []
    seen = set()

    # Primary: same WordPress/article layout as adult-tv-channels.com.
    for name, videourl, img in com_parse_channels_from_html(html, page_url):
        try:
            host = urlparse(videourl).netloc.lower()
        except Exception:
            host = ''
        if 'fuckflix.click' not in host or videourl in seen:
            continue
        seen.add(videourl)
        channels.append((name, videourl, img))

    # Secondary: card layout, useful if a theme page changes independently.
    for name, videourl, img in click_parse_channels_from_html(html, page_url):
        try:
            host = urlparse(videourl).netloc.lower()
        except Exception:
            host = ''
        if 'fuckflix.click' not in host or videourl in seen:
            continue
        seen.add(videourl)
        channels.append((name, videourl, img))

    return channels


@site.register()
def List_FUCKFLIX(url):
    html = utils.getHtml(url, BASE_FUCKFLIX)
    channels = fuckflix_parse_channels_from_html(html, url)

    for name, videourl, img in channels:
        site.add_download_link(name, videourl, 'Play_FUCKFLIX', img, '', noDownload=True)

    current_page = fuckflix_page_number(url)
    max_page = fuckflix_max_page_from_html(html, url)
    if current_page < max_page:
        next_page = current_page + 1
        nexturl = fuckflix_page_url(next_page)
        site.add_dir('Next Page ({})'.format(next_page), nexturl, 'List_FUCKFLIX', site.img_next)
        log('FUCKFLIX list pagination: page {}/{} -> {}'.format(current_page, max_page, nexturl))

    utils.eod()


def fuckflix_add_candidate(real_candidates, fallback_candidates, seen, streamurl, referer, source_kind='', name=''):
    streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
    if not streamurl:
        return
    streamurl = urljoin(referer or BASE_FUCKFLIX, streamurl)
    key = (streamurl, referer or '')
    if key in seen or fuckflix_is_hard_ad(streamurl):
        return
    seen.add(key)

    kind = 'real' if fuckflix_is_livecams_real(name, streamurl) else ('visible_fallback' if fuckflix_is_visible_fallback(streamurl, referer, source_kind) else 'real')
    target = fallback_candidates if kind == 'visible_fallback' else real_candidates
    target.append((streamurl, referer, kind))
    if kind == 'visible_fallback':
        log('FUCKFLIX wrong fallback recorded but globally blocked for {}: {}'.format(name, streamurl))
    else:
        log('FUCKFLIX candidate {} for {}: {}'.format(kind.upper(), referer or '-', streamurl))


def fuckflix_collect_stream_candidates(opener, page_url, name='', allow_visible_fallback=False, progress=None, channel_index=0, channel_total=0, stage_prefix=''):
    real_candidates = []
    fallback_candidates = []
    seen_streams = set()
    seen_documents = set()
    fallback_seen = False
    mp4_ignored = 0
    documents_scanned = 0
    endpoints_called = 0

    def add_stream(streamurl, referer, source_kind=''):
        nonlocal fallback_seen, mp4_ignored
        streamurl = html_unescape(streamurl or '').replace('\\/', '/').strip()
        if not streamurl:
            return
        if '.mp4' in unquote(streamurl.lower()) and not FUCKFLIX_ALLOW_MP4_FALLBACK:
            mp4_ignored += 1
            fallback_seen = True
            log('FUCKFLIX MP4 ignored pending website proof for {}: {}'.format(name, streamurl))
            return
        kind = 'real' if fuckflix_is_livecams_real(name, streamurl) else ('visible_fallback' if fuckflix_is_visible_fallback(streamurl, referer, source_kind) else 'real')
        if kind == 'visible_fallback':
            fallback_seen = True
        fuckflix_add_candidate(real_candidates, fallback_candidates, seen_streams, streamurl, referer, kind, name)

    def scan_document(document, document_url, inherited_kind='', depth=0):
        nonlocal fallback_seen, mp4_ignored, documents_scanned
        document = document or ''
        documents_scanned += 1

        # JSON/text responses can hold nested URLs that normal HTML regex misses.
        try:
            parsed = json.loads(document)
        except Exception:
            parsed = document
        for streamurl in fuckflix_find_all_stream_urls(parsed, document_url):
            add_stream(streamurl, document_url, inherited_kind)

        for streamurl in extract_m3u8_candidates(document, document_url):
            add_stream(streamurl, document_url, inherited_kind)

        page_mp4 = extract_mp4_candidates(document, document_url)
        if page_mp4:
            mp4_ignored += len(page_mp4)
            fallback_seen = True
            log('FUCKFLIX document MP4 ignored pending website proof for {} | {}: {} candidate(s)'.format(name, document_url, len(page_mp4)))

        nested = []
        if depth < FUCKFLIX_MAX_PLAYER_DEPTH:
            nested = fuckflix_extract_player_urls(document, document_url)
        return nested

    fuckflix_progress_update(progress, channel_index, channel_total, name, '{}Seite laden...'.format(stage_prefix))
    try:
        videosrc = fuckflix_http_get(opener, page_url, BASE_FUCKFLIX)
    except Exception as e:
        log('FUCKFLIX page load error for {} | {}: {}'.format(name, page_url, e), xbmc.LOGERROR)
        return [], 'page_load_error'

    queue = []
    direct_nested = scan_document(videosrc, page_url, '', 0)
    for player_url in direct_nested:
        queue.append((player_url, page_url, 1))

    page_variables = fuckflix_extract_js_string_variables(videosrc, page_url)
    endpoints = fuckflix_extract_request_endpoints(videosrc, page_url, seed_variables=page_variables)
    player_urls = fuckflix_extract_player_urls(videosrc, page_url)

    # v66: Current FuckFlix pages expose a declarative playerConfig object.
    # The generic /assets/js/player.js performs the fetch at runtime, so the
    # page itself contains no fetch()/fileUrl code. Resolve that descriptor
    # directly instead of trying to emulate arbitrary external JavaScript.
    config_endpoints, player_configs = fuckflix_extract_player_config_endpoints(videosrc, page_url)
    for config_index, config in enumerate(player_configs, 1):
        source_url = config.get('sourceUrl') or ''
        log('FUCKFLIX playerConfig for {} [{}/{}]: streamType={} | apiUrl={} | endpoint={} | useHlsJs={} | source_fallback={}'.format(
            name, config_index, len(player_configs),
            config.get('streamType') or '-',
            config.get('apiUrl') or '-',
            config.get('endpoint') or '-',
            'true' if config.get('useHlsJs') is True else ('false' if config.get('useHlsJs') is False else '-'),
            'livecams-real' if fuckflix_is_livecams_real(name, source_url) else ('yes' if fuckflix_is_visible_fallback(source_url, page_url) else ('no' if source_url else '-'))
        ))
    for config_endpoint in config_endpoints:
        if config_endpoint not in endpoints:
            endpoints.append(config_endpoint)
            log('FUCKFLIX playerConfig endpoint resolved for {}: {} {}'.format(
                name, config_endpoint[1], config_endpoint[0]
            ))

    # v65 fallback path: older/current variants without a resolvable
    # playerConfig may still move fetch/fileUrl into an external JS resource.
    # fetch/fileUrl/videojs are absent. That strongly suggests the player
    # runtime moved into an external JS resource. Scan likely script resources
    # with the same cookies and seed them with the page's URL variables.
    script_urls = fuckflix_extract_script_urls(videosrc, page_url)
    script_endpoints = []
    script_player_urls = []
    interesting_scripts = 0
    if not real_candidates and script_urls and not endpoints:
        for script_index, script_url in enumerate(script_urls, 1):
            script_body = fuckflix_get_script_cached(opener, script_url, page_url)
            if not script_body:
                continue
            script_markers = fuckflix_runtime_marker_counts(script_body)
            playerish = (
                script_markers['fetch'] or script_markers['fileUrl'] or
                script_markers['api_url'] or script_markers['videojs'] or
                script_markers['xhr'] or script_markers['ajax'] or
                script_markers['m3u8']
            )
            if not playerish:
                continue
            interesting_scripts += 1
            log('FUCKFLIX external JS marker for {} [{}/{}] {}: fetch={} | fileUrl={} | api_url={} | videojs={} | xhr={} | ajax={} | m3u8={}'.format(
                name, script_index, len(script_urls), script_url,
                script_markers['fetch'], script_markers['fileUrl'], script_markers['api_url'],
                script_markers['videojs'], script_markers['xhr'], script_markers['ajax'],
                script_markers['m3u8']
            ))

            # Direct streams inside the JS are valid candidates too.
            scan_document(script_body, script_url, '', 0)

            for endpoint in fuckflix_extract_request_endpoints(
                script_body, page_url, seed_variables=page_variables
            ):
                if endpoint not in endpoints and endpoint not in script_endpoints:
                    script_endpoints.append(endpoint)
                    log('FUCKFLIX external JS endpoint for {}: {} {}'.format(
                        name, endpoint[1], endpoint[0]
                    ))

            for js_player_url in fuckflix_extract_player_urls(script_body, page_url):
                if js_player_url not in player_urls and js_player_url not in script_player_urls:
                    script_player_urls.append(js_player_url)

    endpoints.extend(script_endpoints)
    player_urls.extend(script_player_urls)
    if len(endpoints) > FUCKFLIX_MAX_PLAYER_URLS:
        endpoints = endpoints[:FUCKFLIX_MAX_PLAYER_URLS]
    if len(player_urls) > FUCKFLIX_MAX_PLAYER_URLS:
        player_urls = player_urls[:FUCKFLIX_MAX_PLAYER_URLS]

    log('FUCKFLIX discovery for {}: html={} bytes | endpoints={} | player_urls={} | scripts={} | interesting_scripts={}'.format(
        name, len(videosrc), len(endpoints), len(player_urls), len(script_urls), interesting_scripts
    ))
    if not endpoints and not player_urls and not real_candidates:
        fuckflix_log_runtime_markers(name, videosrc, endpoints, player_urls)
        context = fuckflix_marker_context(videosrc, 'api_url')
        if context:
            log('FUCKFLIX unresolved api_url context for {}: {}'.format(name, context))
        if script_urls:
            log('FUCKFLIX inspected external scripts for {}: {}'.format(
                name, ' | '.join(script_urls[:FUCKFLIX_MAX_SCRIPT_URLS])
            ))

    for player_url in player_urls:
        if not any(player_url == item[0] for item in queue):
            queue.append((player_url, page_url, 1))

    # Literal fetch/ajax/XHR endpoints are queried before nested players.
    for endpoint_index, (endpoint_url, method) in enumerate(endpoints, 1):
        fuckflix_progress_update(
            progress, channel_index, channel_total, name,
            '{}Player-Endpunkt {}/{} ({})...'.format(stage_prefix, endpoint_index, len(endpoints), method)
        )
        try:
            response_status = 0
            response_type = ''
            response_bytes = 0
            response_final_url = endpoint_url
            if method == 'POST':
                response, response_status, response_type, response_bytes, response_final_url = fuckflix_http_post(
                    opener, endpoint_url, page_url, BASE_FUCKFLIX, return_meta=True
                )
            else:
                response = fuckflix_http_get(opener, endpoint_url, page_url)
                response_bytes = len((response or '').encode('utf-8', 'ignore'))
            endpoints_called += 1

            explicit_file_urls = fuckflix_extract_api_file_urls(response, response_final_url or endpoint_url)
            json_kind, top_keys, fileurl_state, response_preview = fuckflix_api_response_diagnostic(response)
            log('FUCKFLIX endpoint response for {} | {} {} | status={} | type={} | bytes={} | json={} | keys={} | fileUrl={}'.format(
                name, method, endpoint_url, response_status or '-', response_type or '-', response_bytes,
                json_kind, top_keys, fileurl_state
            ))

            if explicit_file_urls:
                for explicit_url in explicit_file_urls:
                    log('FUCKFLIX API fileUrl candidate for {}: {}'.format(name, explicit_url))
                    # Browser playback is initiated by the sender page.  Using
                    # the API endpoint itself as Referer is not what Hls.js /
                    # Video.js sends for the subsequent cross-origin HLS load.
                    add_stream(explicit_url, page_url, '')
            elif method == 'POST':
                log('FUCKFLIX API response preview for {}: {}'.format(name, response_preview))

            nested = scan_document(response, response_final_url or endpoint_url, '', 1)
            for player_url in nested:
                if not any(player_url == item[0] for item in queue):
                    queue.append((player_url, response_final_url or endpoint_url, 2))
        except Exception as e:
            log('FUCKFLIX endpoint error for {} | {} {}: {}'.format(name, method, endpoint_url, e), xbmc.LOGERROR)

    # Direct/endpoint REAL already wins and avoids unnecessary extra HTTP
    # work on the four senders that are known to expose their HLS immediately.
    # Lazy/JS player pages are followed only while no REAL candidate exists.
    if real_candidates:
        queue = []

    # Follow lazy/JS/iframe player pages at most two levels deep.
    queue = queue[:FUCKFLIX_MAX_PLAYER_URLS]
    while queue and len(seen_documents) < FUCKFLIX_MAX_PLAYER_URLS and not real_candidates:
        player_url, referer, depth = queue.pop(0)
        if player_url in seen_documents or fuckflix_is_hard_ad(player_url):
            continue
        seen_documents.add(player_url)
        source_kind = 'visible_fallback' if fuckflix_is_visible_fallback('', player_url) else ''
        fuckflix_progress_update(
            progress, channel_index, channel_total, name,
            '{}Player-Seite {}/{} laden...'.format(stage_prefix, len(seen_documents), FUCKFLIX_MAX_PLAYER_URLS)
        )
        try:
            player_html = fuckflix_http_get(opener, player_url, referer)
        except Exception as e:
            log('FUCKFLIX player page load error for {} | {}: {}'.format(name, player_url, e), xbmc.LOGERROR)
            continue

        nested = scan_document(player_html, player_url, source_kind, depth)
        if depth < FUCKFLIX_MAX_PLAYER_DEPTH:
            for nested_url in nested:
                if nested_url not in seen_documents and not any(nested_url == item[0] for item in queue):
                    queue.append((nested_url, player_url, depth + 1))
        if len(queue) > FUCKFLIX_MAX_PLAYER_URLS:
            queue = queue[:FUCKFLIX_MAX_PLAYER_URLS]

    log('FUCKFLIX extraction summary for {}: documents={} | endpoints_called={} | REAL={} | FALLBACK={} | mp4_ignored={}'.format(
        name, documents_scanned, endpoints_called, len(real_candidates), len(fallback_candidates), mp4_ignored
    ))

    if real_candidates:
        return real_candidates + (fallback_candidates if allow_visible_fallback else []), ''
    if fallback_candidates:
        if allow_visible_fallback:
            return fallback_candidates, 'visible_fallback'
        return [], 'visible_fallback_only'
    if fallback_seen:
        return [], 'visible_fallback_only'
    return [], 'no_stream'


def fuckflix_prepare_stream_for_autotest(name, url, allow_visible_fallback=False, progress=None, channel_index=0, channel_total=0, attempt=1, max_attempts=1, session_opener=None):
    prepared = []
    seen = set()
    last_reason = ''

    opener = session_opener or fuckflix_new_browser_opener()
    if session_opener is None:
        fuckflix_bootstrap_session(opener)

    for pass_no in range(1, 3):
        try:
            fuckflix_progress_update(
                progress, channel_index, channel_total, name,
                'V{}/{} | Fresh-Pass {}/2 – Website/Player analysieren...'.format(attempt, max_attempts, pass_no)
            )
            candidates, reason = fuckflix_collect_stream_candidates(
                opener, url, name, allow_visible_fallback,
                progress=progress, channel_index=channel_index, channel_total=channel_total,
                stage_prefix='V{}/{} | Fresh-Pass {}/2 – '.format(attempt, max_attempts, pass_no)
            )
        except Exception as e:
            log('FUCKFLIX collect error for {} pass {}: {}'.format(name, pass_no, e), xbmc.LOGERROR)
            candidates, reason = [], 'no_stream'
        last_reason = reason or last_reason

        pass_prepared = []
        for streamurl, referer, source_kind in candidates:
            is_mp4 = '.mp4' in unquote((streamurl or '').lower())
            variants = [streamurl] if is_mp4 else click_stream_variants(streamurl, name)
            for variant in variants:
                if fuckflix_is_hard_ad(variant):
                    continue
                for profile in fuckflix_header_profiles(variant, referer, name):
                    key = (variant, referer, click_profile_label(profile), source_kind)
                    if key in seen:
                        continue
                    seen.add(key)
                    profile['source_kind'] = source_kind
                    profile['allow_visible_fallback'] = (source_kind == 'visible_fallback')
                    try:
                        profile['_fuckflix_opener'] = opener
                    except Exception:
                        pass
                    finalurl = click_build_final_stream_url(variant, referer, profile)
                    pass_prepared.append(click_prepared_item(finalurl, variant, referer, profile))
                    if len(pass_prepared) >= 3:
                        break
                if len(pass_prepared) >= 3:
                    break
            if len(pass_prepared) >= 3:
                break

        if pass_prepared:
            # API-generated XLivetv URLs are fresh, short-lived player tokens.
            # The browser uses the first successful token once; a second
            # Fresh-Pass plus accumulated header variants only repeats work.
            try:
                first_stream = click_unpack_prepared(pass_prepared[0])[1]
            except Exception:
                first_stream = ''
            if fuckflix_is_api_gateway_url(first_stream):
                prepared = pass_prepared[:1]
                break
            prepared = pass_prepared + prepared
            prepared = prepared[:3]

    if prepared:
        log('FUCKFLIX prepared {} variant(s) for {}'.format(len(prepared), name))
        return prepared, ''
    return [], last_reason or 'no_stream'


def fuckflix_gateway_hls_preflight(streamurl, referer, name, profile):
    """Safely resolve/probe FuckFlix's extensionless XLivetv HLS gateway."""
    allow_visible_fallback = bool(profile and profile.get('allow_visible_fallback'))
    try:
        opener = com_build_preflight_opener()
        req = Request(streamurl, headers=click_preflight_headers(streamurl, referer, profile))
        response = opener.open(req, timeout=CLICK_AUTOTEST_PREFLIGHT_TIMEOUT)
        final_url = response.geturl() or streamurl
        data = response.read(1400).decode('utf-8', 'ignore')
        try:
            content_type = response.headers.get('Content-Type', '') or ''
        except Exception:
            content_type = ''
        try:
            response.close()
        except Exception:
            pass

        if fuckflix_is_visible_fallback(final_url, referer, '') and not allow_visible_fallback:
            log('FUCKFLIX gateway preflight redirected to wrong fallback for {} | {}'.format(name, final_url), xbmc.LOGERROR)
            return False, False

        head = (data or '')[:180].replace('\n', ' ').replace('\r', ' ')
        if '#EXTM3U' not in data:
            log('FUCKFLIX gateway preflight rejected non-HLS for {} -> {} | type={} | {}'.format(
                name, final_url, content_type or '-', head
            ), xbmc.LOGERROR)
            return False, False

        if '#EXT-X-STREAM-INF' in data:
            if not click_deep_manifest_preflight(opener, final_url, referer, name, profile, data):
                return False, False
            try:
                child = (profile or {}).get('resolved_child_url') or ''
            except Exception:
                child = ''
            if child:
                log('FUCKFLIX gateway deep preflight OK for {} -> {}'.format(name, child))
                return True, child

        log('FUCKFLIX gateway HLS preflight OK for {} -> {} | type={}'.format(
            name, final_url, content_type or '-'
        ))
        return True, final_url
    except HTTPError as e:
        log('FUCKFLIX gateway preflight HTTP {} for {} | {}'.format(getattr(e, 'code', '?'), name, streamurl), xbmc.LOGERROR)
        return False, False
    except Exception as e:
        log('FUCKFLIX gateway preflight error for {} | {}: {}'.format(name, streamurl, e), xbmc.LOGERROR)
        return False, False


def fuckflix_livecams_preflight(streamurl, referer, name, profile):
    """Probe the exact FuckFlix Live Cams primary safely before Kodi/ISA.

    The same URL is globally marked dangerous in the .click senderstatus path
    because native Kodi playback used to hang there.  FuckFlix v70 therefore
    never bypasses that global guard; it validates the manifest and first media
    segment here and then hands the stream to InputStream Adaptive only.
    """
    try:
        opener = com_build_preflight_opener()
        headers = click_preflight_headers(streamurl, referer, profile)
        headers['User-Agent'] = FUCKFLIX_UA
        req = Request(streamurl, headers=headers)
        response = opener.open(req, timeout=FUCKFLIX_LIVECAMS_SAFE_TIMEOUT)
        final_url = response.geturl() or streamurl
        data = response.read(12000).decode('utf-8', 'ignore')
        try:
            response.close()
        except Exception:
            pass

        if '#EXTM3U' not in data:
            log('FUCKFLIX Live Cams safe preflight rejected non-HLS | {}'.format(final_url), xbmc.LOGERROR)
            return False, False

        # If this ever becomes a master playlist, reuse the proven deep parser.
        if '#EXT-X-STREAM-INF' in data:
            if not click_deep_manifest_preflight(opener, final_url, referer, name, profile, data):
                return False, False
            child = (profile or {}).get('resolved_child_url') or ''
            if child:
                log('FUCKFLIX Live Cams safe master/child preflight OK -> {}'.format(child))
                return True, child

        segment_url = click_first_media_segment_url(final_url, data)
        if not segment_url:
            log('FUCKFLIX Live Cams safe preflight found no media segment | {}'.format(final_url), xbmc.LOGERROR)
            return False, False

        seg_headers = click_preflight_headers(segment_url, referer, profile)
        seg_headers['User-Agent'] = FUCKFLIX_UA
        seg_headers['Range'] = 'bytes=0-2047'
        seg_req = Request(segment_url, headers=seg_headers)
        seg_resp = opener.open(seg_req, timeout=FUCKFLIX_LIVECAMS_SAFE_TIMEOUT)
        payload = seg_resp.read(2048)
        try:
            seg_resp.close()
        except Exception:
            pass
        if not payload:
            log('FUCKFLIX Live Cams safe segment preflight returned no data | {}'.format(segment_url), xbmc.LOGERROR)
            return False, False

        log('FUCKFLIX Live Cams safe manifest/segment preflight OK -> {} | {} bytes'.format(segment_url, len(payload)))
        return True, final_url
    except HTTPError as e:
        log('FUCKFLIX Live Cams safe preflight HTTP {} | {}'.format(getattr(e, 'code', '?'), streamurl), xbmc.LOGERROR)
        return False, False
    except Exception as e:
        log('FUCKFLIX Live Cams safe preflight error | {}: {}'.format(streamurl, e), xbmc.LOGERROR)
        return False, False


def fuckflix_preflight(streamurl, referer, name, profile):
    if fuckflix_is_livecams_real(name, streamurl):
        return fuckflix_livecams_preflight(streamurl, referer, name, profile)

    if fuckflix_is_api_gateway_url(streamurl):
        # v69: Do not open the short-lived API gateway with urllib immediately
        # before Kodi opens it again.  The website hands the freshly generated
        # URL directly to Hls.js/Video.js.  Kodi 22 has InputStream Adaptive,
        # which is a better fit for this extensionless HLS gateway.
        log('FUCKFLIX gateway preflight skipped for fresh API token: {} | {}'.format(name, streamurl))
        return True, streamurl

    if '.mp4' in unquote((streamurl or '').lower()):
        result = com_manifest_preflight_ok(streamurl, referer, name)
        return bool(result), result

    ok = bool(click_manifest_preflight_ok(streamurl, referer, name, profile))
    if not ok:
        return False, False

    resolved_child_url = ''
    try:
        resolved_child_url = (profile or {}).get('resolved_child_url') or ''
    except Exception:
        resolved_child_url = ''

    if resolved_child_url:
        if fuckflix_is_slow_skygo_name(name, resolved_child_url):
            warmed_media_url = fuckflix_child_segment_preflight_ok(
                resolved_child_url, referer, name, profile
            )
            if not warmed_media_url:
                return False, False
            resolved_child_url = warmed_media_url
        log('FUCKFLIX using resolved child for {} -> {}'.format(name, resolved_child_url))
        return True, resolved_child_url

    return True, True


def fuckflix_try_channel(name, url, progress=None, channel_index=0, channel_total=0, keep_playing=False, session_opener=None):
    real_only = fuckflix_is_real_only_name(name)
    if keep_playing:
        max_attempts = FUCKFLIX_PLAY_MAX_ATTEMPTS
    elif real_only:
        max_attempts = FUCKFLIX_REAL_ONLY_MAX_ATTEMPTS
    else:
        max_attempts = FUCKFLIX_MAX_ATTEMPTS
    last_reason = ''

    for attempt in range(1, max_attempts + 1):
        fuckflix_progress_update(
            progress, channel_index, channel_total, name,
            'V{}/{} – echter Stream wird gesucht...'.format(attempt, max_attempts)
        )
        # v70: MyCam/Redtraffic is a wrong FuckFlix fallback across the whole
        # site, not only before FashionTV. Never prepare/play it in AutoTest or
        # Einzelstart. Live Cams has one exact, explicitly validated exception.
        allow_fallback = False
        if oxax_autotest_cancelled(progress):
            return False, attempt - 1, 'cancelled'

        if attempt > 1:
            if keep_playing:
                notify('FUCKFLIX RETRY {}: {}'.format(attempt, name), False)
            click_autotest_sleep(FUCKFLIX_RETRY_DELAY, progress, 'FUCKFLIX wartet: {}'.format(name))

        try:
            prepared, reason = fuckflix_prepare_stream_for_autotest(
                name, url, allow_fallback,
                progress=progress, channel_index=channel_index, channel_total=channel_total,
                attempt=attempt, max_attempts=max_attempts, session_opener=session_opener
            )
        except Exception as e:
            log('FUCKFLIX prepare error for {}: {}'.format(name, e), xbmc.LOGERROR)
            prepared, reason = [], 'prepare_error'
        last_reason = reason or last_reason

        if not prepared:
            if reason == 'visible_fallback_only':
                stage = 'V{}/{} – nur falscher Fallback gefunden; REAL wird neu gesucht...'.format(attempt, max_attempts)
            elif reason == 'page_load_error':
                stage = 'V{}/{} – Senderseite nicht geladen; neuer Versuch folgt...'.format(attempt, max_attempts)
            else:
                stage = 'V{}/{} – noch kein Streamlink gefunden; neuer Versuch folgt...'.format(attempt, max_attempts)
            fuckflix_progress_update(progress, channel_index, channel_total, name, stage)
            time.sleep(0.35)
            continue

        for variant_index, item in enumerate(prepared, 1):
            finalurl, streamurl, referer, profile = click_unpack_prepared(item)
            source_kind = (profile or {}).get('source_kind', 'real')
            is_fallback = (not fuckflix_is_livecams_real(name, streamurl)) and fuckflix_is_visible_fallback(streamurl, referer, source_kind)

            fuckflix_progress_update(
                progress, channel_index, channel_total, name,
                'V{}/{} | Var{} – REAL-Link vorprüfen...'.format(attempt, max_attempts, variant_index)
            )
            ok_preflight, preflight_result = fuckflix_preflight(streamurl, referer, name, profile)
            if not ok_preflight:
                last_reason = 'preflight_rejected'
                continue

            play_streamurl = streamurl
            if isinstance(preflight_result, str) and preflight_result not in ('True', 'False'):
                play_streamurl = preflight_result
                finalurl = click_build_final_stream_url(play_streamurl, referer, profile)

            # A neutral proxy can redirect to Redtraffic/MyCam only after the
            # preflight. Reclassify the final child before Kodi sees it.
            is_fallback = (not fuckflix_is_livecams_real(name, play_streamurl)) and fuckflix_is_visible_fallback(play_streamurl, referer, source_kind)
            if is_fallback:
                log('FUCKFLIX final wrong fallback globally blocked for {}: {}'.format(name, play_streamurl))
                last_reason = 'visible_fallback_only'
                continue

            player = SenderStatusPlayer('FUCKFLIX Senderstatus')
            item_obj = xbmcgui.ListItem(name)
            use_isa_gateway = fuckflix_is_api_gateway_url(play_streamurl) or fuckflix_is_livecams_real(name, play_streamurl)
            try:
                item_obj.setProperty('IsPlayable', 'true')
                if '.m3u8' in unquote((play_streamurl or '').lower()) or use_isa_gateway:
                    item_obj.setMimeType('application/vnd.apple.mpegurl')
                    item_obj.setContentLookup(False)

                if use_isa_gateway:
                    # Kodi 22 / InputStream Adaptive 22.x supports common_headers,
                    # manifest_headers and stream_headers.  Supplying all three
                    # makes Referer/Origin/User-Agent available to the gateway,
                    # variant playlists, keys and media segments.
                    isa_headers = {
                        # Keep the exact browser UA that requested the FuckFlix
                        # page/API token. Some signed gateways bind playback to
                        # the request fingerprint.
                        'User-Agent': FUCKFLIX_UA,
                        'Accept': '*/*',
                    }
                    ref = (profile or {}).get('referer')
                    origin = (profile or {}).get('origin')
                    if ref:
                        isa_headers['Referer'] = ref
                    if origin:
                        isa_headers['Origin'] = origin.rstrip('/')
                    header_string = urlencode(isa_headers)
                    item_obj.setProperty('inputstream', 'inputstream.adaptive')
                    item_obj.setProperty('inputstream.adaptive.common_headers', header_string)
                    item_obj.setProperty('inputstream.adaptive.manifest_headers', header_string)
                    item_obj.setProperty('inputstream.adaptive.stream_headers', header_string)
                    log('FUCKFLIX InputStream Adaptive playback for {} | kind={} | referer={} | origin={}'.format(
                        name, 'XLivetv' if fuckflix_is_api_gateway_url(play_streamurl) else 'LiveCams-safe', ref or '-', origin or '-'
                    ))
            except Exception as e:
                log('FUCKFLIX ListItem/ISA setup warning for {}: {}'.format(name, e), xbmc.LOGWARNING)

            try:
                xbmc.executebuiltin('PlayerControl(Stop)')
                time.sleep(0.25)
                play_target = play_streamurl if use_isa_gateway else finalurl
                player.play(play_target, item_obj)
            except Exception as e:
                log('FUCKFLIX player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
                last_reason = 'player_error'
                continue

            hold = 0.2 if keep_playing else (FUCKFLIX_PLAYBOY_HOLD_SECONDS if com_status_plain_name(name).lower() == 'playboy tv' else FUCKFLIX_PLAY_SECONDS)
            if fuckflix_is_api_gateway_url(play_streamurl):
                start_timeout = FUCKFLIX_API_START_TIMEOUT
            elif fuckflix_is_livecams_real(name, play_streamurl):
                start_timeout = FUCKFLIX_LIVECAMS_START_TIMEOUT
            else:
                start_timeout = FUCKFLIX_SLOW_START_TIMEOUT if fuckflix_is_slow_skygo_name(name, play_streamurl) else FUCKFLIX_START_TIMEOUT
            log('FUCKFLIX playback timeout for {}: {}s'.format(name, start_timeout))
            ok = senderstatus_wait_for_player(
                player,
                start_timeout=start_timeout,
                play_seconds=hold,
                stable_seconds=(1.5 if com_status_plain_name(name).lower() == 'playboy tv' else CLICK_AUTOTEST_STABLE_SECONDS),
                progress=progress,
                progress_message='FUCKFLIX: {} ({}/{})\nV{} | Var{} | {}'.format(
                    name, channel_index, channel_total, attempt, variant_index,
                    'FALLBACK' if is_fallback else 'REAL'
                ),
                log_prefix='FUCKFLIX Senderstatus'
            )

            if ok:
                label = 'FALLBACK' if is_fallback else 'REAL'
                if keep_playing:
                    notify('FUCKFLIX startet {}: {} | V{} | Var{} | {:.1f}s'.format(label, name, attempt, variant_index, hold), False)
                    return True, attempt, 'visible_fallback' if is_fallback else 'real'

                click_stop_player_safely(player, name, progress=progress, message='FUCKFLIX Player-Cleanup: {}'.format(name))
                notify('FUCKFLIX OK {}: {} | V{} | Var{} | {:.1f}s'.format(label, name, attempt, variant_index, hold), False)
                return True, attempt, 'visible_fallback' if is_fallback else 'real'

            click_stop_player_safely(player, name, progress=progress, message='FUCKFLIX Player-Cleanup: {}'.format(name))
            last_reason = 'no_playback'

    return False, max_attempts, last_reason or 'no_playback'


@site.register()
def Play_FUCKFLIX(url, name, download=None):
    session_opener = fuckflix_new_browser_opener()
    fuckflix_bootstrap_session(session_opener)
    ok, attempts, reason = fuckflix_try_channel(name, url, keep_playing=True, session_opener=session_opener)
    if not ok:
        notify('FUCKFLIX: Stream nach {} Versuchen nicht verfügbar'.format(attempts), True)


def fuckflix_fetch_channels_for_autotest(progress=None, opener=None):
    channels = []
    seen_channels = set()
    page_count = 0
    opener = opener or fuckflix_new_browser_opener()

    try:
        first_html = fuckflix_http_get(opener, BASE_FUCKFLIX, None)
    except Exception as e:
        log('FUCKFLIX first page load error {}: {}'.format(BASE_FUCKFLIX, e), xbmc.LOGERROR)
        return [], 0, opener

    max_page = fuckflix_max_page_from_html(first_html, BASE_FUCKFLIX)
    log('FUCKFLIX numbered pagination detected/planned: {} pages'.format(max_page))

    for page_number in range(1, max_page + 1):
        if oxax_autotest_cancelled(progress):
            break

        page_url = fuckflix_page_url(page_number)
        page_count += 1
        try:
            if progress:
                progress.update(0, 'FUCKFLIX: Lade Page {}/{}...'.format(page_number, max_page))
            html = first_html if page_number == 1 else fuckflix_http_get(opener, page_url, BASE_FUCKFLIX)
        except Exception as e:
            log('FUCKFLIX page load error {}: {}'.format(page_url, e), xbmc.LOGERROR)
            continue

        page_channels = fuckflix_parse_channels_from_html(html, page_url)
        added = 0
        for name, videourl, img in page_channels:
            if videourl in seen_channels:
                continue
            seen_channels.add(videourl)
            channels.append((name, videourl, img))
            added += 1
            if len(channels) >= FUCKFLIX_MAX_CHANNELS:
                break

        log('FUCKFLIX page {}: {} neue Sender | total {}'.format(page_number, added, len(channels)))
        if len(channels) >= FUCKFLIX_MAX_CHANNELS:
            break

    log('FUCKFLIX channels: {} from {} pages'.format(len(channels), page_count))
    return channels, page_count, opener


@site.register()
def AutoTest_FUCKFLIX(url, close_directory=True):
    lock_token, lock_window = fuckflix_acquire_autotest_lock()
    if not lock_token:
        notify('FUCKFLIX-Prüfung läuft bereits – kein zweiter Test gestartet', True)
        log('FUCKFLIX duplicate AutoTest invocation returned without touching active player/dialogs', xbmc.LOGWARNING)
        if close_directory:
            try:
                senderstatus_add_main_menu_items()
                utils.eod()
            except Exception:
                pass
        return

    progress = None
    ok_count = 0
    failed = []
    fallback_ok = []
    wrong_fallback_only = []
    skipped = []
    range_label = ''
    page_count = 0
    channels = []
    session_opener = fuckflix_new_browser_opener()

    try:
        try:
            progress = xbmcgui.DialogProgress()
            progress.create('FUCKFLIX Senderstatus prüfen', 'Lade Pages...')
        except Exception:
            progress = None

        try:
            channels, page_count, session_opener = fuckflix_fetch_channels_for_autotest(progress, session_opener)
            if not channels:
                notify('FUCKFLIX: keine Sender gefunden', True)
                return

            channels, range_label, skipped = fuckflix_select_senderstatus_range(channels)
            if not channels:
                log('FUCKFLIX range selection cancelled or empty')
                return

            notify('FUCKFLIX Senderstatus startet: {} | {} Sender / {} Pages'.format(range_label, len(channels), page_count), False)
            for idx, (name, videourl, img) in enumerate(channels, 1):
                if oxax_autotest_cancelled(progress):
                    break
                percent = int(max(0, min(99, ((idx - 1) * 100.0) / max(1, len(channels)))))
                progress = senderstatus_reopen_progress(
                    progress,
                    'FUCKFLIX Senderstatus prüfen',
                    'FUCKFLIX: {} ({}/{})\nStarte Senderanalyse...'.format(name, idx, len(channels)),
                    percent,
                    'FUCKFLIX Senderstatus'
                )
                fuckflix_progress_update(progress, idx, len(channels), name, 'Starte Senderanalyse...', percent)
                log('FUCKFLIX channel {}/{}: {} | {}'.format(idx, len(channels), name, videourl))
                ok, attempts, reason = fuckflix_try_channel(
                    name, videourl, progress=progress,
                    channel_index=idx, channel_total=len(channels), keep_playing=False,
                    session_opener=session_opener
                )
                if ok:
                    ok_count += 1
                    if reason == 'visible_fallback':
                        fallback_ok.append(name)
                else:
                    if reason == 'visible_fallback_only':
                        wrong_fallback_only.append(name)
                        log('FUCKFLIX classified wrong-fallback-only: {}'.format(name))
                        fuckflix_progress_update(
                            progress, idx, len(channels), name,
                            'Kein REAL-Link gefunden – falscher Fallback wurde blockiert.'
                        )
                    else:
                        failed.append(name)

                result_percent = int((idx * 100) / max(len(channels), 1))
                if ok:
                    result_label = 'OK FALLBACK' if reason == 'visible_fallback' else 'OK REAL'
                elif reason == 'visible_fallback_only':
                    result_label = 'REAL fehlt – falscher Fallback blockiert'
                else:
                    result_label = 'Fehler: {}'.format(reason or 'unbekannt')
                progress = senderstatus_reopen_progress(
                    progress,
                    'FUCKFLIX Senderstatus prüfen',
                    'FUCKFLIX fertig: {} ({}/{})\n{} | OK: {} | Falsche Fallbacks: {} | Fehler: {}'.format(
                        name, idx, len(channels), result_label, ok_count,
                        len(wrong_fallback_only), len(failed)
                    ),
                    result_percent,
                    'FUCKFLIX Senderstatus'
                )
                click_autotest_sleep(FUCKFLIX_PAUSE_SECONDS, progress, 'FUCKFLIX nächster Sender: {}'.format(name))
        finally:
            try:
                if progress:
                    progress.close()
            except Exception:
                pass

        status_msg = 'FUCKFLIX Senderstatus v71 summary: {}/{} OK | range: {} | total: {} | pages: {} | failed: {} | wrong_fallback_only: {} | fallback_ok: {} | skipped: {}'.format(
            ok_count,
            len(channels) if channels else ok_count + len(failed) + len(wrong_fallback_only),
            range_label or '-',
            len(channels) if channels else ok_count + len(failed) + len(wrong_fallback_only),
            page_count,
            ', '.join(failed) if failed else '-',
            ', '.join(wrong_fallback_only) if wrong_fallback_only else '-',
            ', '.join(fallback_ok) if fallback_ok else '-',
            ', '.join(skipped) if skipped else '-'
        )
        log(status_msg)
        notify('FUCKFLIX {}: {}/{} OK, {} falsche Fallbacks blockiert'.format(
            range_label or '-',
            ok_count,
            len(channels) if channels else ok_count + len(failed) + len(wrong_fallback_only),
            len(wrong_fallback_only)
        ), bool(failed or wrong_fallback_only))

        if close_directory:
            senderstatus_final_cleanup('FUCKFLIX Senderstatus', close_directory=True)
    finally:
        fuckflix_release_autotest_lock(lock_token, lock_window)


# -------------------------------------------------------------------------
# oxax.tv
# -------------------------------------------------------------------------

def oxax_get_html(opener, url, referer):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html, */*; q=0.01',
        'Accept-Language': 'ru-RU,ru;q=0.9,de-DE,de;q=0.8,en;q=0.7',
        'Accept-Encoding': 'identity',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': referer,
        'Origin': BASE_OXAX.rstrip('/'),
        'Connection': 'keep-alive',
    }

    req = Request(url, headers=headers)
    response = opener.open(req, timeout=30)
    data = response.read()

    return data.decode('utf-8', 'ignore')


def oxax_logo_cache_dir():
    try:
        if xbmcvfs:
            path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cumination/oxax_logos/')
        else:
            path = ''

        if not path:
            return ''

        if not os.path.exists(path):
            os.makedirs(path)

        return path
    except Exception as e:
        log('OXAX logo cache dir error: {}'.format(e), xbmc.LOGERROR)
        return ''


def oxax_extract_css_rules(css, keyword):
    rules = []

    for match in re.finditer(r'[^{}]*' + re.escape(keyword) + r'[^{}]*\{[^}]*\}', css or '', re.IGNORECASE | re.DOTALL):
        rules.append(match.group(0))

    return '\n'.join(rules)


def oxax_logo_sprite_info(opener):
    try:
        css_url = urljoin(BASE_OXAX, 'ss.css')
        css = browser_get(opener, css_url, BASE_OXAX, accept='text/css,*/*;q=0.1')
    except Exception as e:
        log('OXAX logo CSS load error: {}'.format(e), xbmc.LOGERROR)
        return None

    css_focus = oxax_extract_css_rules(css, 'tv_sp')

    if not css_focus:
        css_focus = css

    url_matches = re.findall(r'url\(\s*["\']?([^\)"\']+)["\']?\s*\)', css_focus, re.IGNORECASE)

    sprite_url = ''

    for item in url_matches:
        item = html_unescape(item).strip()

        if not item:
            continue

        low = item.lower()

        if any(ext in low for ext in ['.png', '.jpg', '.jpeg', '.webp', '.gif']):
            sprite_url = urljoin(BASE_OXAX, item)
            break

    if not sprite_url:
        log('OXAX logo sprite not found in CSS', xbmc.LOGWARNING)
        return None

    width = 0
    height = 0

    width_match = re.search(r'width\s*:\s*(\d+)px', css_focus, re.IGNORECASE)
    height_match = re.search(r'height\s*:\s*(\d+)px', css_focus, re.IGNORECASE)

    if width_match:
        width = int(width_match.group(1))

    if height_match:
        height = int(height_match.group(1))

    # Sichere Fallbacks, falls das CSS die Werte nicht direkt im tv_sp-Block liefert.
    if not width:
        width = 165

    if not height:
        height = 80

    log('OXAX logo sprite: {} | {}x{}'.format(sprite_url, width, height))

    return {
        'url': sprite_url,
        'width': width,
        'height': height,
    }


def oxax_extract_logo_positions(html):
    positions = set()

    for match in re.finditer(
        r'background-position\s*:\s*(-?\d+)px\s+(-?\d+)px',
        html or '',
        re.IGNORECASE
    ):
        positions.add((int(match.group(1)), int(match.group(2))))

    return positions


def oxax_download_sprite(opener, sprite_url):
    headers = {
        'User-Agent': UA,
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Accept-Language': 'ru-RU,ru;q=0.9,de-DE,de;q=0.8,en;q=0.7',
        'Referer': BASE_OXAX,
        'Connection': 'keep-alive',
    }

    req = Request(sprite_url, headers=headers)
    response = opener.open(req, timeout=30)
    return response.read()


def oxax_build_logo_map(opener, html):
    logo_map = {}

    if Image is None:
        log('OXAX logo crop skipped: PIL/Image module not available', xbmc.LOGWARNING)
        return logo_map

    positions = oxax_extract_logo_positions(html)

    log('OXAX logo positions: {}'.format(len(positions)))

    if not positions:
        return logo_map

    info = oxax_logo_sprite_info(opener)

    if not info:
        return logo_map

    cache_dir = oxax_logo_cache_dir()

    if not cache_dir:
        return logo_map

    try:
        data = oxax_download_sprite(opener, info['url'])
        sprite = Image.open(io.BytesIO(data)).convert('RGBA')
    except Exception as e:
        log('OXAX logo sprite load/crop error: {}'.format(e), xbmc.LOGERROR)
        return logo_map

    width = int(info.get('width') or 0)
    height = int(info.get('height') or 0)

    # Oxax meldet im CSS teils 150x75, die echte Sprite-Datei ist aber z. B. 120x5250.
    # Wenn alle Logos in einer einzigen Spalte liegen, ist die echte Logo-Breite die Sprite-Breite.
    if not width or width > sprite.size[0]:
        width = sprite.size[0]

    # Höhe robust aus den background-position-Schritten ableiten.
    # Die OXAX-Sprite-Positionen liegen typischerweise in 75px-Schritten.
    if not height:
        y_values = sorted(set(abs(int(y)) for x, y in positions))
        diffs = []

        for idx in range(1, len(y_values)):
            diff = y_values[idx] - y_values[idx - 1]

            if diff > 0:
                diffs.append(diff)

        height = min(diffs) if diffs else 75

    if height > sprite.size[1]:
        height = 75

    log('OXAX logo crop size: {}x{} from sprite {}'.format(width, height, sprite.size))

    for x, y in positions:
        left = max(0, -int(x))
        top = max(0, -int(y))
        right = left + width
        bottom = top + height

        if right > sprite.size[0] or bottom > sprite.size[1]:
            log('OXAX logo crop outside sprite: pos={} {} box=({}, {}, {}, {}) sprite={}'.format(x, y, left, top, right, bottom, sprite.size), xbmc.LOGWARNING)
            continue

        filename = 'oxax_logo_{}_{}_{}x{}.png'.format(abs(x), abs(y), width, height)
        out_path = os.path.join(cache_dir, filename)

        try:
            if not os.path.exists(out_path):
                sprite.crop((left, top, right, bottom)).save(out_path, 'PNG')

            logo_map[(x, y)] = out_path
        except Exception as e:
            log('OXAX logo save error {}: {}'.format(filename, e), xbmc.LOGERROR)

    log('OXAX logos ready: {}'.format(len(logo_map)))

    return logo_map


def oxax_get_block_title(block):
    match = re.search(r'title=["\']([^"\']+)["\']', block or '', re.IGNORECASE | re.DOTALL)
    return clean_text(match.group(1)) if match else ''


def oxax_get_block_href(block):
    match = re.search(r'<a[^>]+href=["\']([^"\']+)["\']', block or '', re.IGNORECASE | re.DOTALL)
    return html_unescape(match.group(1)).strip() if match else ''


def oxax_get_block_logo(block, logo_map):
    match = re.search(
        r'background-position\s*:\s*(-?\d+)px\s+(-?\d+)px',
        block or '',
        re.IGNORECASE
    )

    if not match:
        return ''

    key = (int(match.group(1)), int(match.group(2)))
    return logo_map.get(key, '') if logo_map else ''


def oxax_parse_channels(html, logo_map=None):
    html = html_unescape(html or '')
    html = html.replace('\n', ' ').replace('\r', ' ')

    channels = []
    seen = set()

    blocks = re.findall(
        r'(<div[^>]*class=["\'][^"\']*tv_sp[^"\']*["\'][^>]*>.*?</div>)',
        html,
        re.IGNORECASE | re.DOTALL
    )

    log('OXAX parser blocks: {}'.format(len(blocks)))

    if not blocks:
        fallback = re.findall(
            r'<div\s+class=["\']tv_sp["\']\s+title=["\']([^"\']+)["\']>\s*<a\s+href=["\']([^"\']+)["\']',
            html,
            re.IGNORECASE | re.DOTALL
        )

        log('OXAX parser fallback blocks: {}'.format(len(fallback)))

        for name, href in fallback:
            name = clean_text(name)
            href = html_unescape(href).strip()

            if not href.endswith('.html'):
                continue

            videourl = urljoin(BASE_OXAX, href)

            if videourl in seen:
                continue

            seen.add(videourl)
            channels.append((name, videourl, ''))

        return channels

    for block in blocks:
        name = oxax_get_block_title(block)
        href = oxax_get_block_href(block)
        img = oxax_get_block_logo(block, logo_map)

        if not name or not href:
            continue

        if not href.endswith('.html'):
            continue

        videourl = urljoin(BASE_OXAX, href)

        if videourl in seen:
            continue

        seen.add(videourl)
        channels.append((name, videourl, img))

    return channels

@site.register()
def List_OXAX(url):
    cj = http.cookiejar.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))

    endpoints = [
        (urljoin(BASE_OXAX, 'spisok'), BASE_OXAX),
        (urljoin(BASE_OXAX, 'spisok?vse=4'), urljoin(BASE_OXAX, 'porno-kanaly.html')),
        (urljoin(BASE_OXAX, 'spisok?vse=1'), BASE_OXAX),
        (urljoin(BASE_OXAX, 'vz_spi.php'), BASE_OXAX),
    ]

    channels = []

    for endpoint, referer in endpoints:
        try:
            html = oxax_get_html(opener, endpoint, referer)

            log('OXAX endpoint: {}'.format(endpoint))
            log('OXAX html length: {}'.format(len(html or '')))
            log('OXAX html first 300: {}'.format((html or '')[:300]))

            logo_map = oxax_build_logo_map(opener, html)
            channels = oxax_parse_channels(html, logo_map)

            log('OXAX found channels: {}'.format(len(channels)))

            if channels:
                break

        except Exception as e:
            log('OXAX list endpoint error {}: {}'.format(endpoint, e), xbmc.LOGERROR)

    if not channels:
        notify('OXAX: Keine Sender gefunden - Log prüfen', True)
        utils.eod()
        return

    for name, videourl, img in channels:
        site.add_download_link(name, videourl, 'Play_OXAX', img, '', noDownload=True)

    utils.eod()


def oxax_stream_headers(page_url=None, cj=None):
    # OXAX ist bei Kodi deutlich empfindlicher als .com/.click.
    # Wichtig: Stream nicht mehr vorher per Python leerlesen, sondern Kodi mit
    # moeglichst browsernahen Headern + Cookies selbst den Redirect ausfuehren lassen.
    headers = {
        'User-Agent': UA,
        'Accept': 'application/x-mpegURL, application/vnd.apple.mpegurl, */*',
        'Accept-Language': 'ru-RU,ru;q=0.9,de-DE,de;q=0.8,en;q=0.7',
        'Referer': BASE_OXAX,
        'Origin': BASE_OXAX.rstrip('/'),
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
    }

    cookies = cookie_header(cj) if cj else ''

    if cookies:
        headers['Cookie'] = cookies

    return headers


def oxax_kodi_stream_url(streamurl, page_url=None, cj=None):
    return streamurl + '|' + urlencode(oxax_stream_headers(page_url, cj))


def oxax_resolve_redirect_no_read(opener, streamurl, page_url, cj=None):
    try:
        req = Request(streamurl, headers=oxax_stream_headers(page_url, cj))
        response = opener.open(req, timeout=8)
        final_url = response.geturl()

        try:
            response.close()
        except Exception:
            pass

        log('OXAX redirect check URL: {}'.format(streamurl))
        log('OXAX redirect final URL: {}'.format(final_url))

        if final_url and final_url != streamurl and 'index.m3u8' in final_url:
            return final_url
    except Exception as e:
        log('OXAX redirect check failed {}: {}'.format(streamurl, e), xbmc.LOGERROR)

    return ''


def oxax_manifest_ok(opener, streamurl, page_url):
    last_error = None

    # Einige Oxax-Manifeste liefern kurz nach dem Redirect zuerst eine leere Antwort.
    # Deshalb bei leerem Body einmal neu versuchen, statt sofort aufzugeben.
    for attempt in range(1, 3):
        try:
            req = Request(streamurl, headers=oxax_stream_headers(page_url))
            response = opener.open(req, timeout=10)

            final_url = response.geturl()
            data = response.read(500).decode('utf-8', 'ignore')

            log('OXAX manifest test URL: {}'.format(streamurl))
            log('OXAX manifest final URL: {}'.format(final_url))
            log('OXAX manifest first 120: {}'.format(data[:120].replace('\n', ' ')))

            if '#EXTM3U' in data:
                return final_url

            if not data.strip() and attempt == 1:
                log('OXAX manifest blank response - retrying once')
                time.sleep(1.2)
                continue

            return None

        except Exception as e:
            last_error = e
            break

    if last_error:
        log('OXAX manifest test failed {}: {}'.format(streamurl, last_error), xbmc.LOGERROR)

    return None


def oxax_decode_b64_part(text):
    text = re.sub(r'[^A-Za-z0-9+/=]', '', text or '')

    if not text:
        return ''

    # Base64-Laengen, die 1 ueber Vielfachem von 4 liegen, koennen nicht dekodiert werden.
    if len(text.replace('=', '')) % 4 == 1:
        return ''

    text = text + ('=' * ((4 - len(text) % 4) % 4))

    try:
        return base64.b64decode(text).decode('utf-8', 'ignore')
    except Exception:
        return ''


def oxax_clean_decoded_text(text):
    text = html_unescape(text or '').replace('\\/', '/')

    # Steuerzeichen entfernen, sonst entstehen Fehler wie:
    # URL can't contain control characters ... \x14
    text = ''.join(ch for ch in text if ord(ch) >= 32 and ord(ch) != 127)

    return text


def oxax_sanitize_template(decoded):
    decoded = oxax_clean_decoded_text(decoded)

    # Bevorzugt r.pokaz.me, weil die funktionierenden DevTools-URLs dort landen.
    # Der Decoder darf bewusst etwas "zu viel" nehmen; die Token-Varianten darunter
    # schneiden PlayerJS-Reste wie MMM/SSS/E556 sauberer weg.
    match = re.search(
        r'https?://r\.pokaz\.me/\{v1\}([A-Za-z0-9]+)\{v2\}([A-Za-z0-9]+)',
        decoded,
        re.IGNORECASE
    )

    if match:
        return 'https://r.pokaz.me/{v1}' + match.group(1) + '{v2}' + match.group(2)

    match = re.search(
        r'https?://s\.oxax\.tv/\{v1\}([A-Za-z0-9]+)\{v2\}([A-Za-z0-9]+)',
        decoded,
        re.IGNORECASE
    )

    if match:
        return 'https://s.oxax.tv/{v1}' + match.group(1) + '{v2}' + match.group(2)

    return ''


def oxax_templates_from_fragment(fragment):
    templates = []

    fragment = re.sub(r'[^A-Za-z0-9+/=]', '', fragment or '')

    # Von lang nach kurz testen: manche PlayerJS-Strings haben am Ende JSON-/Garbage-Reste.
    for cut in range(len(fragment), 20, -1):
        decoded = oxax_decode_b64_part(fragment[:cut])

        if not decoded:
            continue

        tpl = oxax_sanitize_template(decoded)

        if tpl and tpl not in templates:
            templates.append(tpl)
            break

    return templates


def oxax_playerjs_templates(html):
    html = html_unescape(html or '').replace('\\/', '/')
    templates = []

    player_matches = re.findall(
        r'new\s+Playerjs\s*\(\s*["\']([^"\']+)["\']',
        html,
        re.IGNORECASE | re.DOTALL
    )

    log('OXAX PlayerJS blocks: {}'.format(len(player_matches)))

    for raw in player_matches:
        raw = raw.strip()

        # Varianten: original, ohne #, ohne #F/#M/... Marker
        variants = [raw]

        if raw.startswith('#'):
            variants.append(raw[1:])

            if len(raw) > 2:
                variants.append(raw[2:])

        for variant in variants:
            # 1. Komplette/nahezu komplette Dekodierung versuchen
            full_decoded = oxax_decode_b64_part(variant)
            tpl = oxax_sanitize_template(full_decoded)

            if tpl and tpl not in templates:
                templates.append(tpl)

            # 2. Marker-Suche mit unterschiedlichen Base64-Ausrichtungen.
            markers = [
                'aHR0cHM6Ly9yLnBva2F6Lm1l',  # https://r.pokaz.me
                'ci5wb2thei5tZ',              # r.pokaz.me, verschobene Base64-Ausrichtung
                'cG9rYXoubWU',                # pokaz.me
                'LnBva2F6Lm1l',               # .pokaz.me
                'aHR0cHM6Ly9zLm94YXgudHYv',   # https://s.oxax.tv/
                'cy5veGF4LnR2',               # s.oxax.tv, verschobene Base64-Ausrichtung
                'b3hheC50dg',                 # oxax.tv
            ]

            for marker in markers:
                start_pos = 0

                while True:
                    pos = variant.find(marker, start_pos)

                    if pos == -1:
                        break

                    win_start = max(0, pos - 100)
                    win_end = min(len(variant), pos + 420)
                    window = variant[win_start:win_end]
                    rel_pos = pos - win_start

                    for offset in range(0, min(rel_pos + 1, 100)):
                        frag = window[offset:]

                        for tpl in oxax_templates_from_fragment(frag):
                            if tpl and tpl not in templates:
                                templates.append(tpl)

                    start_pos = pos + len(marker)

    templates.sort(key=lambda x: 0 if 'r.pokaz.me' in x else 1)

    return templates


def oxax_token_variants(token, prefer_suffix=False):
    """Return safe variants for the small PlayerJS glue tokens around {v2}.

    Examples seen in the log:
    - aMMM498   -> a498, a, original
    - ...SSSds4E -> prefix before SSS, original
    - ...MMMLC627 -> prefix before MMM, original
    - ...5556G3DMMM -> prefixes before 5556G3D / 556G3D / MMM, original
    """
    token = re.sub(r'[^A-Za-z0-9]', '', token or '')
    variants = []

    def add(item):
        item = re.sub(r'[^A-Za-z0-9]', '', item or '')
        if item and item not in variants:
            variants.append(item)

    marker_patterns = [
        'SSSds4E', 'SSS',
        'E556G3D', 'DE556G3D', '5556G3D', '556G3D',
        'MMM6G34', 'MMMLC', 'MMMLU', 'MMML', 'MMM',
        'QPUhc', 'QPUh', 'PUhc', 'Q1V6', 'Q1V',
    ]

    if prefer_suffix:
        # Bei Suffixen ist meistens alles ab Marker Garbage.
        for marker in marker_patterns:
            pos = token.find(marker)
            if pos > -1:
                add(token[:pos])

        # Wenn nach einer hexartigen Nutzlast ein Marker mit Grossbuchstaben kommt,
        # die hexartige Nutzlast als Kandidat testen.
        match = re.match(r'^([0-9a-f]{2,})(?:[A-Z].*)$', token)
        if match:
            add(match.group(1))

        for marker in marker_patterns:
            if marker in token:
                add(token.replace(marker, ''))

        add(token)
    else:
        # Bei Prefixen kann MMM mitten drin stehen (z. B. aMMM498).
        # Erst "Marker entfernen", dann "ab Marker abschneiden", dann Original.
        for marker in marker_patterns:
            if marker in token:
                add(token.replace(marker, ''))

        for marker in marker_patterns:
            pos = token.find(marker)
            if pos > -1:
                add(token[:pos])

        add(token)

    return variants


def oxax_template_to_candidates(tpl, kodk, kos):
    """Build ordered HLS candidate URLs from one decoded template.

    Wichtig fuer den aktuellen Test: nicht mehr pauschal alles auf r.pokaz.me
    umbiegen. Wenn die Website im PlayerJS s.oxax.tv liefert, testen wir zuerst
    genau diesen Host und danach erst den r.pokaz.me-Spiegel.
    """
    tpl = oxax_clean_decoded_text(tpl or '').strip()

    match = re.search(
        r'(https?://(?:r\.pokaz\.me|s\.oxax\.tv))/\{v1\}([A-Za-z0-9]+)\{v2\}([A-Za-z0-9]+)',
        tpl,
        re.IGNORECASE
    )

    if not match:
        item = tpl.replace('{v1}', kodk).replace('{v2}', kos)
        return oxax_candidate_variants(item)

    host = match.group(1)
    pre_raw = match.group(2)
    post_raw = match.group(3)

    urls = []

    def add(host_url, pre, post):
        item = host_url.rstrip('/') + '/' + kodk + pre + kos + post
        item = oxax_clean_decoded_text(item).strip()
        item = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', item).strip()

        if item and item not in urls:
            urls.append(item)

    hosts = [host]

    if 's.oxax.tv' in host:
        hosts.append('https://r.pokaz.me')
    elif 'r.pokaz.me' in host:
        hosts.append('https://s.oxax.tv')

    pre_variants = oxax_token_variants(pre_raw, prefer_suffix=False)
    post_variants = oxax_token_variants(post_raw, prefer_suffix=True)

    for host_url in hosts:
        for pre in pre_variants:
            for post in post_variants:
                add(host_url, pre, post)

    return urls


def oxax_candidate_variants(url):
    """Fallback variants for non-template direct URLs."""
    url = oxax_clean_decoded_text(url or '').strip()
    url = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', url).strip()

    variants = []

    def add(item):
        item = oxax_clean_decoded_text(item or '').strip()
        item = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', item).strip()
        if item and item not in variants:
            variants.append(item)

    marker_patterns = [
        'SSSds4E', 'SSS',
        'E556G3D', 'DE556G3D', '5556G3D', '556G3D',
        'MMM6G34', 'MMMLC', 'MMMLU', 'MMML', 'MMM',
        'QPUhc', 'QPUh', 'PUhc', 'Q1V6', 'Q1V',
    ]

    for marker in marker_patterns:
        pos = url.find(marker)
        if pos > -1:
            add(url[:pos])

    for marker in marker_patterns:
        if marker in url:
            add(url.replace(marker, ''))

    add(url)

    result = []
    for item in variants:
        # Nicht mehr automatisch s.oxax.tv auf r.pokaz.me umbiegen.
        # Der aktuelle LibreELEC-Test zeigt: s.oxax.tv konnte Superone HD abspielen,
        # waehrend r.pokaz.me bei Brazzers/Red Lips nur einen Demuxer-Fehler erzeugte.
        if item and item not in result:
            result.append(item)

        if 's.oxax.tv/' in item:
            mirror = item.replace('https://s.oxax.tv/', 'https://r.pokaz.me/')
            mirror = mirror.replace('http://s.oxax.tv/', 'https://r.pokaz.me/')

            if mirror and mirror not in result:
                result.append(mirror)

        elif 'r.pokaz.me/' in item:
            mirror = item.replace('https://r.pokaz.me/', 'https://s.oxax.tv/')
            mirror = mirror.replace('http://r.pokaz.me/', 'https://s.oxax.tv/')

            if mirror and mirror not in result:
                result.append(mirror)

    return result


def oxax_get_stream_candidates(html, page_url):
    html = html_unescape(html or '').replace('\\/', '/')

    candidates = []

    kodk_match = re.search(
        r'var\s+kodk\s*=\s*["\']([^"\']+)["\']',
        html,
        re.IGNORECASE | re.DOTALL
    )

    kos_match = re.search(
        r'var\s+kos\s*=\s*["\']([^"\']+)["\']',
        html,
        re.IGNORECASE | re.DOTALL
    )

    kodk = kodk_match.group(1).strip() if kodk_match else ''
    kos = kos_match.group(1).strip() if kos_match else ''

    log('OXAX kodk: {}'.format(kodk))
    log('OXAX kos: {}'.format(kos))

    templates = oxax_playerjs_templates(html)

    log('OXAX PlayerJS templates: {}'.format(len(templates)))

    for tpl in templates:
        log('OXAX template: {}'.format(tpl))

        for variant in oxax_template_to_candidates(tpl, kodk, kos):
            if variant and variant not in candidates:
                candidates.append(variant)

    # Fallback: direkte m3u8 im HTML, falls manche Sender anders aufgebaut sind.
    direct_links = re.findall(
        r'(https?://[^"\']+?\.m3u8[^"\']*)',
        html,
        re.IGNORECASE | re.DOTALL
    )

    for link in direct_links:
        for variant in oxax_candidate_variants(link.strip()):
            if variant and variant not in candidates:
                candidates.append(variant)

    clean = []
    seen = set()

    for item in candidates:
        item = html_unescape(item).strip()

        if not item:
            continue

        if item in seen:
            continue

        seen.add(item)
        clean.append(item)

    log('OXAX stream candidates: {}'.format(len(clean)))

    for item in clean:
        log('OXAX candidate: {}'.format(item))

    return clean


def oxax_candidate_tail(item):
    item = oxax_clean_decoded_text(item or '')
    query = urlparse(item).query or ''
    qs = parse_qs(query)
    k_values = qs.get('k') or []
    token = k_values[0] if k_values else ''

    if not token:
        match = re.search(r'[?&]k=([^&|]+)', item)
        token = match.group(1) if match else ''

    # OXAX-kodk sieht typischerweise so aus:
    # 1783201286p5i16i461i291S + eigentlicher Streamtoken
    if 'S' in token:
        token = token.rsplit('S', 1)[-1]

    return re.sub(r'[^A-Za-z0-9]', '', token or '')


OXAX_VOLATILE_MARKERS = [
    'SSSds4E', 'SSS',
    'E556G3D', 'DE556G3D', '5556G3D', '556G3D', 'G3DQ', 'G3D',
    'MMMLC', 'MMMLU', 'MMMLB', 'MMML', 'MMM',
    'XXLNXXX', 'Q1V6', 'Q1V', 'Q17', 'QPUhc', 'QPUh', 'PUhc',
]


def oxax_candidate_is_volatile(item):
    tail = oxax_candidate_tail(item)

    if not tail:
        return True

    # Mehrere Fehlversuche im grossen LibreELEC-Test waren keine Host-Probleme,
    # sondern kurzlebige/kaputte PlayerJS-Varianten mit Restmarkern wie SSS/MMM
    # oder 556G3D. Beim erneuten Laden derselben Senderseite kam kurz danach ein
    # sauberer Token, der sofort abgespielt wurde.
    for marker in OXAX_VOLATILE_MARKERS:
        if marker in tail:
            return True

    # Sehr kurze Tails waren im Log ebenfalls 404-Kandidaten, obwohl die naechste
    # frisch geladene Senderseite funktionierte. Darum vor dem Abspielen lieber
    # nochmal frisch laden, solange Versuche uebrig sind.
    if len(tail) < 22:
        return True

    return False


def oxax_candidate_quality(item):
    tail = oxax_candidate_tail(item)
    volatile = oxax_candidate_is_volatile(item)

    # Bonus fuer stabile, lange, ueberwiegend lowercase/hexartige Tokens.
    stable_score = 0

    if not volatile:
        stable_score += 100

    stable_score += min(len(tail), 60)

    # Uebermaessige Grossbuchstaben am Ende sind meistens PlayerJS-Reste.
    if re.search(r'[A-Z]{2,}', tail):
        stable_score -= 15

    return stable_score


def oxax_should_retry_before_play(item):
    return oxax_candidate_is_volatile(item)


def oxax_order_for_kodi_playback(candidates):
    """Build a safer playback order for OXAX.

    v13 proved that s.oxax.tv is the right primary host for Kodi, but the
    *longest/fullest* PlayerJS candidate is not always the best. In the full
    LibreELEC test, failed first clicks often used tails with SSS/MMM/556G3D
    leftovers and returned 404; the next fresh page load usually produced a
    clean token that started immediately.

    So v14 keeps s.oxax.tv first, but prefers stable/clean tokens before
    volatile PlayerJS leftovers. Volatile candidates are still kept as fallback
    if OXAX only provides those.
    """
    normalized = []

    def add(item):
        item = oxax_clean_decoded_text(item or '').strip()
        item = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', item).strip()

        if item and item not in normalized:
            normalized.append(item)

    for item in candidates or []:
        add(item)

        if 'r.pokaz.me/' in item:
            add(item.replace('https://r.pokaz.me/', 'https://s.oxax.tv/').replace('http://r.pokaz.me/', 'https://s.oxax.tv/'))
        elif 's.oxax.tv/' in item:
            add(item.replace('https://s.oxax.tv/', 'https://r.pokaz.me/').replace('http://s.oxax.tv/', 'https://r.pokaz.me/'))

    def host_rank(item):
        if 's.oxax.tv/' in item:
            return 0
        if 'r.pokaz.me/' in item:
            return 1
        return 2

    indexed = list(enumerate(normalized))
    indexed.sort(key=lambda pair: (
        host_rank(pair[1]),
        -oxax_candidate_quality(pair[1]),
        -len(pair[1]),
        pair[0]
    ))

    ordered = []
    for _, item in indexed:
        if item not in ordered:
            ordered.append(item)

    return ordered



def oxax_autotest_probe_stream(opener, streamurl, page_url, cj=None):
    """Return True/False/None for an OXAX stream candidate.

    True  = candidate is reachable enough to hand to Kodi.
    False = candidate is definitely bad (404/410/403), so Kodi should not see it.
    None  = probe was inconclusive; do not over-block, because Kodi may still play.

    This is only used by the automated senderstatus run. Normal manual playback
    remains direct-to-Kodi so we do not risk consuming/aging tokens unnecessarily.
    """
    streamurl = oxax_clean_decoded_text(streamurl or '').strip()

    if not streamurl:
        return False

    headers = oxax_stream_headers(page_url, cj).copy()
    headers.pop('Connection', None)

    methods = ['HEAD', 'GET']

    for method in methods:
        probe_headers = headers.copy()

        if method == 'GET':
            probe_headers['Range'] = 'bytes=0-2047'

        req = Request(streamurl, headers=probe_headers)

        if method == 'HEAD':
            try:
                req.get_method = lambda: 'HEAD'
            except Exception:
                pass

        try:
            resp = opener.open(req, timeout=OXAX_AUTOTEST_PREFLIGHT_TIMEOUT)
            code = getattr(resp, 'status', None) or resp.getcode()
            final_url = ''

            try:
                final_url = resp.geturl()
            except Exception:
                final_url = streamurl

            if code and int(code) >= 400:
                log('OXAX AutoTest preflight rejected HTTP {} for {}'.format(code, streamurl), xbmc.LOGERROR)
                return False

            if method == 'HEAD':
                log('OXAX AutoTest preflight HEAD OK for {} -> {}'.format(streamurl, final_url))
                return True

            sample = b''

            try:
                sample = resp.read(2048)
            except Exception:
                sample = b''

            if sample:
                text_sample = sample.decode('utf-8', 'ignore') if isinstance(sample, bytes) else str(sample)

                if '#EXTM3U' in text_sample or '#EXT-X-' in text_sample or 'EXTM3U' in text_sample:
                    log('OXAX AutoTest preflight manifest OK for {}'.format(streamurl))
                    return True

                # Some servers already return binary/gzipped/chunked data here.
                # Reaching this point without HTTP error is still safer than
                # handing a known 404 candidate to Kodi.
                log('OXAX AutoTest preflight data OK for {}'.format(streamurl))
                return True

            log('OXAX AutoTest preflight empty/uncertain for {}'.format(streamurl))
            return None

        except HTTPError as e:
            code = getattr(e, 'code', None)

            # Some hosts dislike HEAD, but a GET still works. Only fallback from
            # HEAD for method-specific errors; real 404/410 must be rejected.
            if method == 'HEAD' and code in (405, 501):
                log('OXAX AutoTest preflight HEAD not supported HTTP {} for {}'.format(code, streamurl))
                continue

            if code in (403, 404, 410):
                log('OXAX AutoTest preflight rejected HTTP {} for {}'.format(code, streamurl), xbmc.LOGERROR)
                return False

            log('OXAX AutoTest preflight HTTP {} uncertain for {}'.format(code, streamurl), xbmc.LOGWARNING)
            return None

        except URLError as e:
            log('OXAX AutoTest preflight URL uncertain for {}: {}'.format(streamurl, e), xbmc.LOGWARNING)
            return None

        except Exception as e:
            log('OXAX AutoTest preflight uncertain for {}: {}'.format(streamurl, e), xbmc.LOGWARNING)
            return None

    return None


def oxax_autotest_pick_probe_valid_candidate(opener, candidates, page_url, cj=None):
    """Pick a fast/safe AutoTest candidate.

    v21 reduced the modal Kodi popup, but the log showed a worse side effect:
    when r.pokaz.me only timed out during preflight, the uncertain r-candidate
    was still handed to Kodi. Kodi then blocked the player for roughly 30-60
    seconds and even interfered with the next good s.oxax.tv attempt.

    For the automated senderstatus run we therefore do not hand uncertain
    candidates to Kodi anymore. Only s.oxax.tv candidates with positive
    preflight are allowed. Manual single-channel playback is not changed here.
    """
    ordered = candidates or []

    def allowed(candidate):
        return 's.oxax.tv/' in (candidate or '')

    # First pass: stable s.oxax candidates only.
    for candidate in ordered:
        if not allowed(candidate):
            continue

        if oxax_candidate_is_volatile(candidate):
            continue

        probe = oxax_autotest_probe_stream(opener, candidate, page_url, cj)

        if probe is True:
            return candidate, probe

        log('OXAX AutoTest candidate not accepted for Kodi: {} | probe={}'.format(candidate, probe), xbmc.LOGWARNING)

    # Second pass: volatile s.oxax candidates, but still only when preflight is OK.
    for candidate in ordered:
        if not allowed(candidate):
            continue

        probe = oxax_autotest_probe_stream(opener, candidate, page_url, cj)

        if probe is True:
            return candidate, probe

        log('OXAX AutoTest fallback candidate not accepted for Kodi: {} | probe={}'.format(candidate, probe), xbmc.LOGWARNING)

    return None, False


def oxax_plain_name(name):
    name = re.sub(r'\[/?COLOR[^\]]*\]', '', name or '', flags=re.IGNORECASE)
    return clean_text(name).lower()


def oxax_display_name(name):
    text = re.sub(r'\[/?COLOR[^\]]*\]', '', name or '', flags=re.IGNORECASE)
    return clean_text(text)


def oxax_autotest_skip_reason(name, url):
    """Return a short reason when a channel should be skipped in sender status check.

    v19 keeps these channels in the normal OXAX list, but excludes them from
    the automated status run because they are known website-side problems.
    This makes the status summary honest: OK/testable + skipped separately.
    """
    plain = oxax_plain_name(name)
    path = urlparse(url or '').path.lower()
    slug = path.strip('/').replace('.html', '')

    # Be deliberately tolerant here: OXAX names/paths can appear slightly
    # different depending on the listing endpoint and encoding. Matching by
    # slug substring avoids accidentally testing the known dead channels again.
    known_slug_reasons = {
        'xy-max-hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'xy-mix-hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'exxxotica-hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'russkaya-noch': 'Senderseite meldet: Online-Transaktion nicht verfuegbar',
        'fap-tv-trans': 'Senderseite nicht verfuegbar / 404',
    }

    known_name_reasons = {
        'xy max hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'xy mix hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'exxxotica hd': 'Website-Player vorhanden, aber Stream startet dort nicht',
        'русская ночь': 'Senderseite meldet: Online-Transaktion nicht verfuegbar',
        'русская ночь смотреть': 'Senderseite meldet: Online-Transaktion nicht verfuegbar',
        'fap tv trans': 'Senderseite nicht verfuegbar / 404',
    }

    for known_slug, reason in known_slug_reasons.items():
        if known_slug in slug:
            return reason

    for known_name, reason in known_name_reasons.items():
        if plain == known_name or known_name in plain:
            return reason

    return ''


def oxax_is_red_lips(name, url=''):
    return 'red lips' in oxax_plain_name(name) or 'red-lips' in (url or '').lower()


def oxax_red_lips_candidates(candidates):
    """Red Lips is the one remaining OXAX outlier.

    Other channels now play better through s.oxax.tv, but Red Lips has a
    history of working through the final r.pokaz.me redirect URL. So for this
    one channel we first resolve the r.pokaz.me candidate to its final URL
    without reading the manifest body, then hand that fresh final URL to Kodi.
    """
    ordered = []

    def add(item):
        if item and item not in ordered:
            ordered.append(item)

    for item in candidates or []:
        if 'r.pokaz.me/' in item:
            add(item)

    for item in candidates or []:
        if 's.oxax.tv/' in item:
            add(item.replace('https://s.oxax.tv/', 'https://r.pokaz.me/').replace('http://s.oxax.tv/', 'https://r.pokaz.me/'))

    for item in candidates or []:
        add(item)

    return ordered



def oxax_fetch_channels_for_autotest():
    cj = http.cookiejar.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))

    endpoints = [
        (urljoin(BASE_OXAX, 'spisok'), BASE_OXAX),
        (urljoin(BASE_OXAX, 'spisok?vse=4'), urljoin(BASE_OXAX, 'porno-kanaly.html')),
        (urljoin(BASE_OXAX, 'spisok?vse=1'), BASE_OXAX),
        (urljoin(BASE_OXAX, 'vz_spi.php'), BASE_OXAX),
    ]

    for endpoint, referer in endpoints:
        try:
            html = oxax_get_html(opener, endpoint, referer)
            logo_map = oxax_build_logo_map(opener, html)
            channels = oxax_parse_channels(html, logo_map)

            if channels:
                log('OXAX AutoTest channels: {} from {}'.format(len(channels), endpoint))
                return channels

        except Exception as e:
            log('OXAX AutoTest list endpoint error {}: {}'.format(endpoint, e), xbmc.LOGERROR)

    return []


class OXAXAutoTestPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.started = False
        self.av_started = False
        self.ended = False
        self.stopped = False
        self.error = False

    def onPlayBackStarted(self):
        self.started = True
        log('OXAX AutoTest player callback: started')

    def onAVStarted(self):
        self.av_started = True
        self.started = True
        log('OXAX AutoTest player callback: AV started')

    def onPlayBackEnded(self):
        self.ended = True
        log('OXAX AutoTest player callback: ended')

    def onPlayBackStopped(self):
        self.stopped = True
        log('OXAX AutoTest player callback: stopped')

    def onPlayBackError(self):
        self.error = True
        log('OXAX AutoTest player callback: error', xbmc.LOGERROR)


def oxax_autotest_cancelled(progress=None):
    try:
        if progress and progress.iscanceled():
            return True
    except Exception:
        pass

    try:
        if progress and progress.isCanceled():
            return True
    except Exception:
        pass

    return xbmc.Monitor().abortRequested()


def oxax_wait_for_player(player, start_timeout=OXAX_AUTOTEST_START_TIMEOUT, play_seconds=OXAX_AUTOTEST_PLAY_SECONDS, progress=None, progress_message=''):
    """Wait for a real Kodi playback start without over-counting false starts.

    v19 sometimes counted a retry too early because Kodi fires onPlayBackStarted
    even for URLs that immediately die with 404/demuxer errors. v20 therefore
    waits for AVStarted or isPlaying/isPlayingVideo before the attempt is counted
    as successful. After real playback is detected, the stream is kept visible for
    a few seconds, but short status hiccups during that holding phase are not
    treated as a failure unless Kodi reports error/end/stop.
    """
    start = time.time()
    stable_since = None

    while time.time() - start < start_timeout:
        senderstatus_close_playback_error_dialogs('OXAX AutoTest')
        if oxax_autotest_cancelled(progress):
            return False

        if getattr(player, 'error', False):
            senderstatus_close_playback_error_dialogs('OXAX AutoTest')
            return False

        if (getattr(player, 'ended', False) or getattr(player, 'stopped', False)) and not getattr(player, 'av_started', False):
            senderstatus_close_playback_error_dialogs('OXAX AutoTest')
            return False

        playing_video = False
        try:
            playing_video = bool(player.isPlayingVideo())
        except Exception:
            playing_video = False

        # isPlaying() alone fires too early for failing 404/demuxer attempts and
        # caused v20 to wait as if playback had started. Video/AV is stricter.
        real_started = bool(getattr(player, 'av_started', False) or playing_video)

        if real_started:
            if stable_since is None:
                stable_since = time.time()
                log('OXAX AutoTest real playback detected - confirming stability')

            if time.time() - stable_since >= OXAX_AUTOTEST_STABLE_SECONDS:
                hold_start = time.time()
                log('OXAX AutoTest playback confirmed - holding for {} seconds'.format(play_seconds))

                while time.time() - hold_start < play_seconds:
                    senderstatus_close_playback_error_dialogs('OXAX AutoTest')
                    if oxax_autotest_cancelled(progress):
                        return False

                    if getattr(player, 'error', False) or getattr(player, 'ended', False) or getattr(player, 'stopped', False):
                        return False

                    try:
                        if progress and progress_message:
                            remaining = int(play_seconds - (time.time() - hold_start))
                            progress.update(progress.getPercent() if hasattr(progress, 'getPercent') else 0, progress_message + '\nLäuft noch ca. {} Sekunden...'.format(max(0, remaining)))
                    except Exception:
                        pass

                    time.sleep(0.5)

                return True
        else:
            stable_since = None

        time.sleep(0.35)

    return False


def oxax_autotest_prepare_candidate(name, url, progress=None, channel_index=0, channel_total=0, attempt=1, max_attempts=OXAX_AUTOTEST_MAX_ATTEMPTS):
    """Load the channel page until a sane candidate is available.

    These refreshes are intentionally not counted as visible playback attempts.
    OXAX sometimes returns a page with zero PlayerJS templates or a volatile token
    on the first request, while the next fresh request a second later gives a
    clean stream. Counting those warm-up misses as attempts made v19 look worse
    than the actual playback behavior.
    """
    last_result = None

    for refresh in range(1, OXAX_AUTOTEST_PREFETCH_ROUNDS + 1):
        if oxax_autotest_cancelled(progress):
            return None

        try:
            if progress:
                percent = int((max(channel_index - 1, 0) * 100) / max(channel_total, 1))
                progress.update(percent, 'Teste {} ({}/{})\nVersuch {}/{} - Quelle vorbereiten {}/{}'.format(
                    name, channel_index, channel_total, attempt, max_attempts, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS
                ))
        except Exception:
            pass

        cj = http.cookiejar.CookieJar()
        opener = build_opener(HTTPCookieProcessor(cj))

        try:
            videosrc = browser_get(opener, url, BASE_OXAX)
        except Exception as e:
            log('OXAX AutoTest prefetch page load error for {} ({}/{}): {}'.format(name, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS, e), xbmc.LOGERROR)
            time.sleep(OXAX_AUTOTEST_PREFETCH_PAUSE)
            continue

        candidates = oxax_get_stream_candidates(videosrc, url)
        play_candidates = oxax_order_for_kodi_playback(candidates)

        if not play_candidates:
            log('OXAX AutoTest prefetch no candidates for {} ({}/{})'.format(name, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS))
            time.sleep(OXAX_AUTOTEST_PREFETCH_PAUSE)
            continue

        selected, probe_state = oxax_autotest_pick_probe_valid_candidate(opener, play_candidates, url, cj)

        if not selected:
            log('OXAX AutoTest preflight rejected all candidates for {} ({}/{})'.format(name, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS), xbmc.LOGERROR)
            time.sleep(OXAX_AUTOTEST_PREFETCH_PAUSE)
            continue

        last_result = (selected, cj)

        if probe_state is True:
            log('OXAX AutoTest preflight-stable s-candidate prepared for {} on prefetch {}/{}: {}'.format(name, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS, selected))
            return last_result

        # Sollte durch die neue Auswahl kaum noch passieren. Nicht an Kodi geben,
        # sondern frisch laden, damit kein 30s-Timeout den Auto-Test blockiert.
        log('OXAX AutoTest candidate prepared but not trusted for {} ({}/{}): {} | probe={}'.format(name, refresh, OXAX_AUTOTEST_PREFETCH_ROUNDS, selected, probe_state), xbmc.LOGWARNING)
        time.sleep(OXAX_AUTOTEST_PREFETCH_PAUSE)

    if last_result:
        log('OXAX AutoTest discarding last candidate for {} after prefetch rounds because it was not positively trusted: {}'.format(name, last_result[0]), xbmc.LOGWARNING)

    return None


def oxax_autotest_try_channel(name, url, max_attempts=OXAX_AUTOTEST_MAX_ATTEMPTS, progress=None, channel_index=0, channel_total=0):
    skip_reason = oxax_autotest_skip_reason(name, url)

    if skip_reason:
        log('OXAX AutoTest skipped known unavailable {}: {}'.format(name, skip_reason))
        try:
            notify('Senderstatus uebersprungen: {}'.format(oxax_display_name(name)), False)
        except Exception:
            pass
        return None, 0

    for attempt in range(1, max_attempts + 1):
        if oxax_autotest_cancelled(progress):
            return False, attempt - 1

        log('OXAX AutoTest attempt {}/{} for {}'.format(attempt, max_attempts, name))

        try:
            if progress:
                percent = int((max(channel_index - 1, 0) * 100) / max(channel_total, 1))
                progress.update(percent, 'Teste {} ({}/{})\nVersuch {}/{}'.format(name, channel_index, channel_total, attempt, max_attempts))
        except Exception:
            pass

        prepared = oxax_autotest_prepare_candidate(
            name,
            url,
            progress=progress,
            channel_index=channel_index,
            channel_total=channel_total,
            attempt=attempt,
            max_attempts=max_attempts
        )

        if not prepared:
            log('OXAX AutoTest no prepared candidate for {}'.format(name))
            notify('Stream nicht vorbereitet: {} (Versuch {}/{})'.format(oxax_display_name(name), attempt, max_attempts), False)
            time.sleep(0.35)
            continue

        streamurl, cj = prepared
        finalurl = oxax_kodi_stream_url(streamurl, url, cj)
        log('OXAX AutoTest playing {} attempt {}: {}'.format(name, attempt, streamurl))

        # Vor jedem neuen Versuch sicherstellen, dass keine alte Kodi-Player-
        # Anfrage mehr laeuft. Das verhindert, dass ein vorheriger Timeout den
        # naechsten funktionierenden Sender blockiert.
        try:
            xbmc.executebuiltin('PlayerControl(Stop)')
            time.sleep(0.15)
        except Exception:
            pass

        player = OXAXAutoTestPlayer()
        item = xbmcgui.ListItem(name)

        try:
            item.setProperty('IsPlayable', 'true')
        except Exception:
            pass

        try:
            player.play(finalurl, item)
        except Exception as e:
            log('OXAX AutoTest player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
            time.sleep(0.35)
            continue

        ok = oxax_wait_for_player(
            player,
            start_timeout=OXAX_AUTOTEST_START_TIMEOUT,
            play_seconds=OXAX_AUTOTEST_PLAY_SECONDS,
            progress=progress,
            progress_message='Teste {} ({}/{})\nVersuch {}/{}'.format(name, channel_index, channel_total, attempt, max_attempts)
        )

        try:
            if player.isPlaying():
                player.stop()
        except Exception:
            pass

        # Kurzer Reset reicht im schnellen Senderstatus. Alte Player-Requests
        # werden zusaetzlich aktiv gestoppt.
        try:
            xbmc.executebuiltin('PlayerControl(Stop)')
        except Exception:
            pass
        time.sleep(0.35)

        if ok:
            log('OXAX AutoTest OK for {} on attempt {}'.format(name, attempt))
            return True, attempt

        log('OXAX AutoTest no playback for {} on attempt {}'.format(name, attempt), xbmc.LOGERROR)
        notify('Stream nicht verfuegbar: {} (Versuch {}/{})'.format(oxax_display_name(name), attempt, max_attempts), False)
        time.sleep(0.35)

    return False, max_attempts


@site.register()
def AutoTest_OXAX(url, close_directory=True):
    channels = oxax_fetch_channels_for_autotest()

    if not channels:
        notify('OXAX Auto-Test: keine Sender gefunden', True)
        if close_directory:
            senderstatus_final_cleanup('OXAX Senderstatus', close_directory=True)
        return

    notify('OXAX Senderstatus startet: {} Sender'.format(len(channels)), False)
    ok_count = 0
    failed = []
    skipped = []
    monitor = xbmc.Monitor()
    progress = None

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('OXAX Senderstatus prüfen', 'Starte Schnellpruefung: 2s / max. 2 Versuche...')
    except Exception:
        progress = None

    try:
        for idx, (name, videourl, img) in enumerate(channels, 1):
            if monitor.abortRequested() or oxax_autotest_cancelled(progress):
                log('OXAX Senderstatus cancelled by user/abort')
                break

            start_percent = int(max(0, min(99, ((idx - 1) * 100.0) / max(1, len(channels)))))
            progress = senderstatus_reopen_progress(
                progress,
                'OXAX Senderstatus prüfen',
                'OXAX: {} ({}/{})\nStarte Senderanalyse...'.format(oxax_display_name(name), idx, len(channels)),
                start_percent,
                'OXAX Senderstatus'
            )
            log('OXAX AutoTest channel {}/{}: {} | {}'.format(idx, len(channels), name, videourl))
            ok, used_attempts = oxax_autotest_try_channel(
                name,
                videourl,
                max_attempts=OXAX_AUTOTEST_MAX_ATTEMPTS,
                progress=progress,
                channel_index=idx,
                channel_total=len(channels)
            )

            if ok is None:
                skipped.append(name)
            elif ok:
                ok_count += 1
            else:
                failed.append(name)

            percent = int((idx * 100) / max(len(channels), 1))
            progress = senderstatus_reopen_progress(
                progress,
                'OXAX Senderstatus prüfen',
                'OXAX fertig: {} ({}/{})\nOK: {} | Fehler: {} | Übersprungen: {}'.format(
                    oxax_display_name(name), idx, len(channels), ok_count, len(failed), len(skipped)
                ),
                percent,
                'OXAX Senderstatus'
            )

            # v22: kurze Pause reicht; langsame r.pokaz-Timeouts werden nicht mehr gestartet.
            pause_ticks = int(max(OXAX_AUTOTEST_PAUSE_SECONDS, 0) * 2)
            for _ in range(pause_ticks):
                if monitor.abortRequested() or oxax_autotest_cancelled(progress):
                    break
                time.sleep(0.5)

    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass

    testable_total = max(len(channels) - len(skipped), 0)
    status_msg = 'OXAX Senderstatus v72 summary: {}/{} testbare Sender OK | gesamt: {} | failed: {} | skipped: {}'.format(
        ok_count,
        testable_total,
        len(channels),
        ', '.join(failed) if failed else '-',
        ', '.join(skipped) if skipped else '-'
    )
    log(status_msg)

    if failed:
        notify('OXAX Senderstatus: {}/{} OK, {} Fehler, {} uebersprungen'.format(ok_count, testable_total, len(failed), len(skipped)), True)
    else:
        notify('OXAX Senderstatus: {}/{} OK, {} uebersprungen'.format(ok_count, testable_total, len(skipped)), False)

    if close_directory:
        senderstatus_final_cleanup('OXAX Senderstatus', close_directory=True)


@site.register()
def AutoTest_SelectSites(url, name=None, download=None):
    options = [
        'Alle verfügbaren Sites',
        'Oxax.tv',
        'Adult-TV-Channels.com',
        'Adult-TV-Channels.click',
        'FuckFlix.click'
    ]

    try:
        selected = xbmcgui.Dialog().multiselect('Senderstatus prüfen', options)
    except Exception as e:
        log('Senderstatus selection error: {}'.format(e), xbmc.LOGERROR)
        selected = None

    if not selected:
        senderstatus_final_cleanup('Senderstatus Auswahl', close_directory=True)
        return

    run_oxax = 0 in selected or 1 in selected
    run_com = 0 in selected or 2 in selected
    run_click = 0 in selected or 3 in selected
    run_fuckflix = 0 in selected or 4 in selected

    if not run_oxax and not run_com and not run_click and not run_fuckflix:
        senderstatus_final_cleanup('Senderstatus Auswahl', close_directory=True)
        return

    # v44: In einem Multi-Site-Lauf darf nur AutoTest_SelectSites selbst das
    # Directory beenden. Sonst bleibt Kodi nach dem ersten Test gern in einem
    # leeren Skin-/Container-Zustand oder oeffnet beim naechsten Add-on-Start
    # erneut das Senderstatus-Auswahlfenster.
    try:
        if run_oxax:
            AutoTest_OXAX(urljoin(BASE_OXAX, 'porno-kanaly.html'), close_directory=False)
            senderstatus_between_sites_cleanup('OXAX')

        if run_com:
            AutoTest_COM(BASE_COM, close_directory=False)
            senderstatus_between_sites_cleanup('COM')

        if run_click:
            AutoTest_CLICK(BASE_CLICK, close_directory=False)
            senderstatus_between_sites_cleanup('CLICK')

        if run_fuckflix:
            AutoTest_FUCKFLIX(BASE_FUCKFLIX, close_directory=False)
            senderstatus_between_sites_cleanup('FUCKFLIX')
    finally:
        senderstatus_final_cleanup('Senderstatus Auswahl', close_directory=True)


@site.register()
def Play_OXAX(url, name, download=None):
    log('OXAX Play start v72 popup-safe: {} | {}'.format(name, url))

    cj = http.cookiejar.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))

    for attempt in range(1, 5):
        if attempt > 1:
            log('OXAX retry attempt {} for {}'.format(attempt, name))
            time.sleep(0.8)

        try:
            videosrc = browser_get(opener, url, BASE_OXAX)
        except Exception as e:
            log('OXAX page load error: {}'.format(e), xbmc.LOGERROR)
            notify('OXAX: Senderseite konnte nicht geladen werden', True)
            return

        candidates = oxax_get_stream_candidates(videosrc, url)
        if not candidates:
            continue

        play_candidates = oxax_order_for_kodi_playback(candidates)
        streamurl = play_candidates[0]
        log('OXAX Kodi playback candidates ordered: {}'.format(len(play_candidates)))
        log('OXAX Kodi candidate order mode: s-host/stable-clean-first')

        if attempt < 4 and oxax_should_retry_before_play(streamurl):
            log('OXAX best candidate still looks volatile/short - refreshing page before Kodi for {}: {}'.format(name, streamurl))
            continue

        finalurl = oxax_kodi_stream_url(streamurl, url, cj)
        log('OXAX handing fresh preferred candidate to monitored Kodi for {} attempt {}: {}'.format(name, attempt, streamurl))

        try:
            xbmc.executebuiltin('PlayerControl(Stop)')
            senderstatus_close_playback_error_dialogs('OXAX Einzelstart')
            time.sleep(0.15)
        except Exception:
            pass

        player = SenderStatusPlayer('OXAX Einzelstart')
        item = xbmcgui.ListItem(name)
        try:
            item.setProperty('IsPlayable', 'true')
        except Exception:
            pass

        try:
            player.play(finalurl, item)
        except Exception as e:
            log('OXAX Einzelstart player.play error for {}: {}'.format(name, e), xbmc.LOGERROR)
            senderstatus_close_playback_error_dialogs('OXAX Einzelstart')
            continue

        ok = senderstatus_wait_for_player(
            player,
            start_timeout=8,
            play_seconds=0.15,
            stable_seconds=0.5,
            progress=None,
            progress_message='',
            log_prefix='OXAX Einzelstart'
        )
        senderstatus_close_playback_error_dialogs('OXAX Einzelstart')

        if ok:
            log('OXAX Einzelstart playback confirmed for {} on attempt {}; leaving playback running'.format(name, attempt))
            return

        log('OXAX Einzelstart no stable playback for {} on attempt {}'.format(name, attempt), xbmc.LOGERROR)
        try:
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
        try:
            xbmc.executebuiltin('PlayerControl(Stop)')
        except Exception:
            pass
        senderstatus_close_playback_error_dialogs('OXAX Einzelstart')
        time.sleep(0.35)

    senderstatus_close_playback_error_dialogs('OXAX Einzelstart')
    notify('OXAX: Stream nach 4 Versuchen nicht verfügbar', False)

